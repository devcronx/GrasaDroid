#include "cpu.h"
#include "simd.h"
void f_700452d1f0(Cpu *c) {
    FN_ENTER(0x700452d1f0ull);
L_700452d1f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x330ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x330ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d200(Cpu *c) {
    FN_ENTER(0x700452d200ull);
L_700452d200:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x338ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x338ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d210(Cpu *c) {
    FN_ENTER(0x700452d210ull);
L_700452d210:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x340ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x340ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d220(Cpu *c) {
    FN_ENTER(0x700452d220ull);
L_700452d220:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x348ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x348ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d230(Cpu *c) {
    FN_ENTER(0x700452d230ull);
L_700452d230:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x350ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x350ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d240(Cpu *c) {
    FN_ENTER(0x700452d240ull);
L_700452d240:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x358ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x358ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d250(Cpu *c) {
    FN_ENTER(0x700452d250ull);
L_700452d250:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x360ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x360ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d260(Cpu *c) {
    FN_ENTER(0x700452d260ull);
L_700452d260:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x368ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x368ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d270(Cpu *c) {
    FN_ENTER(0x700452d270ull);
L_700452d270:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x370ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x370ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d280(Cpu *c) {
    FN_ENTER(0x700452d280ull);
L_700452d280:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x378ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x378ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d290(Cpu *c) {
    FN_ENTER(0x700452d290ull);
L_700452d290:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x380ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x380ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d2a0(Cpu *c) {
    FN_ENTER(0x700452d2a0ull);
L_700452d2a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x388ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x388ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d2b0(Cpu *c) {
    FN_ENTER(0x700452d2b0ull);
L_700452d2b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x390ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x390ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d2c0(Cpu *c) {
    FN_ENTER(0x700452d2c0ull);
L_700452d2c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x398ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x398ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d2d0(Cpu *c) {
    FN_ENTER(0x700452d2d0ull);
L_700452d2d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d2e0(Cpu *c) {
    FN_ENTER(0x700452d2e0ull);
L_700452d2e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d2f0(Cpu *c) {
    FN_ENTER(0x700452d2f0ull);
L_700452d2f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d300(Cpu *c) {
    FN_ENTER(0x700452d300ull);
L_700452d300:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d310(Cpu *c) {
    FN_ENTER(0x700452d310ull);
L_700452d310:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d320(Cpu *c) {
    FN_ENTER(0x700452d320ull);
L_700452d320:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d330(Cpu *c) {
    FN_ENTER(0x700452d330ull);
L_700452d330:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d340(Cpu *c) {
    FN_ENTER(0x700452d340ull);
L_700452d340:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d350(Cpu *c) {
    FN_ENTER(0x700452d350ull);
L_700452d350:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d360(Cpu *c) {
    FN_ENTER(0x700452d360ull);
L_700452d360:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d370(Cpu *c) {
    FN_ENTER(0x700452d370ull);
L_700452d370:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d380(Cpu *c) {
    FN_ENTER(0x700452d380ull);
L_700452d380:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x3f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d390(Cpu *c) {
    FN_ENTER(0x700452d390ull);
L_700452d390:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x400ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x400ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d3a0(Cpu *c) {
    FN_ENTER(0x700452d3a0ull);
L_700452d3a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x408ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x408ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d3b0(Cpu *c) {
    FN_ENTER(0x700452d3b0ull);
L_700452d3b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x410ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x410ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d3c0(Cpu *c) {
    FN_ENTER(0x700452d3c0ull);
L_700452d3c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x418ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x418ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d3d0(Cpu *c) {
    FN_ENTER(0x700452d3d0ull);
L_700452d3d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x420ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x420ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d3e0(Cpu *c) {
    FN_ENTER(0x700452d3e0ull);
L_700452d3e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x428ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x428ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d3f0(Cpu *c) {
    FN_ENTER(0x700452d3f0ull);
L_700452d3f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x430ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x430ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d400(Cpu *c) {
    FN_ENTER(0x700452d400ull);
L_700452d400:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x438ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x438ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d410(Cpu *c) {
    FN_ENTER(0x700452d410ull);
L_700452d410:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x440ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x440ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d420(Cpu *c) {
    FN_ENTER(0x700452d420ull);
L_700452d420:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x448ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x448ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d430(Cpu *c) {
    FN_ENTER(0x700452d430ull);
L_700452d430:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d440(Cpu *c) {
    FN_ENTER(0x700452d440ull);
L_700452d440:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d450(Cpu *c) {
    FN_ENTER(0x700452d450ull);
L_700452d450:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d460(Cpu *c) {
    FN_ENTER(0x700452d460ull);
L_700452d460:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d470(Cpu *c) {
    FN_ENTER(0x700452d470ull);
L_700452d470:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d480(Cpu *c) {
    FN_ENTER(0x700452d480ull);
L_700452d480:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d490(Cpu *c) {
    FN_ENTER(0x700452d490ull);
L_700452d490:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d4a0(Cpu *c) {
    FN_ENTER(0x700452d4a0ull);
L_700452d4a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d4b0(Cpu *c) {
    FN_ENTER(0x700452d4b0ull);
L_700452d4b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d4c0(Cpu *c) {
    FN_ENTER(0x700452d4c0ull);
L_700452d4c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d4d0(Cpu *c) {
    FN_ENTER(0x700452d4d0ull);
L_700452d4d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d4e0(Cpu *c) {
    FN_ENTER(0x700452d4e0ull);
L_700452d4e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d4f0(Cpu *c) {
    FN_ENTER(0x700452d4f0ull);
L_700452d4f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d500(Cpu *c) {
    FN_ENTER(0x700452d500ull);
L_700452d500:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d510(Cpu *c) {
    FN_ENTER(0x700452d510ull);
L_700452d510:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d520(Cpu *c) {
    FN_ENTER(0x700452d520ull);
L_700452d520:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d530(Cpu *c) {
    FN_ENTER(0x700452d530ull);
L_700452d530:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d540(Cpu *c) {
    FN_ENTER(0x700452d540ull);
L_700452d540:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d550(Cpu *c) {
    FN_ENTER(0x700452d550ull);
L_700452d550:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d560(Cpu *c) {
    FN_ENTER(0x700452d560ull);
L_700452d560:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d570(Cpu *c) {
    FN_ENTER(0x700452d570ull);
L_700452d570:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d580(Cpu *c) {
    FN_ENTER(0x700452d580ull);
L_700452d580:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d590(Cpu *c) {
    FN_ENTER(0x700452d590ull);
L_700452d590:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d5a0(Cpu *c) {
    FN_ENTER(0x700452d5a0ull);
L_700452d5a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d5b0(Cpu *c) {
    FN_ENTER(0x700452d5b0ull);
L_700452d5b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d5c0(Cpu *c) {
    FN_ENTER(0x700452d5c0ull);
L_700452d5c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d5d0(Cpu *c) {
    FN_ENTER(0x700452d5d0ull);
L_700452d5d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d5e0(Cpu *c) {
    FN_ENTER(0x700452d5e0ull);
L_700452d5e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d5f0(Cpu *c) {
    FN_ENTER(0x700452d5f0ull);
L_700452d5f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d600(Cpu *c) {
    FN_ENTER(0x700452d600ull);
L_700452d600:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d610(Cpu *c) {
    FN_ENTER(0x700452d610ull);
L_700452d610:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d620(Cpu *c) {
    FN_ENTER(0x700452d620ull);
L_700452d620:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d630(Cpu *c) {
    FN_ENTER(0x700452d630ull);
L_700452d630:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d640(Cpu *c) {
    FN_ENTER(0x700452d640ull);
L_700452d640:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d650(Cpu *c) {
    FN_ENTER(0x700452d650ull);
L_700452d650:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d660(Cpu *c) {
    FN_ENTER(0x700452d660ull);
L_700452d660:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d670(Cpu *c) {
    FN_ENTER(0x700452d670ull);
L_700452d670:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d680(Cpu *c) {
    FN_ENTER(0x700452d680ull);
L_700452d680:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d690(Cpu *c) {
    FN_ENTER(0x700452d690ull);
L_700452d690:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d6a0(Cpu *c) {
    FN_ENTER(0x700452d6a0ull);
L_700452d6a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d6b0(Cpu *c) {
    FN_ENTER(0x700452d6b0ull);
L_700452d6b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d6c0(Cpu *c) {
    FN_ENTER(0x700452d6c0ull);
L_700452d6c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d6d0(Cpu *c) {
    FN_ENTER(0x700452d6d0ull);
L_700452d6d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d6e0(Cpu *c) {
    FN_ENTER(0x700452d6e0ull);
L_700452d6e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d6f0(Cpu *c) {
    FN_ENTER(0x700452d6f0ull);
L_700452d6f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d700(Cpu *c) {
    FN_ENTER(0x700452d700ull);
L_700452d700:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d710(Cpu *c) {
    FN_ENTER(0x700452d710ull);
L_700452d710:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d720(Cpu *c) {
    FN_ENTER(0x700452d720ull);
L_700452d720:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d730(Cpu *c) {
    FN_ENTER(0x700452d730ull);
L_700452d730:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d740(Cpu *c) {
    FN_ENTER(0x700452d740ull);
L_700452d740:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d750(Cpu *c) {
    FN_ENTER(0x700452d750ull);
L_700452d750:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d760(Cpu *c) {
    FN_ENTER(0x700452d760ull);
L_700452d760:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d770(Cpu *c) {
    FN_ENTER(0x700452d770ull);
L_700452d770:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d780(Cpu *c) {
    FN_ENTER(0x700452d780ull);
L_700452d780:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d790(Cpu *c) {
    FN_ENTER(0x700452d790ull);
L_700452d790:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d7a0(Cpu *c) {
    FN_ENTER(0x700452d7a0ull);
L_700452d7a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d7b0(Cpu *c) {
    FN_ENTER(0x700452d7b0ull);
L_700452d7b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d7c0(Cpu *c) {
    FN_ENTER(0x700452d7c0ull);
L_700452d7c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d7d0(Cpu *c) {
    FN_ENTER(0x700452d7d0ull);
L_700452d7d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d7e0(Cpu *c) {
    FN_ENTER(0x700452d7e0ull);
L_700452d7e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d7f0(Cpu *c) {
    FN_ENTER(0x700452d7f0ull);
L_700452d7f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d800(Cpu *c) {
    FN_ENTER(0x700452d800ull);
L_700452d800:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d810(Cpu *c) {
    FN_ENTER(0x700452d810ull);
L_700452d810:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d820(Cpu *c) {
    FN_ENTER(0x700452d820ull);
L_700452d820:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d830(Cpu *c) {
    FN_ENTER(0x700452d830ull);
L_700452d830:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d840(Cpu *c) {
    FN_ENTER(0x700452d840ull);
L_700452d840:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d850(Cpu *c) {
    FN_ENTER(0x700452d850ull);
L_700452d850:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d860(Cpu *c) {
    FN_ENTER(0x700452d860ull);
L_700452d860:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d870(Cpu *c) {
    FN_ENTER(0x700452d870ull);
L_700452d870:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d880(Cpu *c) {
    FN_ENTER(0x700452d880ull);
L_700452d880:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d890(Cpu *c) {
    FN_ENTER(0x700452d890ull);
L_700452d890:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d8a0(Cpu *c) {
    FN_ENTER(0x700452d8a0ull);
L_700452d8a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d8b0(Cpu *c) {
    FN_ENTER(0x700452d8b0ull);
L_700452d8b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d8c0(Cpu *c) {
    FN_ENTER(0x700452d8c0ull);
L_700452d8c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d8d0(Cpu *c) {
    FN_ENTER(0x700452d8d0ull);
L_700452d8d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d8e0(Cpu *c) {
    FN_ENTER(0x700452d8e0ull);
L_700452d8e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d8f0(Cpu *c) {
    FN_ENTER(0x700452d8f0ull);
L_700452d8f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d900(Cpu *c) {
    FN_ENTER(0x700452d900ull);
L_700452d900:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d910(Cpu *c) {
    FN_ENTER(0x700452d910ull);
L_700452d910:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d920(Cpu *c) {
    FN_ENTER(0x700452d920ull);
L_700452d920:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d930(Cpu *c) {
    FN_ENTER(0x700452d930ull);
L_700452d930:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d940(Cpu *c) {
    FN_ENTER(0x700452d940ull);
L_700452d940:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d950(Cpu *c) {
    FN_ENTER(0x700452d950ull);
L_700452d950:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d960(Cpu *c) {
    FN_ENTER(0x700452d960ull);
L_700452d960:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d970(Cpu *c) {
    FN_ENTER(0x700452d970ull);
L_700452d970:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d980(Cpu *c) {
    FN_ENTER(0x700452d980ull);
L_700452d980:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d990(Cpu *c) {
    FN_ENTER(0x700452d990ull);
L_700452d990:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d9a0(Cpu *c) {
    FN_ENTER(0x700452d9a0ull);
L_700452d9a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d9b0(Cpu *c) {
    FN_ENTER(0x700452d9b0ull);
L_700452d9b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d9c0(Cpu *c) {
    FN_ENTER(0x700452d9c0ull);
L_700452d9c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d9d0(Cpu *c) {
    FN_ENTER(0x700452d9d0ull);
L_700452d9d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d9e0(Cpu *c) {
    FN_ENTER(0x700452d9e0ull);
L_700452d9e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d9f0(Cpu *c) {
    FN_ENTER(0x700452d9f0ull);
L_700452d9f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da00(Cpu *c) {
    FN_ENTER(0x700452da00ull);
L_700452da00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da10(Cpu *c) {
    FN_ENTER(0x700452da10ull);
L_700452da10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da20(Cpu *c) {
    FN_ENTER(0x700452da20ull);
L_700452da20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da30(Cpu *c) {
    FN_ENTER(0x700452da30ull);
L_700452da30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da40(Cpu *c) {
    FN_ENTER(0x700452da40ull);
L_700452da40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da50(Cpu *c) {
    FN_ENTER(0x700452da50ull);
L_700452da50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da60(Cpu *c) {
    FN_ENTER(0x700452da60ull);
L_700452da60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da70(Cpu *c) {
    FN_ENTER(0x700452da70ull);
L_700452da70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da80(Cpu *c) {
    FN_ENTER(0x700452da80ull);
L_700452da80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452da90(Cpu *c) {
    FN_ENTER(0x700452da90ull);
L_700452da90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452daa0(Cpu *c) {
    FN_ENTER(0x700452daa0ull);
L_700452daa0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dab0(Cpu *c) {
    FN_ENTER(0x700452dab0ull);
L_700452dab0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dac0(Cpu *c) {
    FN_ENTER(0x700452dac0ull);
L_700452dac0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dad0(Cpu *c) {
    FN_ENTER(0x700452dad0ull);
L_700452dad0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dae0(Cpu *c) {
    FN_ENTER(0x700452dae0ull);
L_700452dae0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452daf0(Cpu *c) {
    FN_ENTER(0x700452daf0ull);
L_700452daf0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db00(Cpu *c) {
    FN_ENTER(0x700452db00ull);
L_700452db00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db10(Cpu *c) {
    FN_ENTER(0x700452db10ull);
L_700452db10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db20(Cpu *c) {
    FN_ENTER(0x700452db20ull);
L_700452db20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db30(Cpu *c) {
    FN_ENTER(0x700452db30ull);
L_700452db30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db40(Cpu *c) {
    FN_ENTER(0x700452db40ull);
L_700452db40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db50(Cpu *c) {
    FN_ENTER(0x700452db50ull);
L_700452db50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db60(Cpu *c) {
    FN_ENTER(0x700452db60ull);
L_700452db60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db70(Cpu *c) {
    FN_ENTER(0x700452db70ull);
L_700452db70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db80(Cpu *c) {
    FN_ENTER(0x700452db80ull);
L_700452db80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452db90(Cpu *c) {
    FN_ENTER(0x700452db90ull);
L_700452db90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dba0(Cpu *c) {
    FN_ENTER(0x700452dba0ull);
L_700452dba0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dbb0(Cpu *c) {
    FN_ENTER(0x700452dbb0ull);
L_700452dbb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dbc0(Cpu *c) {
    FN_ENTER(0x700452dbc0ull);
L_700452dbc0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dbd0(Cpu *c) {
    FN_ENTER(0x700452dbd0ull);
L_700452dbd0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dbe0(Cpu *c) {
    FN_ENTER(0x700452dbe0ull);
L_700452dbe0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dbf0(Cpu *c) {
    FN_ENTER(0x700452dbf0ull);
L_700452dbf0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc00(Cpu *c) {
    FN_ENTER(0x700452dc00ull);
L_700452dc00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc10(Cpu *c) {
    FN_ENTER(0x700452dc10ull);
L_700452dc10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc20(Cpu *c) {
    FN_ENTER(0x700452dc20ull);
L_700452dc20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc30(Cpu *c) {
    FN_ENTER(0x700452dc30ull);
L_700452dc30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc40(Cpu *c) {
    FN_ENTER(0x700452dc40ull);
L_700452dc40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc50(Cpu *c) {
    FN_ENTER(0x700452dc50ull);
L_700452dc50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc60(Cpu *c) {
    FN_ENTER(0x700452dc60ull);
L_700452dc60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc70(Cpu *c) {
    FN_ENTER(0x700452dc70ull);
L_700452dc70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc80(Cpu *c) {
    FN_ENTER(0x700452dc80ull);
L_700452dc80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dc90(Cpu *c) {
    FN_ENTER(0x700452dc90ull);
L_700452dc90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dca0(Cpu *c) {
    FN_ENTER(0x700452dca0ull);
L_700452dca0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dcb0(Cpu *c) {
    FN_ENTER(0x700452dcb0ull);
L_700452dcb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dcc0(Cpu *c) {
    FN_ENTER(0x700452dcc0ull);
L_700452dcc0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dcd0(Cpu *c) {
    FN_ENTER(0x700452dcd0ull);
L_700452dcd0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dce0(Cpu *c) {
    FN_ENTER(0x700452dce0ull);
L_700452dce0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dcf0(Cpu *c) {
    FN_ENTER(0x700452dcf0ull);
L_700452dcf0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd00(Cpu *c) {
    FN_ENTER(0x700452dd00ull);
L_700452dd00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd10(Cpu *c) {
    FN_ENTER(0x700452dd10ull);
L_700452dd10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd20(Cpu *c) {
    FN_ENTER(0x700452dd20ull);
L_700452dd20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd30(Cpu *c) {
    FN_ENTER(0x700452dd30ull);
L_700452dd30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd40(Cpu *c) {
    FN_ENTER(0x700452dd40ull);
L_700452dd40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd50(Cpu *c) {
    FN_ENTER(0x700452dd50ull);
L_700452dd50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd60(Cpu *c) {
    FN_ENTER(0x700452dd60ull);
L_700452dd60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd70(Cpu *c) {
    FN_ENTER(0x700452dd70ull);
L_700452dd70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd80(Cpu *c) {
    FN_ENTER(0x700452dd80ull);
L_700452dd80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dd90(Cpu *c) {
    FN_ENTER(0x700452dd90ull);
L_700452dd90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dda0(Cpu *c) {
    FN_ENTER(0x700452dda0ull);
L_700452dda0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ddb0(Cpu *c) {
    FN_ENTER(0x700452ddb0ull);
L_700452ddb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ddc0(Cpu *c) {
    FN_ENTER(0x700452ddc0ull);
L_700452ddc0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ddd0(Cpu *c) {
    FN_ENTER(0x700452ddd0ull);
L_700452ddd0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dde0(Cpu *c) {
    FN_ENTER(0x700452dde0ull);
L_700452dde0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ddf0(Cpu *c) {
    FN_ENTER(0x700452ddf0ull);
L_700452ddf0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de00(Cpu *c) {
    FN_ENTER(0x700452de00ull);
L_700452de00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de10(Cpu *c) {
    FN_ENTER(0x700452de10ull);
L_700452de10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de20(Cpu *c) {
    FN_ENTER(0x700452de20ull);
L_700452de20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de30(Cpu *c) {
    FN_ENTER(0x700452de30ull);
L_700452de30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de40(Cpu *c) {
    FN_ENTER(0x700452de40ull);
L_700452de40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de50(Cpu *c) {
    FN_ENTER(0x700452de50ull);
L_700452de50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de60(Cpu *c) {
    FN_ENTER(0x700452de60ull);
L_700452de60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de70(Cpu *c) {
    FN_ENTER(0x700452de70ull);
L_700452de70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de80(Cpu *c) {
    FN_ENTER(0x700452de80ull);
L_700452de80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452de90(Cpu *c) {
    FN_ENTER(0x700452de90ull);
L_700452de90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dea0(Cpu *c) {
    FN_ENTER(0x700452dea0ull);
L_700452dea0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452deb0(Cpu *c) {
    FN_ENTER(0x700452deb0ull);
L_700452deb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dec0(Cpu *c) {
    FN_ENTER(0x700452dec0ull);
L_700452dec0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ded0(Cpu *c) {
    FN_ENTER(0x700452ded0ull);
L_700452ded0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dee0(Cpu *c) {
    FN_ENTER(0x700452dee0ull);
L_700452dee0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452def0(Cpu *c) {
    FN_ENTER(0x700452def0ull);
L_700452def0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df00(Cpu *c) {
    FN_ENTER(0x700452df00ull);
L_700452df00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df10(Cpu *c) {
    FN_ENTER(0x700452df10ull);
L_700452df10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df20(Cpu *c) {
    FN_ENTER(0x700452df20ull);
L_700452df20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df30(Cpu *c) {
    FN_ENTER(0x700452df30ull);
L_700452df30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df40(Cpu *c) {
    FN_ENTER(0x700452df40ull);
L_700452df40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df50(Cpu *c) {
    FN_ENTER(0x700452df50ull);
L_700452df50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df60(Cpu *c) {
    FN_ENTER(0x700452df60ull);
L_700452df60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df70(Cpu *c) {
    FN_ENTER(0x700452df70ull);
L_700452df70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df80(Cpu *c) {
    FN_ENTER(0x700452df80ull);
L_700452df80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452df90(Cpu *c) {
    FN_ENTER(0x700452df90ull);
L_700452df90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dfa0(Cpu *c) {
    FN_ENTER(0x700452dfa0ull);
L_700452dfa0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dfb0(Cpu *c) {
    FN_ENTER(0x700452dfb0ull);
L_700452dfb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dfc0(Cpu *c) {
    FN_ENTER(0x700452dfc0ull);
L_700452dfc0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dfd0(Cpu *c) {
    FN_ENTER(0x700452dfd0ull);
L_700452dfd0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dfe0(Cpu *c) {
    FN_ENTER(0x700452dfe0ull);
L_700452dfe0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452dff0(Cpu *c) {
    FN_ENTER(0x700452dff0ull);
L_700452dff0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e000(Cpu *c) {
    FN_ENTER(0x700452e000ull);
L_700452e000:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e010(Cpu *c) {
    FN_ENTER(0x700452e010ull);
L_700452e010:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e020(Cpu *c) {
    FN_ENTER(0x700452e020ull);
L_700452e020:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e030(Cpu *c) {
    FN_ENTER(0x700452e030ull);
L_700452e030:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e040(Cpu *c) {
    FN_ENTER(0x700452e040ull);
L_700452e040:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e050(Cpu *c) {
    FN_ENTER(0x700452e050ull);
L_700452e050:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e060(Cpu *c) {
    FN_ENTER(0x700452e060ull);
L_700452e060:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e070(Cpu *c) {
    FN_ENTER(0x700452e070ull);
L_700452e070:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e080(Cpu *c) {
    FN_ENTER(0x700452e080ull);
L_700452e080:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e090(Cpu *c) {
    FN_ENTER(0x700452e090ull);
L_700452e090:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e0a0(Cpu *c) {
    FN_ENTER(0x700452e0a0ull);
L_700452e0a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e0b0(Cpu *c) {
    FN_ENTER(0x700452e0b0ull);
L_700452e0b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e0c0(Cpu *c) {
    FN_ENTER(0x700452e0c0ull);
L_700452e0c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e0d0(Cpu *c) {
    FN_ENTER(0x700452e0d0ull);
L_700452e0d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e0e0(Cpu *c) {
    FN_ENTER(0x700452e0e0ull);
L_700452e0e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e0f0(Cpu *c) {
    FN_ENTER(0x700452e0f0ull);
L_700452e0f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e100(Cpu *c) {
    FN_ENTER(0x700452e100ull);
L_700452e100:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e110(Cpu *c) {
    FN_ENTER(0x700452e110ull);
L_700452e110:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e120(Cpu *c) {
    FN_ENTER(0x700452e120ull);
L_700452e120:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e130(Cpu *c) {
    FN_ENTER(0x700452e130ull);
L_700452e130:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e140(Cpu *c) {
    FN_ENTER(0x700452e140ull);
L_700452e140:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e150(Cpu *c) {
    FN_ENTER(0x700452e150ull);
L_700452e150:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e160(Cpu *c) {
    FN_ENTER(0x700452e160ull);
L_700452e160:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e170(Cpu *c) {
    FN_ENTER(0x700452e170ull);
L_700452e170:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e180(Cpu *c) {
    FN_ENTER(0x700452e180ull);
L_700452e180:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e190(Cpu *c) {
    FN_ENTER(0x700452e190ull);
L_700452e190:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e1a0(Cpu *c) {
    FN_ENTER(0x700452e1a0ull);
L_700452e1a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e1b0(Cpu *c) {
    FN_ENTER(0x700452e1b0ull);
L_700452e1b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e1c0(Cpu *c) {
    FN_ENTER(0x700452e1c0ull);
L_700452e1c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e1d0(Cpu *c) {
    FN_ENTER(0x700452e1d0ull);
L_700452e1d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e1e0(Cpu *c) {
    FN_ENTER(0x700452e1e0ull);
L_700452e1e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e1f0(Cpu *c) {
    FN_ENTER(0x700452e1f0ull);
L_700452e1f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e200(Cpu *c) {
    FN_ENTER(0x700452e200ull);
L_700452e200:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e210(Cpu *c) {
    FN_ENTER(0x700452e210ull);
L_700452e210:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e220(Cpu *c) {
    FN_ENTER(0x700452e220ull);
L_700452e220:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e230(Cpu *c) {
    FN_ENTER(0x700452e230ull);
L_700452e230:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e240(Cpu *c) {
    FN_ENTER(0x700452e240ull);
L_700452e240:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e250(Cpu *c) {
    FN_ENTER(0x700452e250ull);
L_700452e250:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e260(Cpu *c) {
    FN_ENTER(0x700452e260ull);
L_700452e260:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e270(Cpu *c) {
    FN_ENTER(0x700452e270ull);
L_700452e270:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e280(Cpu *c) {
    FN_ENTER(0x700452e280ull);
L_700452e280:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e290(Cpu *c) {
    FN_ENTER(0x700452e290ull);
L_700452e290:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e2a0(Cpu *c) {
    FN_ENTER(0x700452e2a0ull);
L_700452e2a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e2b0(Cpu *c) {
    FN_ENTER(0x700452e2b0ull);
L_700452e2b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e2c0(Cpu *c) {
    FN_ENTER(0x700452e2c0ull);
L_700452e2c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e2d0(Cpu *c) {
    FN_ENTER(0x700452e2d0ull);
L_700452e2d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e2e0(Cpu *c) {
    FN_ENTER(0x700452e2e0ull);
L_700452e2e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e2f0(Cpu *c) {
    FN_ENTER(0x700452e2f0ull);
L_700452e2f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e300(Cpu *c) {
    FN_ENTER(0x700452e300ull);
L_700452e300:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e310(Cpu *c) {
    FN_ENTER(0x700452e310ull);
L_700452e310:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e320(Cpu *c) {
    FN_ENTER(0x700452e320ull);
L_700452e320:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e330(Cpu *c) {
    FN_ENTER(0x700452e330ull);
L_700452e330:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e340(Cpu *c) {
    FN_ENTER(0x700452e340ull);
L_700452e340:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e350(Cpu *c) {
    FN_ENTER(0x700452e350ull);
L_700452e350:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e360(Cpu *c) {
    FN_ENTER(0x700452e360ull);
L_700452e360:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e370(Cpu *c) {
    FN_ENTER(0x700452e370ull);
L_700452e370:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e380(Cpu *c) {
    FN_ENTER(0x700452e380ull);
L_700452e380:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e390(Cpu *c) {
    FN_ENTER(0x700452e390ull);
L_700452e390:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e3a0(Cpu *c) {
    FN_ENTER(0x700452e3a0ull);
L_700452e3a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e3b0(Cpu *c) {
    FN_ENTER(0x700452e3b0ull);
L_700452e3b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e3c0(Cpu *c) {
    FN_ENTER(0x700452e3c0ull);
L_700452e3c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e3d0(Cpu *c) {
    FN_ENTER(0x700452e3d0ull);
L_700452e3d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e3e0(Cpu *c) {
    FN_ENTER(0x700452e3e0ull);
L_700452e3e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e3f0(Cpu *c) {
    FN_ENTER(0x700452e3f0ull);
L_700452e3f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e400(Cpu *c) {
    FN_ENTER(0x700452e400ull);
L_700452e400:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e410(Cpu *c) {
    FN_ENTER(0x700452e410ull);
L_700452e410:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e420(Cpu *c) {
    FN_ENTER(0x700452e420ull);
L_700452e420:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e430(Cpu *c) {
    FN_ENTER(0x700452e430ull);
L_700452e430:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e440(Cpu *c) {
    FN_ENTER(0x700452e440ull);
L_700452e440:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e450(Cpu *c) {
    FN_ENTER(0x700452e450ull);
L_700452e450:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e460(Cpu *c) {
    FN_ENTER(0x700452e460ull);
L_700452e460:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e470(Cpu *c) {
    FN_ENTER(0x700452e470ull);
L_700452e470:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e480(Cpu *c) {
    FN_ENTER(0x700452e480ull);
L_700452e480:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e490(Cpu *c) {
    FN_ENTER(0x700452e490ull);
L_700452e490:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e4a0(Cpu *c) {
    FN_ENTER(0x700452e4a0ull);
L_700452e4a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e4b0(Cpu *c) {
    FN_ENTER(0x700452e4b0ull);
L_700452e4b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e4c0(Cpu *c) {
    FN_ENTER(0x700452e4c0ull);
L_700452e4c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e4d0(Cpu *c) {
    FN_ENTER(0x700452e4d0ull);
L_700452e4d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e4e0(Cpu *c) {
    FN_ENTER(0x700452e4e0ull);
L_700452e4e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e4f0(Cpu *c) {
    FN_ENTER(0x700452e4f0ull);
L_700452e4f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e500(Cpu *c) {
    FN_ENTER(0x700452e500ull);
L_700452e500:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e510(Cpu *c) {
    FN_ENTER(0x700452e510ull);
L_700452e510:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e520(Cpu *c) {
    FN_ENTER(0x700452e520ull);
L_700452e520:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e530(Cpu *c) {
    FN_ENTER(0x700452e530ull);
L_700452e530:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e540(Cpu *c) {
    FN_ENTER(0x700452e540ull);
L_700452e540:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e550(Cpu *c) {
    FN_ENTER(0x700452e550ull);
L_700452e550:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e560(Cpu *c) {
    FN_ENTER(0x700452e560ull);
L_700452e560:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e570(Cpu *c) {
    FN_ENTER(0x700452e570ull);
L_700452e570:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e580(Cpu *c) {
    FN_ENTER(0x700452e580ull);
L_700452e580:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e590(Cpu *c) {
    FN_ENTER(0x700452e590ull);
L_700452e590:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e5a0(Cpu *c) {
    FN_ENTER(0x700452e5a0ull);
L_700452e5a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e5b0(Cpu *c) {
    FN_ENTER(0x700452e5b0ull);
L_700452e5b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e5c0(Cpu *c) {
    FN_ENTER(0x700452e5c0ull);
L_700452e5c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e5d0(Cpu *c) {
    FN_ENTER(0x700452e5d0ull);
L_700452e5d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e5e0(Cpu *c) {
    FN_ENTER(0x700452e5e0ull);
L_700452e5e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e5f0(Cpu *c) {
    FN_ENTER(0x700452e5f0ull);
L_700452e5f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e600(Cpu *c) {
    FN_ENTER(0x700452e600ull);
L_700452e600:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e610(Cpu *c) {
    FN_ENTER(0x700452e610ull);
L_700452e610:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e620(Cpu *c) {
    FN_ENTER(0x700452e620ull);
L_700452e620:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e630(Cpu *c) {
    FN_ENTER(0x700452e630ull);
L_700452e630:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e640(Cpu *c) {
    FN_ENTER(0x700452e640ull);
L_700452e640:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e650(Cpu *c) {
    FN_ENTER(0x700452e650ull);
L_700452e650:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e660(Cpu *c) {
    FN_ENTER(0x700452e660ull);
L_700452e660:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e670(Cpu *c) {
    FN_ENTER(0x700452e670ull);
L_700452e670:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e680(Cpu *c) {
    FN_ENTER(0x700452e680ull);
L_700452e680:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e690(Cpu *c) {
    FN_ENTER(0x700452e690ull);
L_700452e690:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e6a0(Cpu *c) {
    FN_ENTER(0x700452e6a0ull);
L_700452e6a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e6b0(Cpu *c) {
    FN_ENTER(0x700452e6b0ull);
L_700452e6b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e6c0(Cpu *c) {
    FN_ENTER(0x700452e6c0ull);
L_700452e6c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e6d0(Cpu *c) {
    FN_ENTER(0x700452e6d0ull);
L_700452e6d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e6e0(Cpu *c) {
    FN_ENTER(0x700452e6e0ull);
L_700452e6e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e6f0(Cpu *c) {
    FN_ENTER(0x700452e6f0ull);
L_700452e6f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e700(Cpu *c) {
    FN_ENTER(0x700452e700ull);
L_700452e700:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e710(Cpu *c) {
    FN_ENTER(0x700452e710ull);
L_700452e710:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e720(Cpu *c) {
    FN_ENTER(0x700452e720ull);
L_700452e720:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e730(Cpu *c) {
    FN_ENTER(0x700452e730ull);
L_700452e730:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e740(Cpu *c) {
    FN_ENTER(0x700452e740ull);
L_700452e740:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e750(Cpu *c) {
    FN_ENTER(0x700452e750ull);
L_700452e750:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e760(Cpu *c) {
    FN_ENTER(0x700452e760ull);
L_700452e760:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e770(Cpu *c) {
    FN_ENTER(0x700452e770ull);
L_700452e770:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e780(Cpu *c) {
    FN_ENTER(0x700452e780ull);
L_700452e780:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e790(Cpu *c) {
    FN_ENTER(0x700452e790ull);
L_700452e790:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e7a0(Cpu *c) {
    FN_ENTER(0x700452e7a0ull);
L_700452e7a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e7b0(Cpu *c) {
    FN_ENTER(0x700452e7b0ull);
L_700452e7b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e7c0(Cpu *c) {
    FN_ENTER(0x700452e7c0ull);
L_700452e7c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e7d0(Cpu *c) {
    FN_ENTER(0x700452e7d0ull);
L_700452e7d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e7e0(Cpu *c) {
    FN_ENTER(0x700452e7e0ull);
L_700452e7e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e7f0(Cpu *c) {
    FN_ENTER(0x700452e7f0ull);
L_700452e7f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e800(Cpu *c) {
    FN_ENTER(0x700452e800ull);
L_700452e800:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e810(Cpu *c) {
    FN_ENTER(0x700452e810ull);
L_700452e810:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e820(Cpu *c) {
    FN_ENTER(0x700452e820ull);
L_700452e820:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e830(Cpu *c) {
    FN_ENTER(0x700452e830ull);
L_700452e830:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e840(Cpu *c) {
    FN_ENTER(0x700452e840ull);
L_700452e840:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e850(Cpu *c) {
    FN_ENTER(0x700452e850ull);
L_700452e850:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e860(Cpu *c) {
    FN_ENTER(0x700452e860ull);
L_700452e860:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e870(Cpu *c) {
    FN_ENTER(0x700452e870ull);
L_700452e870:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e880(Cpu *c) {
    FN_ENTER(0x700452e880ull);
L_700452e880:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e890(Cpu *c) {
    FN_ENTER(0x700452e890ull);
L_700452e890:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e8a0(Cpu *c) {
    FN_ENTER(0x700452e8a0ull);
L_700452e8a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e8b0(Cpu *c) {
    FN_ENTER(0x700452e8b0ull);
L_700452e8b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e8c0(Cpu *c) {
    FN_ENTER(0x700452e8c0ull);
L_700452e8c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e8d0(Cpu *c) {
    FN_ENTER(0x700452e8d0ull);
L_700452e8d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e8e0(Cpu *c) {
    FN_ENTER(0x700452e8e0ull);
L_700452e8e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e8f0(Cpu *c) {
    FN_ENTER(0x700452e8f0ull);
L_700452e8f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e900(Cpu *c) {
    FN_ENTER(0x700452e900ull);
L_700452e900:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e910(Cpu *c) {
    FN_ENTER(0x700452e910ull);
L_700452e910:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e920(Cpu *c) {
    FN_ENTER(0x700452e920ull);
L_700452e920:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e930(Cpu *c) {
    FN_ENTER(0x700452e930ull);
L_700452e930:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e940(Cpu *c) {
    FN_ENTER(0x700452e940ull);
L_700452e940:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e950(Cpu *c) {
    FN_ENTER(0x700452e950ull);
L_700452e950:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e960(Cpu *c) {
    FN_ENTER(0x700452e960ull);
L_700452e960:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e970(Cpu *c) {
    FN_ENTER(0x700452e970ull);
L_700452e970:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e980(Cpu *c) {
    FN_ENTER(0x700452e980ull);
L_700452e980:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e990(Cpu *c) {
    FN_ENTER(0x700452e990ull);
L_700452e990:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e9a0(Cpu *c) {
    FN_ENTER(0x700452e9a0ull);
L_700452e9a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e9b0(Cpu *c) {
    FN_ENTER(0x700452e9b0ull);
L_700452e9b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e9c0(Cpu *c) {
    FN_ENTER(0x700452e9c0ull);
L_700452e9c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e9d0(Cpu *c) {
    FN_ENTER(0x700452e9d0ull);
L_700452e9d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e9e0(Cpu *c) {
    FN_ENTER(0x700452e9e0ull);
L_700452e9e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452e9f0(Cpu *c) {
    FN_ENTER(0x700452e9f0ull);
L_700452e9f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea00(Cpu *c) {
    FN_ENTER(0x700452ea00ull);
L_700452ea00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea10(Cpu *c) {
    FN_ENTER(0x700452ea10ull);
L_700452ea10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea20(Cpu *c) {
    FN_ENTER(0x700452ea20ull);
L_700452ea20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea30(Cpu *c) {
    FN_ENTER(0x700452ea30ull);
L_700452ea30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea40(Cpu *c) {
    FN_ENTER(0x700452ea40ull);
L_700452ea40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea50(Cpu *c) {
    FN_ENTER(0x700452ea50ull);
L_700452ea50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea60(Cpu *c) {
    FN_ENTER(0x700452ea60ull);
L_700452ea60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea70(Cpu *c) {
    FN_ENTER(0x700452ea70ull);
L_700452ea70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea80(Cpu *c) {
    FN_ENTER(0x700452ea80ull);
L_700452ea80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ea90(Cpu *c) {
    FN_ENTER(0x700452ea90ull);
L_700452ea90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eaa0(Cpu *c) {
    FN_ENTER(0x700452eaa0ull);
L_700452eaa0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eab0(Cpu *c) {
    FN_ENTER(0x700452eab0ull);
L_700452eab0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eac0(Cpu *c) {
    FN_ENTER(0x700452eac0ull);
L_700452eac0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ead0(Cpu *c) {
    FN_ENTER(0x700452ead0ull);
L_700452ead0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eae0(Cpu *c) {
    FN_ENTER(0x700452eae0ull);
L_700452eae0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eaf0(Cpu *c) {
    FN_ENTER(0x700452eaf0ull);
L_700452eaf0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb00(Cpu *c) {
    FN_ENTER(0x700452eb00ull);
L_700452eb00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb10(Cpu *c) {
    FN_ENTER(0x700452eb10ull);
L_700452eb10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb20(Cpu *c) {
    FN_ENTER(0x700452eb20ull);
L_700452eb20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb30(Cpu *c) {
    FN_ENTER(0x700452eb30ull);
L_700452eb30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb40(Cpu *c) {
    FN_ENTER(0x700452eb40ull);
L_700452eb40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb50(Cpu *c) {
    FN_ENTER(0x700452eb50ull);
L_700452eb50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb60(Cpu *c) {
    FN_ENTER(0x700452eb60ull);
L_700452eb60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb70(Cpu *c) {
    FN_ENTER(0x700452eb70ull);
L_700452eb70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb80(Cpu *c) {
    FN_ENTER(0x700452eb80ull);
L_700452eb80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eb90(Cpu *c) {
    FN_ENTER(0x700452eb90ull);
L_700452eb90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eba0(Cpu *c) {
    FN_ENTER(0x700452eba0ull);
L_700452eba0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ebb0(Cpu *c) {
    FN_ENTER(0x700452ebb0ull);
L_700452ebb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ebc0(Cpu *c) {
    FN_ENTER(0x700452ebc0ull);
L_700452ebc0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ebd0(Cpu *c) {
    FN_ENTER(0x700452ebd0ull);
L_700452ebd0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ebe0(Cpu *c) {
    FN_ENTER(0x700452ebe0ull);
L_700452ebe0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ebf0(Cpu *c) {
    FN_ENTER(0x700452ebf0ull);
L_700452ebf0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec00(Cpu *c) {
    FN_ENTER(0x700452ec00ull);
L_700452ec00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec10(Cpu *c) {
    FN_ENTER(0x700452ec10ull);
L_700452ec10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec20(Cpu *c) {
    FN_ENTER(0x700452ec20ull);
L_700452ec20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec30(Cpu *c) {
    FN_ENTER(0x700452ec30ull);
L_700452ec30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec40(Cpu *c) {
    FN_ENTER(0x700452ec40ull);
L_700452ec40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec50(Cpu *c) {
    FN_ENTER(0x700452ec50ull);
L_700452ec50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec60(Cpu *c) {
    FN_ENTER(0x700452ec60ull);
L_700452ec60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec70(Cpu *c) {
    FN_ENTER(0x700452ec70ull);
L_700452ec70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec80(Cpu *c) {
    FN_ENTER(0x700452ec80ull);
L_700452ec80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ec90(Cpu *c) {
    FN_ENTER(0x700452ec90ull);
L_700452ec90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eca0(Cpu *c) {
    FN_ENTER(0x700452eca0ull);
L_700452eca0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ecb0(Cpu *c) {
    FN_ENTER(0x700452ecb0ull);
L_700452ecb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ecc0(Cpu *c) {
    FN_ENTER(0x700452ecc0ull);
L_700452ecc0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ecd0(Cpu *c) {
    FN_ENTER(0x700452ecd0ull);
L_700452ecd0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ece0(Cpu *c) {
    FN_ENTER(0x700452ece0ull);
L_700452ece0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ecf0(Cpu *c) {
    FN_ENTER(0x700452ecf0ull);
L_700452ecf0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed00(Cpu *c) {
    FN_ENTER(0x700452ed00ull);
L_700452ed00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed10(Cpu *c) {
    FN_ENTER(0x700452ed10ull);
L_700452ed10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed20(Cpu *c) {
    FN_ENTER(0x700452ed20ull);
L_700452ed20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed30(Cpu *c) {
    FN_ENTER(0x700452ed30ull);
L_700452ed30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed40(Cpu *c) {
    FN_ENTER(0x700452ed40ull);
L_700452ed40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed50(Cpu *c) {
    FN_ENTER(0x700452ed50ull);
L_700452ed50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed60(Cpu *c) {
    FN_ENTER(0x700452ed60ull);
L_700452ed60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed70(Cpu *c) {
    FN_ENTER(0x700452ed70ull);
L_700452ed70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed80(Cpu *c) {
    FN_ENTER(0x700452ed80ull);
L_700452ed80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ed90(Cpu *c) {
    FN_ENTER(0x700452ed90ull);
L_700452ed90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x100ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x100ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eda0(Cpu *c) {
    FN_ENTER(0x700452eda0ull);
L_700452eda0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x108ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x108ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452edb0(Cpu *c) {
    FN_ENTER(0x700452edb0ull);
L_700452edb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x110ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x110ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452edc0(Cpu *c) {
    FN_ENTER(0x700452edc0ull);
L_700452edc0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x118ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x118ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452edd0(Cpu *c) {
    FN_ENTER(0x700452edd0ull);
L_700452edd0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x120ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x120ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ede0(Cpu *c) {
    FN_ENTER(0x700452ede0ull);
L_700452ede0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x128ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x128ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452edf0(Cpu *c) {
    FN_ENTER(0x700452edf0ull);
L_700452edf0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x130ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x130ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee00(Cpu *c) {
    FN_ENTER(0x700452ee00ull);
L_700452ee00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x138ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x138ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee10(Cpu *c) {
    FN_ENTER(0x700452ee10ull);
L_700452ee10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x140ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x140ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee20(Cpu *c) {
    FN_ENTER(0x700452ee20ull);
L_700452ee20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x148ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x148ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee30(Cpu *c) {
    FN_ENTER(0x700452ee30ull);
L_700452ee30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x150ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x150ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee40(Cpu *c) {
    FN_ENTER(0x700452ee40ull);
L_700452ee40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x158ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x158ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee50(Cpu *c) {
    FN_ENTER(0x700452ee50ull);
L_700452ee50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x160ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x160ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee60(Cpu *c) {
    FN_ENTER(0x700452ee60ull);
L_700452ee60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x168ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x168ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee70(Cpu *c) {
    FN_ENTER(0x700452ee70ull);
L_700452ee70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x170ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x170ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee80(Cpu *c) {
    FN_ENTER(0x700452ee80ull);
L_700452ee80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x178ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x178ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ee90(Cpu *c) {
    FN_ENTER(0x700452ee90ull);
L_700452ee90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x180ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x180ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eea0(Cpu *c) {
    FN_ENTER(0x700452eea0ull);
L_700452eea0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x188ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x188ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eeb0(Cpu *c) {
    FN_ENTER(0x700452eeb0ull);
L_700452eeb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x190ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x190ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eec0(Cpu *c) {
    FN_ENTER(0x700452eec0ull);
L_700452eec0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x198ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x198ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eed0(Cpu *c) {
    FN_ENTER(0x700452eed0ull);
L_700452eed0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eee0(Cpu *c) {
    FN_ENTER(0x700452eee0ull);
L_700452eee0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eef0(Cpu *c) {
    FN_ENTER(0x700452eef0ull);
L_700452eef0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef00(Cpu *c) {
    FN_ENTER(0x700452ef00ull);
L_700452ef00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef10(Cpu *c) {
    FN_ENTER(0x700452ef10ull);
L_700452ef10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef20(Cpu *c) {
    FN_ENTER(0x700452ef20ull);
L_700452ef20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef30(Cpu *c) {
    FN_ENTER(0x700452ef30ull);
L_700452ef30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef40(Cpu *c) {
    FN_ENTER(0x700452ef40ull);
L_700452ef40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef50(Cpu *c) {
    FN_ENTER(0x700452ef50ull);
L_700452ef50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef60(Cpu *c) {
    FN_ENTER(0x700452ef60ull);
L_700452ef60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef70(Cpu *c) {
    FN_ENTER(0x700452ef70ull);
L_700452ef70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef80(Cpu *c) {
    FN_ENTER(0x700452ef80ull);
L_700452ef80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x1f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ef90(Cpu *c) {
    FN_ENTER(0x700452ef90ull);
L_700452ef90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x200ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x200ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452efa0(Cpu *c) {
    FN_ENTER(0x700452efa0ull);
L_700452efa0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x208ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x208ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452efb0(Cpu *c) {
    FN_ENTER(0x700452efb0ull);
L_700452efb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x210ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x210ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452efc0(Cpu *c) {
    FN_ENTER(0x700452efc0ull);
L_700452efc0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x218ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x218ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452efd0(Cpu *c) {
    FN_ENTER(0x700452efd0ull);
L_700452efd0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x220ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x220ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452efe0(Cpu *c) {
    FN_ENTER(0x700452efe0ull);
L_700452efe0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x228ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x228ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452eff0(Cpu *c) {
    FN_ENTER(0x700452eff0ull);
L_700452eff0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x230ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x230ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f000(Cpu *c) {
    FN_ENTER(0x700452f000ull);
L_700452f000:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x238ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x238ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f010(Cpu *c) {
    FN_ENTER(0x700452f010ull);
L_700452f010:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x240ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x240ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f020(Cpu *c) {
    FN_ENTER(0x700452f020ull);
L_700452f020:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x248ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x248ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f030(Cpu *c) {
    FN_ENTER(0x700452f030ull);
L_700452f030:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x250ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x250ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f040(Cpu *c) {
    FN_ENTER(0x700452f040ull);
L_700452f040:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x258ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x258ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f050(Cpu *c) {
    FN_ENTER(0x700452f050ull);
L_700452f050:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x260ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x260ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f060(Cpu *c) {
    FN_ENTER(0x700452f060ull);
L_700452f060:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x268ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x268ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f070(Cpu *c) {
    FN_ENTER(0x700452f070ull);
L_700452f070:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x270ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x270ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f080(Cpu *c) {
    FN_ENTER(0x700452f080ull);
L_700452f080:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x278ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x278ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f090(Cpu *c) {
    FN_ENTER(0x700452f090ull);
L_700452f090:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x280ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x280ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f0a0(Cpu *c) {
    FN_ENTER(0x700452f0a0ull);
L_700452f0a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x288ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x288ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f0b0(Cpu *c) {
    FN_ENTER(0x700452f0b0ull);
L_700452f0b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x290ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x290ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f0c0(Cpu *c) {
    FN_ENTER(0x700452f0c0ull);
L_700452f0c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x298ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x298ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f0d0(Cpu *c) {
    FN_ENTER(0x700452f0d0ull);
L_700452f0d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f0e0(Cpu *c) {
    FN_ENTER(0x700452f0e0ull);
L_700452f0e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f0f0(Cpu *c) {
    FN_ENTER(0x700452f0f0ull);
L_700452f0f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f100(Cpu *c) {
    FN_ENTER(0x700452f100ull);
L_700452f100:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f110(Cpu *c) {
    FN_ENTER(0x700452f110ull);
L_700452f110:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f120(Cpu *c) {
    FN_ENTER(0x700452f120ull);
L_700452f120:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f130(Cpu *c) {
    FN_ENTER(0x700452f130ull);
L_700452f130:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f140(Cpu *c) {
    FN_ENTER(0x700452f140ull);
L_700452f140:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f150(Cpu *c) {
    FN_ENTER(0x700452f150ull);
L_700452f150:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f160(Cpu *c) {
    FN_ENTER(0x700452f160ull);
L_700452f160:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f170(Cpu *c) {
    FN_ENTER(0x700452f170ull);
L_700452f170:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f180(Cpu *c) {
    FN_ENTER(0x700452f180ull);
L_700452f180:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x2f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f190(Cpu *c) {
    FN_ENTER(0x700452f190ull);
L_700452f190:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x300ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x300ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f1a0(Cpu *c) {
    FN_ENTER(0x700452f1a0ull);
L_700452f1a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x308ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x308ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f1b0(Cpu *c) {
    FN_ENTER(0x700452f1b0ull);
L_700452f1b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x310ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x310ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f1c0(Cpu *c) {
    FN_ENTER(0x700452f1c0ull);
L_700452f1c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x318ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x318ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f1d0(Cpu *c) {
    FN_ENTER(0x700452f1d0ull);
L_700452f1d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x320ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x320ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f1e0(Cpu *c) {
    FN_ENTER(0x700452f1e0ull);
L_700452f1e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x328ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x328ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f1f0(Cpu *c) {
    FN_ENTER(0x700452f1f0ull);
L_700452f1f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x330ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x330ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f200(Cpu *c) {
    FN_ENTER(0x700452f200ull);
L_700452f200:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x338ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x338ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f210(Cpu *c) {
    FN_ENTER(0x700452f210ull);
L_700452f210:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x340ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x340ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f220(Cpu *c) {
    FN_ENTER(0x700452f220ull);
L_700452f220:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x348ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x348ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f230(Cpu *c) {
    FN_ENTER(0x700452f230ull);
L_700452f230:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x350ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x350ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f240(Cpu *c) {
    FN_ENTER(0x700452f240ull);
L_700452f240:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x358ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x358ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f250(Cpu *c) {
    FN_ENTER(0x700452f250ull);
L_700452f250:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x360ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x360ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f260(Cpu *c) {
    FN_ENTER(0x700452f260ull);
L_700452f260:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x368ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x368ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f270(Cpu *c) {
    FN_ENTER(0x700452f270ull);
L_700452f270:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x370ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x370ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f280(Cpu *c) {
    FN_ENTER(0x700452f280ull);
L_700452f280:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x378ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x378ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f290(Cpu *c) {
    FN_ENTER(0x700452f290ull);
L_700452f290:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x380ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x380ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f2a0(Cpu *c) {
    FN_ENTER(0x700452f2a0ull);
L_700452f2a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x388ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x388ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f2b0(Cpu *c) {
    FN_ENTER(0x700452f2b0ull);
L_700452f2b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x390ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x390ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f2c0(Cpu *c) {
    FN_ENTER(0x700452f2c0ull);
L_700452f2c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x398ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x398ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f2d0(Cpu *c) {
    FN_ENTER(0x700452f2d0ull);
L_700452f2d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f2e0(Cpu *c) {
    FN_ENTER(0x700452f2e0ull);
L_700452f2e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f2f0(Cpu *c) {
    FN_ENTER(0x700452f2f0ull);
L_700452f2f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f300(Cpu *c) {
    FN_ENTER(0x700452f300ull);
L_700452f300:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f310(Cpu *c) {
    FN_ENTER(0x700452f310ull);
L_700452f310:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f320(Cpu *c) {
    FN_ENTER(0x700452f320ull);
L_700452f320:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f330(Cpu *c) {
    FN_ENTER(0x700452f330ull);
L_700452f330:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f340(Cpu *c) {
    FN_ENTER(0x700452f340ull);
L_700452f340:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f350(Cpu *c) {
    FN_ENTER(0x700452f350ull);
L_700452f350:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f360(Cpu *c) {
    FN_ENTER(0x700452f360ull);
L_700452f360:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f370(Cpu *c) {
    FN_ENTER(0x700452f370ull);
L_700452f370:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f380(Cpu *c) {
    FN_ENTER(0x700452f380ull);
L_700452f380:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x3f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f390(Cpu *c) {
    FN_ENTER(0x700452f390ull);
L_700452f390:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x400ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x400ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f3a0(Cpu *c) {
    FN_ENTER(0x700452f3a0ull);
L_700452f3a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x408ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x408ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f3b0(Cpu *c) {
    FN_ENTER(0x700452f3b0ull);
L_700452f3b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x410ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x410ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f3c0(Cpu *c) {
    FN_ENTER(0x700452f3c0ull);
L_700452f3c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x418ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x418ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f3d0(Cpu *c) {
    FN_ENTER(0x700452f3d0ull);
L_700452f3d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x420ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x420ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f3e0(Cpu *c) {
    FN_ENTER(0x700452f3e0ull);
L_700452f3e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x428ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x428ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f3f0(Cpu *c) {
    FN_ENTER(0x700452f3f0ull);
L_700452f3f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x430ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x430ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f400(Cpu *c) {
    FN_ENTER(0x700452f400ull);
L_700452f400:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x438ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x438ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f410(Cpu *c) {
    FN_ENTER(0x700452f410ull);
L_700452f410:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x440ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x440ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f420(Cpu *c) {
    FN_ENTER(0x700452f420ull);
L_700452f420:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x448ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x448ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f430(Cpu *c) {
    FN_ENTER(0x700452f430ull);
L_700452f430:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f440(Cpu *c) {
    FN_ENTER(0x700452f440ull);
L_700452f440:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f450(Cpu *c) {
    FN_ENTER(0x700452f450ull);
L_700452f450:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f460(Cpu *c) {
    FN_ENTER(0x700452f460ull);
L_700452f460:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f470(Cpu *c) {
    FN_ENTER(0x700452f470ull);
L_700452f470:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f480(Cpu *c) {
    FN_ENTER(0x700452f480ull);
L_700452f480:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f490(Cpu *c) {
    FN_ENTER(0x700452f490ull);
L_700452f490:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f4a0(Cpu *c) {
    FN_ENTER(0x700452f4a0ull);
L_700452f4a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f4b0(Cpu *c) {
    FN_ENTER(0x700452f4b0ull);
L_700452f4b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f4c0(Cpu *c) {
    FN_ENTER(0x700452f4c0ull);
L_700452f4c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f4d0(Cpu *c) {
    FN_ENTER(0x700452f4d0ull);
L_700452f4d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f4e0(Cpu *c) {
    FN_ENTER(0x700452f4e0ull);
L_700452f4e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f4f0(Cpu *c) {
    FN_ENTER(0x700452f4f0ull);
L_700452f4f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f500(Cpu *c) {
    FN_ENTER(0x700452f500ull);
L_700452f500:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f510(Cpu *c) {
    FN_ENTER(0x700452f510ull);
L_700452f510:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f520(Cpu *c) {
    FN_ENTER(0x700452f520ull);
L_700452f520:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f530(Cpu *c) {
    FN_ENTER(0x700452f530ull);
L_700452f530:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f540(Cpu *c) {
    FN_ENTER(0x700452f540ull);
L_700452f540:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f550(Cpu *c) {
    FN_ENTER(0x700452f550ull);
L_700452f550:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f560(Cpu *c) {
    FN_ENTER(0x700452f560ull);
L_700452f560:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f570(Cpu *c) {
    FN_ENTER(0x700452f570ull);
L_700452f570:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f580(Cpu *c) {
    FN_ENTER(0x700452f580ull);
L_700452f580:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f590(Cpu *c) {
    FN_ENTER(0x700452f590ull);
L_700452f590:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f5a0(Cpu *c) {
    FN_ENTER(0x700452f5a0ull);
L_700452f5a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f5b0(Cpu *c) {
    FN_ENTER(0x700452f5b0ull);
L_700452f5b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f5c0(Cpu *c) {
    FN_ENTER(0x700452f5c0ull);
L_700452f5c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f5d0(Cpu *c) {
    FN_ENTER(0x700452f5d0ull);
L_700452f5d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f5e0(Cpu *c) {
    FN_ENTER(0x700452f5e0ull);
L_700452f5e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f5f0(Cpu *c) {
    FN_ENTER(0x700452f5f0ull);
L_700452f5f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f600(Cpu *c) {
    FN_ENTER(0x700452f600ull);
L_700452f600:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f610(Cpu *c) {
    FN_ENTER(0x700452f610ull);
L_700452f610:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f620(Cpu *c) {
    FN_ENTER(0x700452f620ull);
L_700452f620:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f630(Cpu *c) {
    FN_ENTER(0x700452f630ull);
L_700452f630:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f640(Cpu *c) {
    FN_ENTER(0x700452f640ull);
L_700452f640:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f650(Cpu *c) {
    FN_ENTER(0x700452f650ull);
L_700452f650:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f660(Cpu *c) {
    FN_ENTER(0x700452f660ull);
L_700452f660:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f670(Cpu *c) {
    FN_ENTER(0x700452f670ull);
L_700452f670:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f680(Cpu *c) {
    FN_ENTER(0x700452f680ull);
L_700452f680:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f690(Cpu *c) {
    FN_ENTER(0x700452f690ull);
L_700452f690:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f6a0(Cpu *c) {
    FN_ENTER(0x700452f6a0ull);
L_700452f6a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f6b0(Cpu *c) {
    FN_ENTER(0x700452f6b0ull);
L_700452f6b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f6c0(Cpu *c) {
    FN_ENTER(0x700452f6c0ull);
L_700452f6c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f6d0(Cpu *c) {
    FN_ENTER(0x700452f6d0ull);
L_700452f6d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f6e0(Cpu *c) {
    FN_ENTER(0x700452f6e0ull);
L_700452f6e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f6f0(Cpu *c) {
    FN_ENTER(0x700452f6f0ull);
L_700452f6f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f700(Cpu *c) {
    FN_ENTER(0x700452f700ull);
L_700452f700:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f710(Cpu *c) {
    FN_ENTER(0x700452f710ull);
L_700452f710:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f720(Cpu *c) {
    FN_ENTER(0x700452f720ull);
L_700452f720:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f730(Cpu *c) {
    FN_ENTER(0x700452f730ull);
L_700452f730:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f740(Cpu *c) {
    FN_ENTER(0x700452f740ull);
L_700452f740:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f750(Cpu *c) {
    FN_ENTER(0x700452f750ull);
L_700452f750:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f760(Cpu *c) {
    FN_ENTER(0x700452f760ull);
L_700452f760:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f770(Cpu *c) {
    FN_ENTER(0x700452f770ull);
L_700452f770:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f780(Cpu *c) {
    FN_ENTER(0x700452f780ull);
L_700452f780:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f790(Cpu *c) {
    FN_ENTER(0x700452f790ull);
L_700452f790:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f7a0(Cpu *c) {
    FN_ENTER(0x700452f7a0ull);
L_700452f7a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f7b0(Cpu *c) {
    FN_ENTER(0x700452f7b0ull);
L_700452f7b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f7c0(Cpu *c) {
    FN_ENTER(0x700452f7c0ull);
L_700452f7c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f7d0(Cpu *c) {
    FN_ENTER(0x700452f7d0ull);
L_700452f7d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f7e0(Cpu *c) {
    FN_ENTER(0x700452f7e0ull);
L_700452f7e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f7f0(Cpu *c) {
    FN_ENTER(0x700452f7f0ull);
L_700452f7f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f800(Cpu *c) {
    FN_ENTER(0x700452f800ull);
L_700452f800:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f810(Cpu *c) {
    FN_ENTER(0x700452f810ull);
L_700452f810:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f820(Cpu *c) {
    FN_ENTER(0x700452f820ull);
L_700452f820:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f830(Cpu *c) {
    FN_ENTER(0x700452f830ull);
L_700452f830:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f840(Cpu *c) {
    FN_ENTER(0x700452f840ull);
L_700452f840:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f850(Cpu *c) {
    FN_ENTER(0x700452f850ull);
L_700452f850:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f860(Cpu *c) {
    FN_ENTER(0x700452f860ull);
L_700452f860:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f870(Cpu *c) {
    FN_ENTER(0x700452f870ull);
L_700452f870:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f880(Cpu *c) {
    FN_ENTER(0x700452f880ull);
L_700452f880:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f890(Cpu *c) {
    FN_ENTER(0x700452f890ull);
L_700452f890:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f8a0(Cpu *c) {
    FN_ENTER(0x700452f8a0ull);
L_700452f8a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f8b0(Cpu *c) {
    FN_ENTER(0x700452f8b0ull);
L_700452f8b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f8c0(Cpu *c) {
    FN_ENTER(0x700452f8c0ull);
L_700452f8c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f8d0(Cpu *c) {
    FN_ENTER(0x700452f8d0ull);
L_700452f8d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f8e0(Cpu *c) {
    FN_ENTER(0x700452f8e0ull);
L_700452f8e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f8f0(Cpu *c) {
    FN_ENTER(0x700452f8f0ull);
L_700452f8f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f900(Cpu *c) {
    FN_ENTER(0x700452f900ull);
L_700452f900:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f910(Cpu *c) {
    FN_ENTER(0x700452f910ull);
L_700452f910:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f920(Cpu *c) {
    FN_ENTER(0x700452f920ull);
L_700452f920:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f930(Cpu *c) {
    FN_ENTER(0x700452f930ull);
L_700452f930:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f940(Cpu *c) {
    FN_ENTER(0x700452f940ull);
L_700452f940:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f950(Cpu *c) {
    FN_ENTER(0x700452f950ull);
L_700452f950:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f960(Cpu *c) {
    FN_ENTER(0x700452f960ull);
L_700452f960:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f970(Cpu *c) {
    FN_ENTER(0x700452f970ull);
L_700452f970:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f980(Cpu *c) {
    FN_ENTER(0x700452f980ull);
L_700452f980:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f990(Cpu *c) {
    FN_ENTER(0x700452f990ull);
L_700452f990:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f9a0(Cpu *c) {
    FN_ENTER(0x700452f9a0ull);
L_700452f9a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f9b0(Cpu *c) {
    FN_ENTER(0x700452f9b0ull);
L_700452f9b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f9c0(Cpu *c) {
    FN_ENTER(0x700452f9c0ull);
L_700452f9c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f9d0(Cpu *c) {
    FN_ENTER(0x700452f9d0ull);
L_700452f9d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f9e0(Cpu *c) {
    FN_ENTER(0x700452f9e0ull);
L_700452f9e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452f9f0(Cpu *c) {
    FN_ENTER(0x700452f9f0ull);
L_700452f9f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa00(Cpu *c) {
    FN_ENTER(0x700452fa00ull);
L_700452fa00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa10(Cpu *c) {
    FN_ENTER(0x700452fa10ull);
L_700452fa10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa20(Cpu *c) {
    FN_ENTER(0x700452fa20ull);
L_700452fa20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa30(Cpu *c) {
    FN_ENTER(0x700452fa30ull);
L_700452fa30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa40(Cpu *c) {
    FN_ENTER(0x700452fa40ull);
L_700452fa40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa50(Cpu *c) {
    FN_ENTER(0x700452fa50ull);
L_700452fa50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa60(Cpu *c) {
    FN_ENTER(0x700452fa60ull);
L_700452fa60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa70(Cpu *c) {
    FN_ENTER(0x700452fa70ull);
L_700452fa70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa80(Cpu *c) {
    FN_ENTER(0x700452fa80ull);
L_700452fa80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fa90(Cpu *c) {
    FN_ENTER(0x700452fa90ull);
L_700452fa90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452faa0(Cpu *c) {
    FN_ENTER(0x700452faa0ull);
L_700452faa0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fab0(Cpu *c) {
    FN_ENTER(0x700452fab0ull);
L_700452fab0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fac0(Cpu *c) {
    FN_ENTER(0x700452fac0ull);
L_700452fac0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fad0(Cpu *c) {
    FN_ENTER(0x700452fad0ull);
L_700452fad0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fae0(Cpu *c) {
    FN_ENTER(0x700452fae0ull);
L_700452fae0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452faf0(Cpu *c) {
    FN_ENTER(0x700452faf0ull);
L_700452faf0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb00(Cpu *c) {
    FN_ENTER(0x700452fb00ull);
L_700452fb00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb10(Cpu *c) {
    FN_ENTER(0x700452fb10ull);
L_700452fb10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb20(Cpu *c) {
    FN_ENTER(0x700452fb20ull);
L_700452fb20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb30(Cpu *c) {
    FN_ENTER(0x700452fb30ull);
L_700452fb30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb40(Cpu *c) {
    FN_ENTER(0x700452fb40ull);
L_700452fb40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb50(Cpu *c) {
    FN_ENTER(0x700452fb50ull);
L_700452fb50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb60(Cpu *c) {
    FN_ENTER(0x700452fb60ull);
L_700452fb60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb70(Cpu *c) {
    FN_ENTER(0x700452fb70ull);
L_700452fb70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb80(Cpu *c) {
    FN_ENTER(0x700452fb80ull);
L_700452fb80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fb90(Cpu *c) {
    FN_ENTER(0x700452fb90ull);
L_700452fb90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fba0(Cpu *c) {
    FN_ENTER(0x700452fba0ull);
L_700452fba0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fbb0(Cpu *c) {
    FN_ENTER(0x700452fbb0ull);
L_700452fbb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fbc0(Cpu *c) {
    FN_ENTER(0x700452fbc0ull);
L_700452fbc0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fbd0(Cpu *c) {
    FN_ENTER(0x700452fbd0ull);
L_700452fbd0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fbe0(Cpu *c) {
    FN_ENTER(0x700452fbe0ull);
L_700452fbe0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fbf0(Cpu *c) {
    FN_ENTER(0x700452fbf0ull);
L_700452fbf0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc00(Cpu *c) {
    FN_ENTER(0x700452fc00ull);
L_700452fc00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc10(Cpu *c) {
    FN_ENTER(0x700452fc10ull);
L_700452fc10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc20(Cpu *c) {
    FN_ENTER(0x700452fc20ull);
L_700452fc20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc30(Cpu *c) {
    FN_ENTER(0x700452fc30ull);
L_700452fc30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc40(Cpu *c) {
    FN_ENTER(0x700452fc40ull);
L_700452fc40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc50(Cpu *c) {
    FN_ENTER(0x700452fc50ull);
L_700452fc50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc60(Cpu *c) {
    FN_ENTER(0x700452fc60ull);
L_700452fc60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc70(Cpu *c) {
    FN_ENTER(0x700452fc70ull);
L_700452fc70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc80(Cpu *c) {
    FN_ENTER(0x700452fc80ull);
L_700452fc80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fc90(Cpu *c) {
    FN_ENTER(0x700452fc90ull);
L_700452fc90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fca0(Cpu *c) {
    FN_ENTER(0x700452fca0ull);
L_700452fca0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fcb0(Cpu *c) {
    FN_ENTER(0x700452fcb0ull);
L_700452fcb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fcc0(Cpu *c) {
    FN_ENTER(0x700452fcc0ull);
L_700452fcc0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fcd0(Cpu *c) {
    FN_ENTER(0x700452fcd0ull);
L_700452fcd0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fce0(Cpu *c) {
    FN_ENTER(0x700452fce0ull);
L_700452fce0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fcf0(Cpu *c) {
    FN_ENTER(0x700452fcf0ull);
L_700452fcf0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd00(Cpu *c) {
    FN_ENTER(0x700452fd00ull);
L_700452fd00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd10(Cpu *c) {
    FN_ENTER(0x700452fd10ull);
L_700452fd10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd20(Cpu *c) {
    FN_ENTER(0x700452fd20ull);
L_700452fd20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd30(Cpu *c) {
    FN_ENTER(0x700452fd30ull);
L_700452fd30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd40(Cpu *c) {
    FN_ENTER(0x700452fd40ull);
L_700452fd40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd50(Cpu *c) {
    FN_ENTER(0x700452fd50ull);
L_700452fd50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd60(Cpu *c) {
    FN_ENTER(0x700452fd60ull);
L_700452fd60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd70(Cpu *c) {
    FN_ENTER(0x700452fd70ull);
L_700452fd70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd80(Cpu *c) {
    FN_ENTER(0x700452fd80ull);
L_700452fd80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fd90(Cpu *c) {
    FN_ENTER(0x700452fd90ull);
L_700452fd90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fda0(Cpu *c) {
    FN_ENTER(0x700452fda0ull);
L_700452fda0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fdb0(Cpu *c) {
    FN_ENTER(0x700452fdb0ull);
L_700452fdb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fdc0(Cpu *c) {
    FN_ENTER(0x700452fdc0ull);
L_700452fdc0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fdd0(Cpu *c) {
    FN_ENTER(0x700452fdd0ull);
L_700452fdd0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fde0(Cpu *c) {
    FN_ENTER(0x700452fde0ull);
L_700452fde0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fdf0(Cpu *c) {
    FN_ENTER(0x700452fdf0ull);
L_700452fdf0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe00(Cpu *c) {
    FN_ENTER(0x700452fe00ull);
L_700452fe00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe10(Cpu *c) {
    FN_ENTER(0x700452fe10ull);
L_700452fe10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe20(Cpu *c) {
    FN_ENTER(0x700452fe20ull);
L_700452fe20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe30(Cpu *c) {
    FN_ENTER(0x700452fe30ull);
L_700452fe30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe40(Cpu *c) {
    FN_ENTER(0x700452fe40ull);
L_700452fe40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe50(Cpu *c) {
    FN_ENTER(0x700452fe50ull);
L_700452fe50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe60(Cpu *c) {
    FN_ENTER(0x700452fe60ull);
L_700452fe60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe70(Cpu *c) {
    FN_ENTER(0x700452fe70ull);
L_700452fe70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe80(Cpu *c) {
    FN_ENTER(0x700452fe80ull);
L_700452fe80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fe90(Cpu *c) {
    FN_ENTER(0x700452fe90ull);
L_700452fe90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fea0(Cpu *c) {
    FN_ENTER(0x700452fea0ull);
L_700452fea0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452feb0(Cpu *c) {
    FN_ENTER(0x700452feb0ull);
L_700452feb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fec0(Cpu *c) {
    FN_ENTER(0x700452fec0ull);
L_700452fec0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fed0(Cpu *c) {
    FN_ENTER(0x700452fed0ull);
L_700452fed0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fee0(Cpu *c) {
    FN_ENTER(0x700452fee0ull);
L_700452fee0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fef0(Cpu *c) {
    FN_ENTER(0x700452fef0ull);
L_700452fef0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff00(Cpu *c) {
    FN_ENTER(0x700452ff00ull);
L_700452ff00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff10(Cpu *c) {
    FN_ENTER(0x700452ff10ull);
L_700452ff10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff20(Cpu *c) {
    FN_ENTER(0x700452ff20ull);
L_700452ff20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff30(Cpu *c) {
    FN_ENTER(0x700452ff30ull);
L_700452ff30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff40(Cpu *c) {
    FN_ENTER(0x700452ff40ull);
L_700452ff40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff50(Cpu *c) {
    FN_ENTER(0x700452ff50ull);
L_700452ff50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff60(Cpu *c) {
    FN_ENTER(0x700452ff60ull);
L_700452ff60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff70(Cpu *c) {
    FN_ENTER(0x700452ff70ull);
L_700452ff70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff80(Cpu *c) {
    FN_ENTER(0x700452ff80ull);
L_700452ff80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ff90(Cpu *c) {
    FN_ENTER(0x700452ff90ull);
L_700452ff90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ffa0(Cpu *c) {
    FN_ENTER(0x700452ffa0ull);
L_700452ffa0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ffb0(Cpu *c) {
    FN_ENTER(0x700452ffb0ull);
L_700452ffb0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ffc0(Cpu *c) {
    FN_ENTER(0x700452ffc0ull);
L_700452ffc0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ffd0(Cpu *c) {
    FN_ENTER(0x700452ffd0ull);
L_700452ffd0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ffe0(Cpu *c) {
    FN_ENTER(0x700452ffe0ull);
L_700452ffe0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452fff0(Cpu *c) {
    FN_ENTER(0x700452fff0ull);
L_700452fff0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530000(Cpu *c) {
    FN_ENTER(0x7004530000ull);
L_7004530000:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530010(Cpu *c) {
    FN_ENTER(0x7004530010ull);
L_7004530010:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530020(Cpu *c) {
    FN_ENTER(0x7004530020ull);
L_7004530020:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530030(Cpu *c) {
    FN_ENTER(0x7004530030ull);
L_7004530030:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530040(Cpu *c) {
    FN_ENTER(0x7004530040ull);
L_7004530040:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530050(Cpu *c) {
    FN_ENTER(0x7004530050ull);
L_7004530050:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530060(Cpu *c) {
    FN_ENTER(0x7004530060ull);
L_7004530060:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530070(Cpu *c) {
    FN_ENTER(0x7004530070ull);
L_7004530070:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530080(Cpu *c) {
    FN_ENTER(0x7004530080ull);
L_7004530080:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530090(Cpu *c) {
    FN_ENTER(0x7004530090ull);
L_7004530090:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045300a0(Cpu *c) {
    FN_ENTER(0x70045300a0ull);
L_70045300a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045300b0(Cpu *c) {
    FN_ENTER(0x70045300b0ull);
L_70045300b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045300c0(Cpu *c) {
    FN_ENTER(0x70045300c0ull);
L_70045300c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045300d0(Cpu *c) {
    FN_ENTER(0x70045300d0ull);
L_70045300d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045300e0(Cpu *c) {
    FN_ENTER(0x70045300e0ull);
L_70045300e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045300f0(Cpu *c) {
    FN_ENTER(0x70045300f0ull);
L_70045300f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530100(Cpu *c) {
    FN_ENTER(0x7004530100ull);
L_7004530100:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530110(Cpu *c) {
    FN_ENTER(0x7004530110ull);
L_7004530110:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530120(Cpu *c) {
    FN_ENTER(0x7004530120ull);
L_7004530120:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530130(Cpu *c) {
    FN_ENTER(0x7004530130ull);
L_7004530130:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530140(Cpu *c) {
    FN_ENTER(0x7004530140ull);
L_7004530140:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530150(Cpu *c) {
    FN_ENTER(0x7004530150ull);
L_7004530150:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530160(Cpu *c) {
    FN_ENTER(0x7004530160ull);
L_7004530160:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530170(Cpu *c) {
    FN_ENTER(0x7004530170ull);
L_7004530170:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530180(Cpu *c) {
    FN_ENTER(0x7004530180ull);
L_7004530180:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530190(Cpu *c) {
    FN_ENTER(0x7004530190ull);
L_7004530190:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045301a0(Cpu *c) {
    FN_ENTER(0x70045301a0ull);
L_70045301a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045301b0(Cpu *c) {
    FN_ENTER(0x70045301b0ull);
L_70045301b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045301c0(Cpu *c) {
    FN_ENTER(0x70045301c0ull);
L_70045301c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045301d0(Cpu *c) {
    FN_ENTER(0x70045301d0ull);
L_70045301d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045301e0(Cpu *c) {
    FN_ENTER(0x70045301e0ull);
L_70045301e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045301f0(Cpu *c) {
    FN_ENTER(0x70045301f0ull);
L_70045301f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530200(Cpu *c) {
    FN_ENTER(0x7004530200ull);
L_7004530200:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530210(Cpu *c) {
    FN_ENTER(0x7004530210ull);
L_7004530210:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530220(Cpu *c) {
    FN_ENTER(0x7004530220ull);
L_7004530220:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530230(Cpu *c) {
    FN_ENTER(0x7004530230ull);
L_7004530230:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530240(Cpu *c) {
    FN_ENTER(0x7004530240ull);
L_7004530240:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530250(Cpu *c) {
    FN_ENTER(0x7004530250ull);
L_7004530250:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530260(Cpu *c) {
    FN_ENTER(0x7004530260ull);
L_7004530260:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530270(Cpu *c) {
    FN_ENTER(0x7004530270ull);
L_7004530270:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530280(Cpu *c) {
    FN_ENTER(0x7004530280ull);
L_7004530280:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530290(Cpu *c) {
    FN_ENTER(0x7004530290ull);
L_7004530290:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045302a0(Cpu *c) {
    FN_ENTER(0x70045302a0ull);
L_70045302a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045302b0(Cpu *c) {
    FN_ENTER(0x70045302b0ull);
L_70045302b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045302c0(Cpu *c) {
    FN_ENTER(0x70045302c0ull);
L_70045302c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045302d0(Cpu *c) {
    FN_ENTER(0x70045302d0ull);
L_70045302d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045302e0(Cpu *c) {
    FN_ENTER(0x70045302e0ull);
L_70045302e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045302f0(Cpu *c) {
    FN_ENTER(0x70045302f0ull);
L_70045302f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530300(Cpu *c) {
    FN_ENTER(0x7004530300ull);
L_7004530300:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530310(Cpu *c) {
    FN_ENTER(0x7004530310ull);
L_7004530310:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530320(Cpu *c) {
    FN_ENTER(0x7004530320ull);
L_7004530320:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530330(Cpu *c) {
    FN_ENTER(0x7004530330ull);
L_7004530330:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530340(Cpu *c) {
    FN_ENTER(0x7004530340ull);
L_7004530340:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530350(Cpu *c) {
    FN_ENTER(0x7004530350ull);
L_7004530350:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530360(Cpu *c) {
    FN_ENTER(0x7004530360ull);
L_7004530360:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530370(Cpu *c) {
    FN_ENTER(0x7004530370ull);
L_7004530370:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530380(Cpu *c) {
    FN_ENTER(0x7004530380ull);
L_7004530380:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530390(Cpu *c) {
    FN_ENTER(0x7004530390ull);
L_7004530390:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045303a0(Cpu *c) {
    FN_ENTER(0x70045303a0ull);
L_70045303a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045303b0(Cpu *c) {
    FN_ENTER(0x70045303b0ull);
L_70045303b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045303c0(Cpu *c) {
    FN_ENTER(0x70045303c0ull);
L_70045303c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045303d0(Cpu *c) {
    FN_ENTER(0x70045303d0ull);
L_70045303d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045303e0(Cpu *c) {
    FN_ENTER(0x70045303e0ull);
L_70045303e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045303f0(Cpu *c) {
    FN_ENTER(0x70045303f0ull);
L_70045303f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530400(Cpu *c) {
    FN_ENTER(0x7004530400ull);
L_7004530400:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530410(Cpu *c) {
    FN_ENTER(0x7004530410ull);
L_7004530410:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530420(Cpu *c) {
    FN_ENTER(0x7004530420ull);
L_7004530420:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530430(Cpu *c) {
    FN_ENTER(0x7004530430ull);
L_7004530430:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530440(Cpu *c) {
    FN_ENTER(0x7004530440ull);
L_7004530440:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530450(Cpu *c) {
    FN_ENTER(0x7004530450ull);
L_7004530450:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530460(Cpu *c) {
    FN_ENTER(0x7004530460ull);
L_7004530460:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530470(Cpu *c) {
    FN_ENTER(0x7004530470ull);
L_7004530470:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530480(Cpu *c) {
    FN_ENTER(0x7004530480ull);
L_7004530480:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530490(Cpu *c) {
    FN_ENTER(0x7004530490ull);
L_7004530490:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045304a0(Cpu *c) {
    FN_ENTER(0x70045304a0ull);
L_70045304a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045304b0(Cpu *c) {
    FN_ENTER(0x70045304b0ull);
L_70045304b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045304c0(Cpu *c) {
    FN_ENTER(0x70045304c0ull);
L_70045304c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045304d0(Cpu *c) {
    FN_ENTER(0x70045304d0ull);
L_70045304d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045304e0(Cpu *c) {
    FN_ENTER(0x70045304e0ull);
L_70045304e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045304f0(Cpu *c) {
    FN_ENTER(0x70045304f0ull);
L_70045304f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530500(Cpu *c) {
    FN_ENTER(0x7004530500ull);
L_7004530500:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530510(Cpu *c) {
    FN_ENTER(0x7004530510ull);
L_7004530510:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530520(Cpu *c) {
    FN_ENTER(0x7004530520ull);
L_7004530520:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530530(Cpu *c) {
    FN_ENTER(0x7004530530ull);
L_7004530530:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530540(Cpu *c) {
    FN_ENTER(0x7004530540ull);
L_7004530540:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530550(Cpu *c) {
    FN_ENTER(0x7004530550ull);
L_7004530550:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530560(Cpu *c) {
    FN_ENTER(0x7004530560ull);
L_7004530560:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530570(Cpu *c) {
    FN_ENTER(0x7004530570ull);
L_7004530570:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530580(Cpu *c) {
    FN_ENTER(0x7004530580ull);
L_7004530580:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530590(Cpu *c) {
    FN_ENTER(0x7004530590ull);
L_7004530590:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045305a0(Cpu *c) {
    FN_ENTER(0x70045305a0ull);
L_70045305a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045305b0(Cpu *c) {
    FN_ENTER(0x70045305b0ull);
L_70045305b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045305c0(Cpu *c) {
    FN_ENTER(0x70045305c0ull);
L_70045305c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045305d0(Cpu *c) {
    FN_ENTER(0x70045305d0ull);
L_70045305d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045305e0(Cpu *c) {
    FN_ENTER(0x70045305e0ull);
L_70045305e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045305f0(Cpu *c) {
    FN_ENTER(0x70045305f0ull);
L_70045305f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530600(Cpu *c) {
    FN_ENTER(0x7004530600ull);
L_7004530600:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530610(Cpu *c) {
    FN_ENTER(0x7004530610ull);
L_7004530610:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530620(Cpu *c) {
    FN_ENTER(0x7004530620ull);
L_7004530620:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530630(Cpu *c) {
    FN_ENTER(0x7004530630ull);
L_7004530630:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530640(Cpu *c) {
    FN_ENTER(0x7004530640ull);
L_7004530640:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530650(Cpu *c) {
    FN_ENTER(0x7004530650ull);
L_7004530650:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530660(Cpu *c) {
    FN_ENTER(0x7004530660ull);
L_7004530660:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530670(Cpu *c) {
    FN_ENTER(0x7004530670ull);
L_7004530670:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530680(Cpu *c) {
    FN_ENTER(0x7004530680ull);
L_7004530680:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530690(Cpu *c) {
    FN_ENTER(0x7004530690ull);
L_7004530690:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045306a0(Cpu *c) {
    FN_ENTER(0x70045306a0ull);
L_70045306a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045306b0(Cpu *c) {
    FN_ENTER(0x70045306b0ull);
L_70045306b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045306c0(Cpu *c) {
    FN_ENTER(0x70045306c0ull);
L_70045306c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045306d0(Cpu *c) {
    FN_ENTER(0x70045306d0ull);
L_70045306d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045306e0(Cpu *c) {
    FN_ENTER(0x70045306e0ull);
L_70045306e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045306f0(Cpu *c) {
    FN_ENTER(0x70045306f0ull);
L_70045306f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530700(Cpu *c) {
    FN_ENTER(0x7004530700ull);
L_7004530700:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530710(Cpu *c) {
    FN_ENTER(0x7004530710ull);
L_7004530710:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530720(Cpu *c) {
    FN_ENTER(0x7004530720ull);
L_7004530720:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530730(Cpu *c) {
    FN_ENTER(0x7004530730ull);
L_7004530730:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530740(Cpu *c) {
    FN_ENTER(0x7004530740ull);
L_7004530740:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530750(Cpu *c) {
    FN_ENTER(0x7004530750ull);
L_7004530750:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530760(Cpu *c) {
    FN_ENTER(0x7004530760ull);
L_7004530760:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530770(Cpu *c) {
    FN_ENTER(0x7004530770ull);
L_7004530770:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530780(Cpu *c) {
    FN_ENTER(0x7004530780ull);
L_7004530780:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530790(Cpu *c) {
    FN_ENTER(0x7004530790ull);
L_7004530790:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045307a0(Cpu *c) {
    FN_ENTER(0x70045307a0ull);
L_70045307a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045307b0(Cpu *c) {
    FN_ENTER(0x70045307b0ull);
L_70045307b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045307c0(Cpu *c) {
    FN_ENTER(0x70045307c0ull);
L_70045307c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045307d0(Cpu *c) {
    FN_ENTER(0x70045307d0ull);
L_70045307d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045307e0(Cpu *c) {
    FN_ENTER(0x70045307e0ull);
L_70045307e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045307f0(Cpu *c) {
    FN_ENTER(0x70045307f0ull);
L_70045307f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530800(Cpu *c) {
    FN_ENTER(0x7004530800ull);
L_7004530800:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530810(Cpu *c) {
    FN_ENTER(0x7004530810ull);
L_7004530810:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530820(Cpu *c) {
    FN_ENTER(0x7004530820ull);
L_7004530820:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530830(Cpu *c) {
    FN_ENTER(0x7004530830ull);
L_7004530830:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530840(Cpu *c) {
    FN_ENTER(0x7004530840ull);
L_7004530840:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530850(Cpu *c) {
    FN_ENTER(0x7004530850ull);
L_7004530850:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530860(Cpu *c) {
    FN_ENTER(0x7004530860ull);
L_7004530860:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530870(Cpu *c) {
    FN_ENTER(0x7004530870ull);
L_7004530870:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530880(Cpu *c) {
    FN_ENTER(0x7004530880ull);
L_7004530880:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530890(Cpu *c) {
    FN_ENTER(0x7004530890ull);
L_7004530890:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045308a0(Cpu *c) {
    FN_ENTER(0x70045308a0ull);
L_70045308a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045308b0(Cpu *c) {
    FN_ENTER(0x70045308b0ull);
L_70045308b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045308c0(Cpu *c) {
    FN_ENTER(0x70045308c0ull);
L_70045308c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045308d0(Cpu *c) {
    FN_ENTER(0x70045308d0ull);
L_70045308d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045308e0(Cpu *c) {
    FN_ENTER(0x70045308e0ull);
L_70045308e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045308f0(Cpu *c) {
    FN_ENTER(0x70045308f0ull);
L_70045308f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530900(Cpu *c) {
    FN_ENTER(0x7004530900ull);
L_7004530900:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530910(Cpu *c) {
    FN_ENTER(0x7004530910ull);
L_7004530910:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530920(Cpu *c) {
    FN_ENTER(0x7004530920ull);
L_7004530920:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530930(Cpu *c) {
    FN_ENTER(0x7004530930ull);
L_7004530930:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530940(Cpu *c) {
    FN_ENTER(0x7004530940ull);
L_7004530940:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530950(Cpu *c) {
    FN_ENTER(0x7004530950ull);
L_7004530950:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530960(Cpu *c) {
    FN_ENTER(0x7004530960ull);
L_7004530960:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530970(Cpu *c) {
    FN_ENTER(0x7004530970ull);
L_7004530970:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530980(Cpu *c) {
    FN_ENTER(0x7004530980ull);
L_7004530980:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530990(Cpu *c) {
    FN_ENTER(0x7004530990ull);
L_7004530990:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045309a0(Cpu *c) {
    FN_ENTER(0x70045309a0ull);
L_70045309a0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045309b0(Cpu *c) {
    FN_ENTER(0x70045309b0ull);
L_70045309b0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045309c0(Cpu *c) {
    FN_ENTER(0x70045309c0ull);
L_70045309c0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045309d0(Cpu *c) {
    FN_ENTER(0x70045309d0ull);
L_70045309d0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045309e0(Cpu *c) {
    FN_ENTER(0x70045309e0ull);
L_70045309e0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045309f0(Cpu *c) {
    FN_ENTER(0x70045309f0ull);
L_70045309f0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a00(Cpu *c) {
    FN_ENTER(0x7004530a00ull);
L_7004530a00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a10(Cpu *c) {
    FN_ENTER(0x7004530a10ull);
L_7004530a10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a20(Cpu *c) {
    FN_ENTER(0x7004530a20ull);
L_7004530a20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a30(Cpu *c) {
    FN_ENTER(0x7004530a30ull);
L_7004530a30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a40(Cpu *c) {
    FN_ENTER(0x7004530a40ull);
L_7004530a40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a50(Cpu *c) {
    FN_ENTER(0x7004530a50ull);
L_7004530a50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a60(Cpu *c) {
    FN_ENTER(0x7004530a60ull);
L_7004530a60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a70(Cpu *c) {
    FN_ENTER(0x7004530a70ull);
L_7004530a70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a80(Cpu *c) {
    FN_ENTER(0x7004530a80ull);
L_7004530a80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530a90(Cpu *c) {
    FN_ENTER(0x7004530a90ull);
L_7004530a90:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530aa0(Cpu *c) {
    FN_ENTER(0x7004530aa0ull);
L_7004530aa0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ab0(Cpu *c) {
    FN_ENTER(0x7004530ab0ull);
L_7004530ab0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ac0(Cpu *c) {
    FN_ENTER(0x7004530ac0ull);
L_7004530ac0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ad0(Cpu *c) {
    FN_ENTER(0x7004530ad0ull);
L_7004530ad0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ae0(Cpu *c) {
    FN_ENTER(0x7004530ae0ull);
L_7004530ae0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530af0(Cpu *c) {
    FN_ENTER(0x7004530af0ull);
L_7004530af0:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b00(Cpu *c) {
    FN_ENTER(0x7004530b00ull);
L_7004530b00:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b10(Cpu *c) {
    FN_ENTER(0x7004530b10ull);
L_7004530b10:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b20(Cpu *c) {
    FN_ENTER(0x7004530b20ull);
L_7004530b20:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b30(Cpu *c) {
    FN_ENTER(0x7004530b30ull);
L_7004530b30:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b40(Cpu *c) {
    FN_ENTER(0x7004530b40ull);
L_7004530b40:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b50(Cpu *c) {
    FN_ENTER(0x7004530b50ull);
L_7004530b50:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b60(Cpu *c) {
    FN_ENTER(0x7004530b60ull);
L_7004530b60:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b70(Cpu *c) {
    FN_ENTER(0x7004530b70ull);
L_7004530b70:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b80(Cpu *c) {
    FN_ENTER(0x7004530b80ull);
L_7004530b80:;
    c->x[16] = (uint64_t)(0x7004c30000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530b90(Cpu *c) {
    FN_ENTER(0x7004530b90ull);
L_7004530b90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ba0(Cpu *c) {
    FN_ENTER(0x7004530ba0ull);
L_7004530ba0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530bb0(Cpu *c) {
    FN_ENTER(0x7004530bb0ull);
L_7004530bb0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530bc0(Cpu *c) {
    FN_ENTER(0x7004530bc0ull);
L_7004530bc0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530bd0(Cpu *c) {
    FN_ENTER(0x7004530bd0ull);
L_7004530bd0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530be0(Cpu *c) {
    FN_ENTER(0x7004530be0ull);
L_7004530be0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530bf0(Cpu *c) {
    FN_ENTER(0x7004530bf0ull);
L_7004530bf0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c00(Cpu *c) {
    FN_ENTER(0x7004530c00ull);
L_7004530c00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c10(Cpu *c) {
    FN_ENTER(0x7004530c10ull);
L_7004530c10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c20(Cpu *c) {
    FN_ENTER(0x7004530c20ull);
L_7004530c20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c30(Cpu *c) {
    FN_ENTER(0x7004530c30ull);
L_7004530c30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c40(Cpu *c) {
    FN_ENTER(0x7004530c40ull);
L_7004530c40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c50(Cpu *c) {
    FN_ENTER(0x7004530c50ull);
L_7004530c50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c60(Cpu *c) {
    FN_ENTER(0x7004530c60ull);
L_7004530c60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c70(Cpu *c) {
    FN_ENTER(0x7004530c70ull);
L_7004530c70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c80(Cpu *c) {
    FN_ENTER(0x7004530c80ull);
L_7004530c80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530c90(Cpu *c) {
    FN_ENTER(0x7004530c90ull);
L_7004530c90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ca0(Cpu *c) {
    FN_ENTER(0x7004530ca0ull);
L_7004530ca0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530cb0(Cpu *c) {
    FN_ENTER(0x7004530cb0ull);
L_7004530cb0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530cc0(Cpu *c) {
    FN_ENTER(0x7004530cc0ull);
L_7004530cc0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530cd0(Cpu *c) {
    FN_ENTER(0x7004530cd0ull);
L_7004530cd0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ce0(Cpu *c) {
    FN_ENTER(0x7004530ce0ull);
L_7004530ce0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530cf0(Cpu *c) {
    FN_ENTER(0x7004530cf0ull);
L_7004530cf0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d00(Cpu *c) {
    FN_ENTER(0x7004530d00ull);
L_7004530d00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d10(Cpu *c) {
    FN_ENTER(0x7004530d10ull);
L_7004530d10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d20(Cpu *c) {
    FN_ENTER(0x7004530d20ull);
L_7004530d20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d30(Cpu *c) {
    FN_ENTER(0x7004530d30ull);
L_7004530d30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d40(Cpu *c) {
    FN_ENTER(0x7004530d40ull);
L_7004530d40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d50(Cpu *c) {
    FN_ENTER(0x7004530d50ull);
L_7004530d50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d60(Cpu *c) {
    FN_ENTER(0x7004530d60ull);
L_7004530d60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d70(Cpu *c) {
    FN_ENTER(0x7004530d70ull);
L_7004530d70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d80(Cpu *c) {
    FN_ENTER(0x7004530d80ull);
L_7004530d80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530d90(Cpu *c) {
    FN_ENTER(0x7004530d90ull);
L_7004530d90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x100ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x100ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530da0(Cpu *c) {
    FN_ENTER(0x7004530da0ull);
L_7004530da0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x108ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x108ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530db0(Cpu *c) {
    FN_ENTER(0x7004530db0ull);
L_7004530db0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x110ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x110ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530dc0(Cpu *c) {
    FN_ENTER(0x7004530dc0ull);
L_7004530dc0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x118ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x118ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530dd0(Cpu *c) {
    FN_ENTER(0x7004530dd0ull);
L_7004530dd0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x120ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x120ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530de0(Cpu *c) {
    FN_ENTER(0x7004530de0ull);
L_7004530de0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x128ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x128ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530df0(Cpu *c) {
    FN_ENTER(0x7004530df0ull);
L_7004530df0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x130ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x130ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e00(Cpu *c) {
    FN_ENTER(0x7004530e00ull);
L_7004530e00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x138ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x138ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e10(Cpu *c) {
    FN_ENTER(0x7004530e10ull);
L_7004530e10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x140ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x140ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e20(Cpu *c) {
    FN_ENTER(0x7004530e20ull);
L_7004530e20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x148ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x148ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e30(Cpu *c) {
    FN_ENTER(0x7004530e30ull);
L_7004530e30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x150ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x150ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e40(Cpu *c) {
    FN_ENTER(0x7004530e40ull);
L_7004530e40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x158ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x158ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e50(Cpu *c) {
    FN_ENTER(0x7004530e50ull);
L_7004530e50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x160ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x160ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e60(Cpu *c) {
    FN_ENTER(0x7004530e60ull);
L_7004530e60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x168ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x168ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e70(Cpu *c) {
    FN_ENTER(0x7004530e70ull);
L_7004530e70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x170ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x170ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e80(Cpu *c) {
    FN_ENTER(0x7004530e80ull);
L_7004530e80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x178ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x178ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530e90(Cpu *c) {
    FN_ENTER(0x7004530e90ull);
L_7004530e90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x180ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x180ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ea0(Cpu *c) {
    FN_ENTER(0x7004530ea0ull);
L_7004530ea0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x188ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x188ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530eb0(Cpu *c) {
    FN_ENTER(0x7004530eb0ull);
L_7004530eb0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x190ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x190ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ec0(Cpu *c) {
    FN_ENTER(0x7004530ec0ull);
L_7004530ec0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x198ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x198ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ed0(Cpu *c) {
    FN_ENTER(0x7004530ed0ull);
L_7004530ed0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ee0(Cpu *c) {
    FN_ENTER(0x7004530ee0ull);
L_7004530ee0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ef0(Cpu *c) {
    FN_ENTER(0x7004530ef0ull);
L_7004530ef0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f00(Cpu *c) {
    FN_ENTER(0x7004530f00ull);
L_7004530f00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f10(Cpu *c) {
    FN_ENTER(0x7004530f10ull);
L_7004530f10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f20(Cpu *c) {
    FN_ENTER(0x7004530f20ull);
L_7004530f20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f30(Cpu *c) {
    FN_ENTER(0x7004530f30ull);
L_7004530f30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f40(Cpu *c) {
    FN_ENTER(0x7004530f40ull);
L_7004530f40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f50(Cpu *c) {
    FN_ENTER(0x7004530f50ull);
L_7004530f50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f60(Cpu *c) {
    FN_ENTER(0x7004530f60ull);
L_7004530f60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f70(Cpu *c) {
    FN_ENTER(0x7004530f70ull);
L_7004530f70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f80(Cpu *c) {
    FN_ENTER(0x7004530f80ull);
L_7004530f80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x1f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530f90(Cpu *c) {
    FN_ENTER(0x7004530f90ull);
L_7004530f90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x200ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x200ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530fa0(Cpu *c) {
    FN_ENTER(0x7004530fa0ull);
L_7004530fa0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x208ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x208ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530fb0(Cpu *c) {
    FN_ENTER(0x7004530fb0ull);
L_7004530fb0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x210ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x210ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530fc0(Cpu *c) {
    FN_ENTER(0x7004530fc0ull);
L_7004530fc0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x218ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x218ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530fd0(Cpu *c) {
    FN_ENTER(0x7004530fd0ull);
L_7004530fd0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x220ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x220ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530fe0(Cpu *c) {
    FN_ENTER(0x7004530fe0ull);
L_7004530fe0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x228ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x228ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004530ff0(Cpu *c) {
    FN_ENTER(0x7004530ff0ull);
L_7004530ff0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x230ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x230ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531000(Cpu *c) {
    FN_ENTER(0x7004531000ull);
L_7004531000:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x238ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x238ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531010(Cpu *c) {
    FN_ENTER(0x7004531010ull);
L_7004531010:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x240ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x240ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531020(Cpu *c) {
    FN_ENTER(0x7004531020ull);
L_7004531020:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x248ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x248ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531030(Cpu *c) {
    FN_ENTER(0x7004531030ull);
L_7004531030:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x250ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x250ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531040(Cpu *c) {
    FN_ENTER(0x7004531040ull);
L_7004531040:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x258ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x258ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531050(Cpu *c) {
    FN_ENTER(0x7004531050ull);
L_7004531050:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x260ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x260ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531060(Cpu *c) {
    FN_ENTER(0x7004531060ull);
L_7004531060:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x268ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x268ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531070(Cpu *c) {
    FN_ENTER(0x7004531070ull);
L_7004531070:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x270ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x270ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531080(Cpu *c) {
    FN_ENTER(0x7004531080ull);
L_7004531080:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x278ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x278ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531090(Cpu *c) {
    FN_ENTER(0x7004531090ull);
L_7004531090:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x280ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x280ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045310a0(Cpu *c) {
    FN_ENTER(0x70045310a0ull);
L_70045310a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x288ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x288ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045310b0(Cpu *c) {
    FN_ENTER(0x70045310b0ull);
L_70045310b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x290ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x290ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045310c0(Cpu *c) {
    FN_ENTER(0x70045310c0ull);
L_70045310c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x298ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x298ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045310d0(Cpu *c) {
    FN_ENTER(0x70045310d0ull);
L_70045310d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045310e0(Cpu *c) {
    FN_ENTER(0x70045310e0ull);
L_70045310e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045310f0(Cpu *c) {
    FN_ENTER(0x70045310f0ull);
L_70045310f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531100(Cpu *c) {
    FN_ENTER(0x7004531100ull);
L_7004531100:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531110(Cpu *c) {
    FN_ENTER(0x7004531110ull);
L_7004531110:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531120(Cpu *c) {
    FN_ENTER(0x7004531120ull);
L_7004531120:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531130(Cpu *c) {
    FN_ENTER(0x7004531130ull);
L_7004531130:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531140(Cpu *c) {
    FN_ENTER(0x7004531140ull);
L_7004531140:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531150(Cpu *c) {
    FN_ENTER(0x7004531150ull);
L_7004531150:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531160(Cpu *c) {
    FN_ENTER(0x7004531160ull);
L_7004531160:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531170(Cpu *c) {
    FN_ENTER(0x7004531170ull);
L_7004531170:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531180(Cpu *c) {
    FN_ENTER(0x7004531180ull);
L_7004531180:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x2f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531190(Cpu *c) {
    FN_ENTER(0x7004531190ull);
L_7004531190:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x300ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x300ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045311a0(Cpu *c) {
    FN_ENTER(0x70045311a0ull);
L_70045311a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x308ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x308ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045311b0(Cpu *c) {
    FN_ENTER(0x70045311b0ull);
L_70045311b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x310ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x310ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045311c0(Cpu *c) {
    FN_ENTER(0x70045311c0ull);
L_70045311c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x318ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x318ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045311d0(Cpu *c) {
    FN_ENTER(0x70045311d0ull);
L_70045311d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x320ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x320ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045311e0(Cpu *c) {
    FN_ENTER(0x70045311e0ull);
L_70045311e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x328ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x328ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045311f0(Cpu *c) {
    FN_ENTER(0x70045311f0ull);
L_70045311f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x330ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x330ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531200(Cpu *c) {
    FN_ENTER(0x7004531200ull);
L_7004531200:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x338ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x338ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531210(Cpu *c) {
    FN_ENTER(0x7004531210ull);
L_7004531210:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x340ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x340ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531220(Cpu *c) {
    FN_ENTER(0x7004531220ull);
L_7004531220:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x348ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x348ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531230(Cpu *c) {
    FN_ENTER(0x7004531230ull);
L_7004531230:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x350ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x350ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531240(Cpu *c) {
    FN_ENTER(0x7004531240ull);
L_7004531240:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x358ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x358ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531250(Cpu *c) {
    FN_ENTER(0x7004531250ull);
L_7004531250:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x360ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x360ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531260(Cpu *c) {
    FN_ENTER(0x7004531260ull);
L_7004531260:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x368ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x368ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531270(Cpu *c) {
    FN_ENTER(0x7004531270ull);
L_7004531270:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x370ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x370ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531280(Cpu *c) {
    FN_ENTER(0x7004531280ull);
L_7004531280:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x378ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x378ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531290(Cpu *c) {
    FN_ENTER(0x7004531290ull);
L_7004531290:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x380ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x380ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045312a0(Cpu *c) {
    FN_ENTER(0x70045312a0ull);
L_70045312a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x388ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x388ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045312b0(Cpu *c) {
    FN_ENTER(0x70045312b0ull);
L_70045312b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x390ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x390ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045312c0(Cpu *c) {
    FN_ENTER(0x70045312c0ull);
L_70045312c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x398ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x398ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045312d0(Cpu *c) {
    FN_ENTER(0x70045312d0ull);
L_70045312d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045312e0(Cpu *c) {
    FN_ENTER(0x70045312e0ull);
L_70045312e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045312f0(Cpu *c) {
    FN_ENTER(0x70045312f0ull);
L_70045312f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531300(Cpu *c) {
    FN_ENTER(0x7004531300ull);
L_7004531300:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531310(Cpu *c) {
    FN_ENTER(0x7004531310ull);
L_7004531310:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531320(Cpu *c) {
    FN_ENTER(0x7004531320ull);
L_7004531320:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531330(Cpu *c) {
    FN_ENTER(0x7004531330ull);
L_7004531330:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531340(Cpu *c) {
    FN_ENTER(0x7004531340ull);
L_7004531340:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531350(Cpu *c) {
    FN_ENTER(0x7004531350ull);
L_7004531350:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531360(Cpu *c) {
    FN_ENTER(0x7004531360ull);
L_7004531360:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531370(Cpu *c) {
    FN_ENTER(0x7004531370ull);
L_7004531370:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531380(Cpu *c) {
    FN_ENTER(0x7004531380ull);
L_7004531380:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x3f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531390(Cpu *c) {
    FN_ENTER(0x7004531390ull);
L_7004531390:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x400ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x400ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045313a0(Cpu *c) {
    FN_ENTER(0x70045313a0ull);
L_70045313a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x408ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x408ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045313b0(Cpu *c) {
    FN_ENTER(0x70045313b0ull);
L_70045313b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x410ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x410ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045313c0(Cpu *c) {
    FN_ENTER(0x70045313c0ull);
L_70045313c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x418ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x418ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045313d0(Cpu *c) {
    FN_ENTER(0x70045313d0ull);
L_70045313d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x420ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x420ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045313e0(Cpu *c) {
    FN_ENTER(0x70045313e0ull);
L_70045313e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x428ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x428ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045313f0(Cpu *c) {
    FN_ENTER(0x70045313f0ull);
L_70045313f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x430ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x430ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531400(Cpu *c) {
    FN_ENTER(0x7004531400ull);
L_7004531400:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x438ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x438ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531410(Cpu *c) {
    FN_ENTER(0x7004531410ull);
L_7004531410:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x440ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x440ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531420(Cpu *c) {
    FN_ENTER(0x7004531420ull);
L_7004531420:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x448ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x448ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531430(Cpu *c) {
    FN_ENTER(0x7004531430ull);
L_7004531430:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531440(Cpu *c) {
    FN_ENTER(0x7004531440ull);
L_7004531440:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531450(Cpu *c) {
    FN_ENTER(0x7004531450ull);
L_7004531450:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531460(Cpu *c) {
    FN_ENTER(0x7004531460ull);
L_7004531460:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531470(Cpu *c) {
    FN_ENTER(0x7004531470ull);
L_7004531470:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531480(Cpu *c) {
    FN_ENTER(0x7004531480ull);
L_7004531480:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531490(Cpu *c) {
    FN_ENTER(0x7004531490ull);
L_7004531490:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045314a0(Cpu *c) {
    FN_ENTER(0x70045314a0ull);
L_70045314a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045314b0(Cpu *c) {
    FN_ENTER(0x70045314b0ull);
L_70045314b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045314c0(Cpu *c) {
    FN_ENTER(0x70045314c0ull);
L_70045314c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045314d0(Cpu *c) {
    FN_ENTER(0x70045314d0ull);
L_70045314d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045314e0(Cpu *c) {
    FN_ENTER(0x70045314e0ull);
L_70045314e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045314f0(Cpu *c) {
    FN_ENTER(0x70045314f0ull);
L_70045314f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531500(Cpu *c) {
    FN_ENTER(0x7004531500ull);
L_7004531500:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531510(Cpu *c) {
    FN_ENTER(0x7004531510ull);
L_7004531510:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531520(Cpu *c) {
    FN_ENTER(0x7004531520ull);
L_7004531520:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531530(Cpu *c) {
    FN_ENTER(0x7004531530ull);
L_7004531530:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531540(Cpu *c) {
    FN_ENTER(0x7004531540ull);
L_7004531540:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531550(Cpu *c) {
    FN_ENTER(0x7004531550ull);
L_7004531550:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531560(Cpu *c) {
    FN_ENTER(0x7004531560ull);
L_7004531560:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531570(Cpu *c) {
    FN_ENTER(0x7004531570ull);
L_7004531570:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531580(Cpu *c) {
    FN_ENTER(0x7004531580ull);
L_7004531580:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531590(Cpu *c) {
    FN_ENTER(0x7004531590ull);
L_7004531590:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045315a0(Cpu *c) {
    FN_ENTER(0x70045315a0ull);
L_70045315a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045315b0(Cpu *c) {
    FN_ENTER(0x70045315b0ull);
L_70045315b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045315c0(Cpu *c) {
    FN_ENTER(0x70045315c0ull);
L_70045315c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045315d0(Cpu *c) {
    FN_ENTER(0x70045315d0ull);
L_70045315d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045315e0(Cpu *c) {
    FN_ENTER(0x70045315e0ull);
L_70045315e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045315f0(Cpu *c) {
    FN_ENTER(0x70045315f0ull);
L_70045315f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531600(Cpu *c) {
    FN_ENTER(0x7004531600ull);
L_7004531600:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531610(Cpu *c) {
    FN_ENTER(0x7004531610ull);
L_7004531610:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531620(Cpu *c) {
    FN_ENTER(0x7004531620ull);
L_7004531620:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531630(Cpu *c) {
    FN_ENTER(0x7004531630ull);
L_7004531630:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531640(Cpu *c) {
    FN_ENTER(0x7004531640ull);
L_7004531640:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531650(Cpu *c) {
    FN_ENTER(0x7004531650ull);
L_7004531650:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531660(Cpu *c) {
    FN_ENTER(0x7004531660ull);
L_7004531660:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531670(Cpu *c) {
    FN_ENTER(0x7004531670ull);
L_7004531670:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531680(Cpu *c) {
    FN_ENTER(0x7004531680ull);
L_7004531680:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531690(Cpu *c) {
    FN_ENTER(0x7004531690ull);
L_7004531690:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045316a0(Cpu *c) {
    FN_ENTER(0x70045316a0ull);
L_70045316a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045316b0(Cpu *c) {
    FN_ENTER(0x70045316b0ull);
L_70045316b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045316c0(Cpu *c) {
    FN_ENTER(0x70045316c0ull);
L_70045316c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045316d0(Cpu *c) {
    FN_ENTER(0x70045316d0ull);
L_70045316d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045316e0(Cpu *c) {
    FN_ENTER(0x70045316e0ull);
L_70045316e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045316f0(Cpu *c) {
    FN_ENTER(0x70045316f0ull);
L_70045316f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531700(Cpu *c) {
    FN_ENTER(0x7004531700ull);
L_7004531700:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531710(Cpu *c) {
    FN_ENTER(0x7004531710ull);
L_7004531710:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531720(Cpu *c) {
    FN_ENTER(0x7004531720ull);
L_7004531720:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531730(Cpu *c) {
    FN_ENTER(0x7004531730ull);
L_7004531730:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531740(Cpu *c) {
    FN_ENTER(0x7004531740ull);
L_7004531740:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531750(Cpu *c) {
    FN_ENTER(0x7004531750ull);
L_7004531750:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531760(Cpu *c) {
    FN_ENTER(0x7004531760ull);
L_7004531760:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531770(Cpu *c) {
    FN_ENTER(0x7004531770ull);
L_7004531770:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531780(Cpu *c) {
    FN_ENTER(0x7004531780ull);
L_7004531780:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531790(Cpu *c) {
    FN_ENTER(0x7004531790ull);
L_7004531790:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045317a0(Cpu *c) {
    FN_ENTER(0x70045317a0ull);
L_70045317a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045317b0(Cpu *c) {
    FN_ENTER(0x70045317b0ull);
L_70045317b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045317c0(Cpu *c) {
    FN_ENTER(0x70045317c0ull);
L_70045317c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045317d0(Cpu *c) {
    FN_ENTER(0x70045317d0ull);
L_70045317d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045317e0(Cpu *c) {
    FN_ENTER(0x70045317e0ull);
L_70045317e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045317f0(Cpu *c) {
    FN_ENTER(0x70045317f0ull);
L_70045317f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531800(Cpu *c) {
    FN_ENTER(0x7004531800ull);
L_7004531800:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531810(Cpu *c) {
    FN_ENTER(0x7004531810ull);
L_7004531810:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531820(Cpu *c) {
    FN_ENTER(0x7004531820ull);
L_7004531820:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531830(Cpu *c) {
    FN_ENTER(0x7004531830ull);
L_7004531830:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531840(Cpu *c) {
    FN_ENTER(0x7004531840ull);
L_7004531840:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531850(Cpu *c) {
    FN_ENTER(0x7004531850ull);
L_7004531850:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531860(Cpu *c) {
    FN_ENTER(0x7004531860ull);
L_7004531860:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531870(Cpu *c) {
    FN_ENTER(0x7004531870ull);
L_7004531870:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531880(Cpu *c) {
    FN_ENTER(0x7004531880ull);
L_7004531880:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531890(Cpu *c) {
    FN_ENTER(0x7004531890ull);
L_7004531890:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045318a0(Cpu *c) {
    FN_ENTER(0x70045318a0ull);
L_70045318a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045318b0(Cpu *c) {
    FN_ENTER(0x70045318b0ull);
L_70045318b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045318c0(Cpu *c) {
    FN_ENTER(0x70045318c0ull);
L_70045318c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045318d0(Cpu *c) {
    FN_ENTER(0x70045318d0ull);
L_70045318d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045318e0(Cpu *c) {
    FN_ENTER(0x70045318e0ull);
L_70045318e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045318f0(Cpu *c) {
    FN_ENTER(0x70045318f0ull);
L_70045318f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531900(Cpu *c) {
    FN_ENTER(0x7004531900ull);
L_7004531900:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531910(Cpu *c) {
    FN_ENTER(0x7004531910ull);
L_7004531910:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531920(Cpu *c) {
    FN_ENTER(0x7004531920ull);
L_7004531920:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531930(Cpu *c) {
    FN_ENTER(0x7004531930ull);
L_7004531930:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531940(Cpu *c) {
    FN_ENTER(0x7004531940ull);
L_7004531940:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531950(Cpu *c) {
    FN_ENTER(0x7004531950ull);
L_7004531950:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531960(Cpu *c) {
    FN_ENTER(0x7004531960ull);
L_7004531960:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531970(Cpu *c) {
    FN_ENTER(0x7004531970ull);
L_7004531970:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531980(Cpu *c) {
    FN_ENTER(0x7004531980ull);
L_7004531980:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531990(Cpu *c) {
    FN_ENTER(0x7004531990ull);
L_7004531990:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045319a0(Cpu *c) {
    FN_ENTER(0x70045319a0ull);
L_70045319a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045319b0(Cpu *c) {
    FN_ENTER(0x70045319b0ull);
L_70045319b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045319c0(Cpu *c) {
    FN_ENTER(0x70045319c0ull);
L_70045319c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045319d0(Cpu *c) {
    FN_ENTER(0x70045319d0ull);
L_70045319d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045319e0(Cpu *c) {
    FN_ENTER(0x70045319e0ull);
L_70045319e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045319f0(Cpu *c) {
    FN_ENTER(0x70045319f0ull);
L_70045319f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a00(Cpu *c) {
    FN_ENTER(0x7004531a00ull);
L_7004531a00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a10(Cpu *c) {
    FN_ENTER(0x7004531a10ull);
L_7004531a10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a20(Cpu *c) {
    FN_ENTER(0x7004531a20ull);
L_7004531a20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a30(Cpu *c) {
    FN_ENTER(0x7004531a30ull);
L_7004531a30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a40(Cpu *c) {
    FN_ENTER(0x7004531a40ull);
L_7004531a40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a50(Cpu *c) {
    FN_ENTER(0x7004531a50ull);
L_7004531a50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a60(Cpu *c) {
    FN_ENTER(0x7004531a60ull);
L_7004531a60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a70(Cpu *c) {
    FN_ENTER(0x7004531a70ull);
L_7004531a70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a80(Cpu *c) {
    FN_ENTER(0x7004531a80ull);
L_7004531a80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531a90(Cpu *c) {
    FN_ENTER(0x7004531a90ull);
L_7004531a90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531aa0(Cpu *c) {
    FN_ENTER(0x7004531aa0ull);
L_7004531aa0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ab0(Cpu *c) {
    FN_ENTER(0x7004531ab0ull);
L_7004531ab0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ac0(Cpu *c) {
    FN_ENTER(0x7004531ac0ull);
L_7004531ac0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ad0(Cpu *c) {
    FN_ENTER(0x7004531ad0ull);
L_7004531ad0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ae0(Cpu *c) {
    FN_ENTER(0x7004531ae0ull);
L_7004531ae0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531af0(Cpu *c) {
    FN_ENTER(0x7004531af0ull);
L_7004531af0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b00(Cpu *c) {
    FN_ENTER(0x7004531b00ull);
L_7004531b00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b10(Cpu *c) {
    FN_ENTER(0x7004531b10ull);
L_7004531b10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b20(Cpu *c) {
    FN_ENTER(0x7004531b20ull);
L_7004531b20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b30(Cpu *c) {
    FN_ENTER(0x7004531b30ull);
L_7004531b30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b40(Cpu *c) {
    FN_ENTER(0x7004531b40ull);
L_7004531b40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b50(Cpu *c) {
    FN_ENTER(0x7004531b50ull);
L_7004531b50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b60(Cpu *c) {
    FN_ENTER(0x7004531b60ull);
L_7004531b60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b70(Cpu *c) {
    FN_ENTER(0x7004531b70ull);
L_7004531b70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b80(Cpu *c) {
    FN_ENTER(0x7004531b80ull);
L_7004531b80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531b90(Cpu *c) {
    FN_ENTER(0x7004531b90ull);
L_7004531b90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ba0(Cpu *c) {
    FN_ENTER(0x7004531ba0ull);
L_7004531ba0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531bb0(Cpu *c) {
    FN_ENTER(0x7004531bb0ull);
L_7004531bb0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531bc0(Cpu *c) {
    FN_ENTER(0x7004531bc0ull);
L_7004531bc0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531bd0(Cpu *c) {
    FN_ENTER(0x7004531bd0ull);
L_7004531bd0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531be0(Cpu *c) {
    FN_ENTER(0x7004531be0ull);
L_7004531be0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531bf0(Cpu *c) {
    FN_ENTER(0x7004531bf0ull);
L_7004531bf0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c00(Cpu *c) {
    FN_ENTER(0x7004531c00ull);
L_7004531c00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c10(Cpu *c) {
    FN_ENTER(0x7004531c10ull);
L_7004531c10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c20(Cpu *c) {
    FN_ENTER(0x7004531c20ull);
L_7004531c20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c30(Cpu *c) {
    FN_ENTER(0x7004531c30ull);
L_7004531c30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c40(Cpu *c) {
    FN_ENTER(0x7004531c40ull);
L_7004531c40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c50(Cpu *c) {
    FN_ENTER(0x7004531c50ull);
L_7004531c50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c60(Cpu *c) {
    FN_ENTER(0x7004531c60ull);
L_7004531c60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c70(Cpu *c) {
    FN_ENTER(0x7004531c70ull);
L_7004531c70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c80(Cpu *c) {
    FN_ENTER(0x7004531c80ull);
L_7004531c80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531c90(Cpu *c) {
    FN_ENTER(0x7004531c90ull);
L_7004531c90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ca0(Cpu *c) {
    FN_ENTER(0x7004531ca0ull);
L_7004531ca0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531cb0(Cpu *c) {
    FN_ENTER(0x7004531cb0ull);
L_7004531cb0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531cc0(Cpu *c) {
    FN_ENTER(0x7004531cc0ull);
L_7004531cc0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531cd0(Cpu *c) {
    FN_ENTER(0x7004531cd0ull);
L_7004531cd0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ce0(Cpu *c) {
    FN_ENTER(0x7004531ce0ull);
L_7004531ce0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531cf0(Cpu *c) {
    FN_ENTER(0x7004531cf0ull);
L_7004531cf0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d00(Cpu *c) {
    FN_ENTER(0x7004531d00ull);
L_7004531d00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d10(Cpu *c) {
    FN_ENTER(0x7004531d10ull);
L_7004531d10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d20(Cpu *c) {
    FN_ENTER(0x7004531d20ull);
L_7004531d20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d30(Cpu *c) {
    FN_ENTER(0x7004531d30ull);
L_7004531d30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d40(Cpu *c) {
    FN_ENTER(0x7004531d40ull);
L_7004531d40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d50(Cpu *c) {
    FN_ENTER(0x7004531d50ull);
L_7004531d50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d60(Cpu *c) {
    FN_ENTER(0x7004531d60ull);
L_7004531d60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d70(Cpu *c) {
    FN_ENTER(0x7004531d70ull);
L_7004531d70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d80(Cpu *c) {
    FN_ENTER(0x7004531d80ull);
L_7004531d80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531d90(Cpu *c) {
    FN_ENTER(0x7004531d90ull);
L_7004531d90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531da0(Cpu *c) {
    FN_ENTER(0x7004531da0ull);
L_7004531da0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531db0(Cpu *c) {
    FN_ENTER(0x7004531db0ull);
L_7004531db0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531dc0(Cpu *c) {
    FN_ENTER(0x7004531dc0ull);
L_7004531dc0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531dd0(Cpu *c) {
    FN_ENTER(0x7004531dd0ull);
L_7004531dd0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531de0(Cpu *c) {
    FN_ENTER(0x7004531de0ull);
L_7004531de0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531df0(Cpu *c) {
    FN_ENTER(0x7004531df0ull);
L_7004531df0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e00(Cpu *c) {
    FN_ENTER(0x7004531e00ull);
L_7004531e00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e10(Cpu *c) {
    FN_ENTER(0x7004531e10ull);
L_7004531e10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e20(Cpu *c) {
    FN_ENTER(0x7004531e20ull);
L_7004531e20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e30(Cpu *c) {
    FN_ENTER(0x7004531e30ull);
L_7004531e30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e40(Cpu *c) {
    FN_ENTER(0x7004531e40ull);
L_7004531e40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e50(Cpu *c) {
    FN_ENTER(0x7004531e50ull);
L_7004531e50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e60(Cpu *c) {
    FN_ENTER(0x7004531e60ull);
L_7004531e60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e70(Cpu *c) {
    FN_ENTER(0x7004531e70ull);
L_7004531e70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e80(Cpu *c) {
    FN_ENTER(0x7004531e80ull);
L_7004531e80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531e90(Cpu *c) {
    FN_ENTER(0x7004531e90ull);
L_7004531e90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ea0(Cpu *c) {
    FN_ENTER(0x7004531ea0ull);
L_7004531ea0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531eb0(Cpu *c) {
    FN_ENTER(0x7004531eb0ull);
L_7004531eb0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ec0(Cpu *c) {
    FN_ENTER(0x7004531ec0ull);
L_7004531ec0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ed0(Cpu *c) {
    FN_ENTER(0x7004531ed0ull);
L_7004531ed0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ee0(Cpu *c) {
    FN_ENTER(0x7004531ee0ull);
L_7004531ee0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ef0(Cpu *c) {
    FN_ENTER(0x7004531ef0ull);
L_7004531ef0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f00(Cpu *c) {
    FN_ENTER(0x7004531f00ull);
L_7004531f00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f10(Cpu *c) {
    FN_ENTER(0x7004531f10ull);
L_7004531f10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f20(Cpu *c) {
    FN_ENTER(0x7004531f20ull);
L_7004531f20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f30(Cpu *c) {
    FN_ENTER(0x7004531f30ull);
L_7004531f30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f40(Cpu *c) {
    FN_ENTER(0x7004531f40ull);
L_7004531f40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f50(Cpu *c) {
    FN_ENTER(0x7004531f50ull);
L_7004531f50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f60(Cpu *c) {
    FN_ENTER(0x7004531f60ull);
L_7004531f60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f70(Cpu *c) {
    FN_ENTER(0x7004531f70ull);
L_7004531f70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f80(Cpu *c) {
    FN_ENTER(0x7004531f80ull);
L_7004531f80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531f90(Cpu *c) {
    FN_ENTER(0x7004531f90ull);
L_7004531f90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531fa0(Cpu *c) {
    FN_ENTER(0x7004531fa0ull);
L_7004531fa0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531fb0(Cpu *c) {
    FN_ENTER(0x7004531fb0ull);
L_7004531fb0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531fc0(Cpu *c) {
    FN_ENTER(0x7004531fc0ull);
L_7004531fc0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531fd0(Cpu *c) {
    FN_ENTER(0x7004531fd0ull);
L_7004531fd0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531fe0(Cpu *c) {
    FN_ENTER(0x7004531fe0ull);
L_7004531fe0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004531ff0(Cpu *c) {
    FN_ENTER(0x7004531ff0ull);
L_7004531ff0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532000(Cpu *c) {
    FN_ENTER(0x7004532000ull);
L_7004532000:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532010(Cpu *c) {
    FN_ENTER(0x7004532010ull);
L_7004532010:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532020(Cpu *c) {
    FN_ENTER(0x7004532020ull);
L_7004532020:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532030(Cpu *c) {
    FN_ENTER(0x7004532030ull);
L_7004532030:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532040(Cpu *c) {
    FN_ENTER(0x7004532040ull);
L_7004532040:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532050(Cpu *c) {
    FN_ENTER(0x7004532050ull);
L_7004532050:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532060(Cpu *c) {
    FN_ENTER(0x7004532060ull);
L_7004532060:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532070(Cpu *c) {
    FN_ENTER(0x7004532070ull);
L_7004532070:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532080(Cpu *c) {
    FN_ENTER(0x7004532080ull);
L_7004532080:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532090(Cpu *c) {
    FN_ENTER(0x7004532090ull);
L_7004532090:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045320a0(Cpu *c) {
    FN_ENTER(0x70045320a0ull);
L_70045320a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045320b0(Cpu *c) {
    FN_ENTER(0x70045320b0ull);
L_70045320b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045320c0(Cpu *c) {
    FN_ENTER(0x70045320c0ull);
L_70045320c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045320d0(Cpu *c) {
    FN_ENTER(0x70045320d0ull);
L_70045320d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045320e0(Cpu *c) {
    FN_ENTER(0x70045320e0ull);
L_70045320e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045320f0(Cpu *c) {
    FN_ENTER(0x70045320f0ull);
L_70045320f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532100(Cpu *c) {
    FN_ENTER(0x7004532100ull);
L_7004532100:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532110(Cpu *c) {
    FN_ENTER(0x7004532110ull);
L_7004532110:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532120(Cpu *c) {
    FN_ENTER(0x7004532120ull);
L_7004532120:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532130(Cpu *c) {
    FN_ENTER(0x7004532130ull);
L_7004532130:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532140(Cpu *c) {
    FN_ENTER(0x7004532140ull);
L_7004532140:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532150(Cpu *c) {
    FN_ENTER(0x7004532150ull);
L_7004532150:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532160(Cpu *c) {
    FN_ENTER(0x7004532160ull);
L_7004532160:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532170(Cpu *c) {
    FN_ENTER(0x7004532170ull);
L_7004532170:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532180(Cpu *c) {
    FN_ENTER(0x7004532180ull);
L_7004532180:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532190(Cpu *c) {
    FN_ENTER(0x7004532190ull);
L_7004532190:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045321a0(Cpu *c) {
    FN_ENTER(0x70045321a0ull);
L_70045321a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045321b0(Cpu *c) {
    FN_ENTER(0x70045321b0ull);
L_70045321b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045321c0(Cpu *c) {
    FN_ENTER(0x70045321c0ull);
L_70045321c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045321d0(Cpu *c) {
    FN_ENTER(0x70045321d0ull);
L_70045321d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045321e0(Cpu *c) {
    FN_ENTER(0x70045321e0ull);
L_70045321e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045321f0(Cpu *c) {
    FN_ENTER(0x70045321f0ull);
L_70045321f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532200(Cpu *c) {
    FN_ENTER(0x7004532200ull);
L_7004532200:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532210(Cpu *c) {
    FN_ENTER(0x7004532210ull);
L_7004532210:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532220(Cpu *c) {
    FN_ENTER(0x7004532220ull);
L_7004532220:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532230(Cpu *c) {
    FN_ENTER(0x7004532230ull);
L_7004532230:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532240(Cpu *c) {
    FN_ENTER(0x7004532240ull);
L_7004532240:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532250(Cpu *c) {
    FN_ENTER(0x7004532250ull);
L_7004532250:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532260(Cpu *c) {
    FN_ENTER(0x7004532260ull);
L_7004532260:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532270(Cpu *c) {
    FN_ENTER(0x7004532270ull);
L_7004532270:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532280(Cpu *c) {
    FN_ENTER(0x7004532280ull);
L_7004532280:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532290(Cpu *c) {
    FN_ENTER(0x7004532290ull);
L_7004532290:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045322a0(Cpu *c) {
    FN_ENTER(0x70045322a0ull);
L_70045322a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045322b0(Cpu *c) {
    FN_ENTER(0x70045322b0ull);
L_70045322b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045322c0(Cpu *c) {
    FN_ENTER(0x70045322c0ull);
L_70045322c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045322d0(Cpu *c) {
    FN_ENTER(0x70045322d0ull);
L_70045322d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045322e0(Cpu *c) {
    FN_ENTER(0x70045322e0ull);
L_70045322e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045322f0(Cpu *c) {
    FN_ENTER(0x70045322f0ull);
L_70045322f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532300(Cpu *c) {
    FN_ENTER(0x7004532300ull);
L_7004532300:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532310(Cpu *c) {
    FN_ENTER(0x7004532310ull);
L_7004532310:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532320(Cpu *c) {
    FN_ENTER(0x7004532320ull);
L_7004532320:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532330(Cpu *c) {
    FN_ENTER(0x7004532330ull);
L_7004532330:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532340(Cpu *c) {
    FN_ENTER(0x7004532340ull);
L_7004532340:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532350(Cpu *c) {
    FN_ENTER(0x7004532350ull);
L_7004532350:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532360(Cpu *c) {
    FN_ENTER(0x7004532360ull);
L_7004532360:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532370(Cpu *c) {
    FN_ENTER(0x7004532370ull);
L_7004532370:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532380(Cpu *c) {
    FN_ENTER(0x7004532380ull);
L_7004532380:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532390(Cpu *c) {
    FN_ENTER(0x7004532390ull);
L_7004532390:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045323a0(Cpu *c) {
    FN_ENTER(0x70045323a0ull);
L_70045323a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045323b0(Cpu *c) {
    FN_ENTER(0x70045323b0ull);
L_70045323b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045323c0(Cpu *c) {
    FN_ENTER(0x70045323c0ull);
L_70045323c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045323d0(Cpu *c) {
    FN_ENTER(0x70045323d0ull);
L_70045323d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045323e0(Cpu *c) {
    FN_ENTER(0x70045323e0ull);
L_70045323e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045323f0(Cpu *c) {
    FN_ENTER(0x70045323f0ull);
L_70045323f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532400(Cpu *c) {
    FN_ENTER(0x7004532400ull);
L_7004532400:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532410(Cpu *c) {
    FN_ENTER(0x7004532410ull);
L_7004532410:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532420(Cpu *c) {
    FN_ENTER(0x7004532420ull);
L_7004532420:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532430(Cpu *c) {
    FN_ENTER(0x7004532430ull);
L_7004532430:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532440(Cpu *c) {
    FN_ENTER(0x7004532440ull);
L_7004532440:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532450(Cpu *c) {
    FN_ENTER(0x7004532450ull);
L_7004532450:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532460(Cpu *c) {
    FN_ENTER(0x7004532460ull);
L_7004532460:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532470(Cpu *c) {
    FN_ENTER(0x7004532470ull);
L_7004532470:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532480(Cpu *c) {
    FN_ENTER(0x7004532480ull);
L_7004532480:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532490(Cpu *c) {
    FN_ENTER(0x7004532490ull);
L_7004532490:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045324a0(Cpu *c) {
    FN_ENTER(0x70045324a0ull);
L_70045324a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045324b0(Cpu *c) {
    FN_ENTER(0x70045324b0ull);
L_70045324b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045324c0(Cpu *c) {
    FN_ENTER(0x70045324c0ull);
L_70045324c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045324d0(Cpu *c) {
    FN_ENTER(0x70045324d0ull);
L_70045324d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045324e0(Cpu *c) {
    FN_ENTER(0x70045324e0ull);
L_70045324e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045324f0(Cpu *c) {
    FN_ENTER(0x70045324f0ull);
L_70045324f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532500(Cpu *c) {
    FN_ENTER(0x7004532500ull);
L_7004532500:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532510(Cpu *c) {
    FN_ENTER(0x7004532510ull);
L_7004532510:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532520(Cpu *c) {
    FN_ENTER(0x7004532520ull);
L_7004532520:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532530(Cpu *c) {
    FN_ENTER(0x7004532530ull);
L_7004532530:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532540(Cpu *c) {
    FN_ENTER(0x7004532540ull);
L_7004532540:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532550(Cpu *c) {
    FN_ENTER(0x7004532550ull);
L_7004532550:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532560(Cpu *c) {
    FN_ENTER(0x7004532560ull);
L_7004532560:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532570(Cpu *c) {
    FN_ENTER(0x7004532570ull);
L_7004532570:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532580(Cpu *c) {
    FN_ENTER(0x7004532580ull);
L_7004532580:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532590(Cpu *c) {
    FN_ENTER(0x7004532590ull);
L_7004532590:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045325a0(Cpu *c) {
    FN_ENTER(0x70045325a0ull);
L_70045325a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045325b0(Cpu *c) {
    FN_ENTER(0x70045325b0ull);
L_70045325b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045325c0(Cpu *c) {
    FN_ENTER(0x70045325c0ull);
L_70045325c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045325d0(Cpu *c) {
    FN_ENTER(0x70045325d0ull);
L_70045325d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045325e0(Cpu *c) {
    FN_ENTER(0x70045325e0ull);
L_70045325e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045325f0(Cpu *c) {
    FN_ENTER(0x70045325f0ull);
L_70045325f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532600(Cpu *c) {
    FN_ENTER(0x7004532600ull);
L_7004532600:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532610(Cpu *c) {
    FN_ENTER(0x7004532610ull);
L_7004532610:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532620(Cpu *c) {
    FN_ENTER(0x7004532620ull);
L_7004532620:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532630(Cpu *c) {
    FN_ENTER(0x7004532630ull);
L_7004532630:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532640(Cpu *c) {
    FN_ENTER(0x7004532640ull);
L_7004532640:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532650(Cpu *c) {
    FN_ENTER(0x7004532650ull);
L_7004532650:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532660(Cpu *c) {
    FN_ENTER(0x7004532660ull);
L_7004532660:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532670(Cpu *c) {
    FN_ENTER(0x7004532670ull);
L_7004532670:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532680(Cpu *c) {
    FN_ENTER(0x7004532680ull);
L_7004532680:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532690(Cpu *c) {
    FN_ENTER(0x7004532690ull);
L_7004532690:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045326a0(Cpu *c) {
    FN_ENTER(0x70045326a0ull);
L_70045326a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045326b0(Cpu *c) {
    FN_ENTER(0x70045326b0ull);
L_70045326b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045326c0(Cpu *c) {
    FN_ENTER(0x70045326c0ull);
L_70045326c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045326d0(Cpu *c) {
    FN_ENTER(0x70045326d0ull);
L_70045326d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045326e0(Cpu *c) {
    FN_ENTER(0x70045326e0ull);
L_70045326e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045326f0(Cpu *c) {
    FN_ENTER(0x70045326f0ull);
L_70045326f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532700(Cpu *c) {
    FN_ENTER(0x7004532700ull);
L_7004532700:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532710(Cpu *c) {
    FN_ENTER(0x7004532710ull);
L_7004532710:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532720(Cpu *c) {
    FN_ENTER(0x7004532720ull);
L_7004532720:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532730(Cpu *c) {
    FN_ENTER(0x7004532730ull);
L_7004532730:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532740(Cpu *c) {
    FN_ENTER(0x7004532740ull);
L_7004532740:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532750(Cpu *c) {
    FN_ENTER(0x7004532750ull);
L_7004532750:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532760(Cpu *c) {
    FN_ENTER(0x7004532760ull);
L_7004532760:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532770(Cpu *c) {
    FN_ENTER(0x7004532770ull);
L_7004532770:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532780(Cpu *c) {
    FN_ENTER(0x7004532780ull);
L_7004532780:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532790(Cpu *c) {
    FN_ENTER(0x7004532790ull);
L_7004532790:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045327a0(Cpu *c) {
    FN_ENTER(0x70045327a0ull);
L_70045327a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045327b0(Cpu *c) {
    FN_ENTER(0x70045327b0ull);
L_70045327b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045327c0(Cpu *c) {
    FN_ENTER(0x70045327c0ull);
L_70045327c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045327d0(Cpu *c) {
    FN_ENTER(0x70045327d0ull);
L_70045327d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045327e0(Cpu *c) {
    FN_ENTER(0x70045327e0ull);
L_70045327e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045327f0(Cpu *c) {
    FN_ENTER(0x70045327f0ull);
L_70045327f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532800(Cpu *c) {
    FN_ENTER(0x7004532800ull);
L_7004532800:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532810(Cpu *c) {
    FN_ENTER(0x7004532810ull);
L_7004532810:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532820(Cpu *c) {
    FN_ENTER(0x7004532820ull);
L_7004532820:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532830(Cpu *c) {
    FN_ENTER(0x7004532830ull);
L_7004532830:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532840(Cpu *c) {
    FN_ENTER(0x7004532840ull);
L_7004532840:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532850(Cpu *c) {
    FN_ENTER(0x7004532850ull);
L_7004532850:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532860(Cpu *c) {
    FN_ENTER(0x7004532860ull);
L_7004532860:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532870(Cpu *c) {
    FN_ENTER(0x7004532870ull);
L_7004532870:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532880(Cpu *c) {
    FN_ENTER(0x7004532880ull);
L_7004532880:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532890(Cpu *c) {
    FN_ENTER(0x7004532890ull);
L_7004532890:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045328a0(Cpu *c) {
    FN_ENTER(0x70045328a0ull);
L_70045328a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045328b0(Cpu *c) {
    FN_ENTER(0x70045328b0ull);
L_70045328b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045328c0(Cpu *c) {
    FN_ENTER(0x70045328c0ull);
L_70045328c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045328d0(Cpu *c) {
    FN_ENTER(0x70045328d0ull);
L_70045328d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045328e0(Cpu *c) {
    FN_ENTER(0x70045328e0ull);
L_70045328e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045328f0(Cpu *c) {
    FN_ENTER(0x70045328f0ull);
L_70045328f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532900(Cpu *c) {
    FN_ENTER(0x7004532900ull);
L_7004532900:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532910(Cpu *c) {
    FN_ENTER(0x7004532910ull);
L_7004532910:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532920(Cpu *c) {
    FN_ENTER(0x7004532920ull);
L_7004532920:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532930(Cpu *c) {
    FN_ENTER(0x7004532930ull);
L_7004532930:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532940(Cpu *c) {
    FN_ENTER(0x7004532940ull);
L_7004532940:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532950(Cpu *c) {
    FN_ENTER(0x7004532950ull);
L_7004532950:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532960(Cpu *c) {
    FN_ENTER(0x7004532960ull);
L_7004532960:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532970(Cpu *c) {
    FN_ENTER(0x7004532970ull);
L_7004532970:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532980(Cpu *c) {
    FN_ENTER(0x7004532980ull);
L_7004532980:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532990(Cpu *c) {
    FN_ENTER(0x7004532990ull);
L_7004532990:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045329a0(Cpu *c) {
    FN_ENTER(0x70045329a0ull);
L_70045329a0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045329b0(Cpu *c) {
    FN_ENTER(0x70045329b0ull);
L_70045329b0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045329c0(Cpu *c) {
    FN_ENTER(0x70045329c0ull);
L_70045329c0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045329d0(Cpu *c) {
    FN_ENTER(0x70045329d0ull);
L_70045329d0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045329e0(Cpu *c) {
    FN_ENTER(0x70045329e0ull);
L_70045329e0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045329f0(Cpu *c) {
    FN_ENTER(0x70045329f0ull);
L_70045329f0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a00(Cpu *c) {
    FN_ENTER(0x7004532a00ull);
L_7004532a00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a10(Cpu *c) {
    FN_ENTER(0x7004532a10ull);
L_7004532a10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a20(Cpu *c) {
    FN_ENTER(0x7004532a20ull);
L_7004532a20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a30(Cpu *c) {
    FN_ENTER(0x7004532a30ull);
L_7004532a30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a40(Cpu *c) {
    FN_ENTER(0x7004532a40ull);
L_7004532a40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a50(Cpu *c) {
    FN_ENTER(0x7004532a50ull);
L_7004532a50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a60(Cpu *c) {
    FN_ENTER(0x7004532a60ull);
L_7004532a60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a70(Cpu *c) {
    FN_ENTER(0x7004532a70ull);
L_7004532a70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a80(Cpu *c) {
    FN_ENTER(0x7004532a80ull);
L_7004532a80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532a90(Cpu *c) {
    FN_ENTER(0x7004532a90ull);
L_7004532a90:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532aa0(Cpu *c) {
    FN_ENTER(0x7004532aa0ull);
L_7004532aa0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ab0(Cpu *c) {
    FN_ENTER(0x7004532ab0ull);
L_7004532ab0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ac0(Cpu *c) {
    FN_ENTER(0x7004532ac0ull);
L_7004532ac0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ad0(Cpu *c) {
    FN_ENTER(0x7004532ad0ull);
L_7004532ad0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ae0(Cpu *c) {
    FN_ENTER(0x7004532ae0ull);
L_7004532ae0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532af0(Cpu *c) {
    FN_ENTER(0x7004532af0ull);
L_7004532af0:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b00(Cpu *c) {
    FN_ENTER(0x7004532b00ull);
L_7004532b00:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b10(Cpu *c) {
    FN_ENTER(0x7004532b10ull);
L_7004532b10:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b20(Cpu *c) {
    FN_ENTER(0x7004532b20ull);
L_7004532b20:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b30(Cpu *c) {
    FN_ENTER(0x7004532b30ull);
L_7004532b30:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b40(Cpu *c) {
    FN_ENTER(0x7004532b40ull);
L_7004532b40:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b50(Cpu *c) {
    FN_ENTER(0x7004532b50ull);
L_7004532b50:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b60(Cpu *c) {
    FN_ENTER(0x7004532b60ull);
L_7004532b60:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b70(Cpu *c) {
    FN_ENTER(0x7004532b70ull);
L_7004532b70:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b80(Cpu *c) {
    FN_ENTER(0x7004532b80ull);
L_7004532b80:;
    c->x[16] = (uint64_t)(0x7004c31000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532b90(Cpu *c) {
    FN_ENTER(0x7004532b90ull);
L_7004532b90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ba0(Cpu *c) {
    FN_ENTER(0x7004532ba0ull);
L_7004532ba0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532bb0(Cpu *c) {
    FN_ENTER(0x7004532bb0ull);
L_7004532bb0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532bc0(Cpu *c) {
    FN_ENTER(0x7004532bc0ull);
L_7004532bc0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532bd0(Cpu *c) {
    FN_ENTER(0x7004532bd0ull);
L_7004532bd0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532be0(Cpu *c) {
    FN_ENTER(0x7004532be0ull);
L_7004532be0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532bf0(Cpu *c) {
    FN_ENTER(0x7004532bf0ull);
L_7004532bf0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c00(Cpu *c) {
    FN_ENTER(0x7004532c00ull);
L_7004532c00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c10(Cpu *c) {
    FN_ENTER(0x7004532c10ull);
L_7004532c10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c20(Cpu *c) {
    FN_ENTER(0x7004532c20ull);
L_7004532c20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c30(Cpu *c) {
    FN_ENTER(0x7004532c30ull);
L_7004532c30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c40(Cpu *c) {
    FN_ENTER(0x7004532c40ull);
L_7004532c40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c50(Cpu *c) {
    FN_ENTER(0x7004532c50ull);
L_7004532c50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c60(Cpu *c) {
    FN_ENTER(0x7004532c60ull);
L_7004532c60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c70(Cpu *c) {
    FN_ENTER(0x7004532c70ull);
L_7004532c70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c80(Cpu *c) {
    FN_ENTER(0x7004532c80ull);
L_7004532c80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532c90(Cpu *c) {
    FN_ENTER(0x7004532c90ull);
L_7004532c90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ca0(Cpu *c) {
    FN_ENTER(0x7004532ca0ull);
L_7004532ca0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532cb0(Cpu *c) {
    FN_ENTER(0x7004532cb0ull);
L_7004532cb0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532cc0(Cpu *c) {
    FN_ENTER(0x7004532cc0ull);
L_7004532cc0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532cd0(Cpu *c) {
    FN_ENTER(0x7004532cd0ull);
L_7004532cd0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ce0(Cpu *c) {
    FN_ENTER(0x7004532ce0ull);
L_7004532ce0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532cf0(Cpu *c) {
    FN_ENTER(0x7004532cf0ull);
L_7004532cf0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d00(Cpu *c) {
    FN_ENTER(0x7004532d00ull);
L_7004532d00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d10(Cpu *c) {
    FN_ENTER(0x7004532d10ull);
L_7004532d10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d20(Cpu *c) {
    FN_ENTER(0x7004532d20ull);
L_7004532d20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d30(Cpu *c) {
    FN_ENTER(0x7004532d30ull);
L_7004532d30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d40(Cpu *c) {
    FN_ENTER(0x7004532d40ull);
L_7004532d40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d50(Cpu *c) {
    FN_ENTER(0x7004532d50ull);
L_7004532d50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d60(Cpu *c) {
    FN_ENTER(0x7004532d60ull);
L_7004532d60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d70(Cpu *c) {
    FN_ENTER(0x7004532d70ull);
L_7004532d70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d80(Cpu *c) {
    FN_ENTER(0x7004532d80ull);
L_7004532d80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532d90(Cpu *c) {
    FN_ENTER(0x7004532d90ull);
L_7004532d90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x100ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x100ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532da0(Cpu *c) {
    FN_ENTER(0x7004532da0ull);
L_7004532da0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x108ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x108ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532db0(Cpu *c) {
    FN_ENTER(0x7004532db0ull);
L_7004532db0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x110ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x110ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532dc0(Cpu *c) {
    FN_ENTER(0x7004532dc0ull);
L_7004532dc0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x118ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x118ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532dd0(Cpu *c) {
    FN_ENTER(0x7004532dd0ull);
L_7004532dd0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x120ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x120ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532de0(Cpu *c) {
    FN_ENTER(0x7004532de0ull);
L_7004532de0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x128ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x128ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532df0(Cpu *c) {
    FN_ENTER(0x7004532df0ull);
L_7004532df0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x130ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x130ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e00(Cpu *c) {
    FN_ENTER(0x7004532e00ull);
L_7004532e00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x138ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x138ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e10(Cpu *c) {
    FN_ENTER(0x7004532e10ull);
L_7004532e10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x140ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x140ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e20(Cpu *c) {
    FN_ENTER(0x7004532e20ull);
L_7004532e20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x148ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x148ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e30(Cpu *c) {
    FN_ENTER(0x7004532e30ull);
L_7004532e30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x150ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x150ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e40(Cpu *c) {
    FN_ENTER(0x7004532e40ull);
L_7004532e40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x158ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x158ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e50(Cpu *c) {
    FN_ENTER(0x7004532e50ull);
L_7004532e50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x160ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x160ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e60(Cpu *c) {
    FN_ENTER(0x7004532e60ull);
L_7004532e60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x168ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x168ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e70(Cpu *c) {
    FN_ENTER(0x7004532e70ull);
L_7004532e70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x170ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x170ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e80(Cpu *c) {
    FN_ENTER(0x7004532e80ull);
L_7004532e80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x178ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x178ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532e90(Cpu *c) {
    FN_ENTER(0x7004532e90ull);
L_7004532e90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x180ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x180ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ea0(Cpu *c) {
    FN_ENTER(0x7004532ea0ull);
L_7004532ea0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x188ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x188ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532eb0(Cpu *c) {
    FN_ENTER(0x7004532eb0ull);
L_7004532eb0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x190ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x190ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ec0(Cpu *c) {
    FN_ENTER(0x7004532ec0ull);
L_7004532ec0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x198ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x198ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ed0(Cpu *c) {
    FN_ENTER(0x7004532ed0ull);
L_7004532ed0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ee0(Cpu *c) {
    FN_ENTER(0x7004532ee0ull);
L_7004532ee0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ef0(Cpu *c) {
    FN_ENTER(0x7004532ef0ull);
L_7004532ef0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f00(Cpu *c) {
    FN_ENTER(0x7004532f00ull);
L_7004532f00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f10(Cpu *c) {
    FN_ENTER(0x7004532f10ull);
L_7004532f10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f20(Cpu *c) {
    FN_ENTER(0x7004532f20ull);
L_7004532f20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f30(Cpu *c) {
    FN_ENTER(0x7004532f30ull);
L_7004532f30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f40(Cpu *c) {
    FN_ENTER(0x7004532f40ull);
L_7004532f40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f50(Cpu *c) {
    FN_ENTER(0x7004532f50ull);
L_7004532f50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f60(Cpu *c) {
    FN_ENTER(0x7004532f60ull);
L_7004532f60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f70(Cpu *c) {
    FN_ENTER(0x7004532f70ull);
L_7004532f70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f80(Cpu *c) {
    FN_ENTER(0x7004532f80ull);
L_7004532f80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x1f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532f90(Cpu *c) {
    FN_ENTER(0x7004532f90ull);
L_7004532f90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x200ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x200ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532fa0(Cpu *c) {
    FN_ENTER(0x7004532fa0ull);
L_7004532fa0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x208ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x208ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
