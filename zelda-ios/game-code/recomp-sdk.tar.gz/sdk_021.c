#include "cpu.h"
#include "simd.h"
void f_7004532fb0(Cpu *c) {
    FN_ENTER(0x7004532fb0ull);
L_7004532fb0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x210ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x210ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532fc0(Cpu *c) {
    FN_ENTER(0x7004532fc0ull);
L_7004532fc0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x218ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x218ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532fd0(Cpu *c) {
    FN_ENTER(0x7004532fd0ull);
L_7004532fd0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x220ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x220ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532fe0(Cpu *c) {
    FN_ENTER(0x7004532fe0ull);
L_7004532fe0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x228ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x228ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004532ff0(Cpu *c) {
    FN_ENTER(0x7004532ff0ull);
L_7004532ff0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x230ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x230ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533000(Cpu *c) {
    FN_ENTER(0x7004533000ull);
L_7004533000:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x238ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x238ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533010(Cpu *c) {
    FN_ENTER(0x7004533010ull);
L_7004533010:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x240ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x240ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533020(Cpu *c) {
    FN_ENTER(0x7004533020ull);
L_7004533020:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x248ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x248ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533030(Cpu *c) {
    FN_ENTER(0x7004533030ull);
L_7004533030:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x250ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x250ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533040(Cpu *c) {
    FN_ENTER(0x7004533040ull);
L_7004533040:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x258ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x258ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533050(Cpu *c) {
    FN_ENTER(0x7004533050ull);
L_7004533050:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x260ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x260ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533060(Cpu *c) {
    FN_ENTER(0x7004533060ull);
L_7004533060:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x268ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x268ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533070(Cpu *c) {
    FN_ENTER(0x7004533070ull);
L_7004533070:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x270ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x270ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533080(Cpu *c) {
    FN_ENTER(0x7004533080ull);
L_7004533080:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x278ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x278ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533090(Cpu *c) {
    FN_ENTER(0x7004533090ull);
L_7004533090:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x280ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x280ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045330a0(Cpu *c) {
    FN_ENTER(0x70045330a0ull);
L_70045330a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x288ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x288ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045330b0(Cpu *c) {
    FN_ENTER(0x70045330b0ull);
L_70045330b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x290ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x290ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045330c0(Cpu *c) {
    FN_ENTER(0x70045330c0ull);
L_70045330c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x298ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x298ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045330d0(Cpu *c) {
    FN_ENTER(0x70045330d0ull);
L_70045330d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045330e0(Cpu *c) {
    FN_ENTER(0x70045330e0ull);
L_70045330e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045330f0(Cpu *c) {
    FN_ENTER(0x70045330f0ull);
L_70045330f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533100(Cpu *c) {
    FN_ENTER(0x7004533100ull);
L_7004533100:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533110(Cpu *c) {
    FN_ENTER(0x7004533110ull);
L_7004533110:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533120(Cpu *c) {
    FN_ENTER(0x7004533120ull);
L_7004533120:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533130(Cpu *c) {
    FN_ENTER(0x7004533130ull);
L_7004533130:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533140(Cpu *c) {
    FN_ENTER(0x7004533140ull);
L_7004533140:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533150(Cpu *c) {
    FN_ENTER(0x7004533150ull);
L_7004533150:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533160(Cpu *c) {
    FN_ENTER(0x7004533160ull);
L_7004533160:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533170(Cpu *c) {
    FN_ENTER(0x7004533170ull);
L_7004533170:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533180(Cpu *c) {
    FN_ENTER(0x7004533180ull);
L_7004533180:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x2f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533190(Cpu *c) {
    FN_ENTER(0x7004533190ull);
L_7004533190:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x300ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x300ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045331a0(Cpu *c) {
    FN_ENTER(0x70045331a0ull);
L_70045331a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x308ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x308ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045331b0(Cpu *c) {
    FN_ENTER(0x70045331b0ull);
L_70045331b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x310ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x310ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045331c0(Cpu *c) {
    FN_ENTER(0x70045331c0ull);
L_70045331c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x318ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x318ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045331d0(Cpu *c) {
    FN_ENTER(0x70045331d0ull);
L_70045331d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x320ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x320ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045331e0(Cpu *c) {
    FN_ENTER(0x70045331e0ull);
L_70045331e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x328ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x328ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045331f0(Cpu *c) {
    FN_ENTER(0x70045331f0ull);
L_70045331f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x330ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x330ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533200(Cpu *c) {
    FN_ENTER(0x7004533200ull);
L_7004533200:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x338ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x338ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533210(Cpu *c) {
    FN_ENTER(0x7004533210ull);
L_7004533210:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x340ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x340ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533220(Cpu *c) {
    FN_ENTER(0x7004533220ull);
L_7004533220:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x348ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x348ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533230(Cpu *c) {
    FN_ENTER(0x7004533230ull);
L_7004533230:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x350ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x350ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533240(Cpu *c) {
    FN_ENTER(0x7004533240ull);
L_7004533240:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x358ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x358ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533250(Cpu *c) {
    FN_ENTER(0x7004533250ull);
L_7004533250:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x360ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x360ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533260(Cpu *c) {
    FN_ENTER(0x7004533260ull);
L_7004533260:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x368ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x368ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533270(Cpu *c) {
    FN_ENTER(0x7004533270ull);
L_7004533270:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x370ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x370ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533280(Cpu *c) {
    FN_ENTER(0x7004533280ull);
L_7004533280:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x378ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x378ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533290(Cpu *c) {
    FN_ENTER(0x7004533290ull);
L_7004533290:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x380ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x380ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045332a0(Cpu *c) {
    FN_ENTER(0x70045332a0ull);
L_70045332a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x388ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x388ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045332b0(Cpu *c) {
    FN_ENTER(0x70045332b0ull);
L_70045332b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x390ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x390ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045332c0(Cpu *c) {
    FN_ENTER(0x70045332c0ull);
L_70045332c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x398ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x398ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045332d0(Cpu *c) {
    FN_ENTER(0x70045332d0ull);
L_70045332d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045332e0(Cpu *c) {
    FN_ENTER(0x70045332e0ull);
L_70045332e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045332f0(Cpu *c) {
    FN_ENTER(0x70045332f0ull);
L_70045332f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533300(Cpu *c) {
    FN_ENTER(0x7004533300ull);
L_7004533300:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533310(Cpu *c) {
    FN_ENTER(0x7004533310ull);
L_7004533310:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533320(Cpu *c) {
    FN_ENTER(0x7004533320ull);
L_7004533320:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533330(Cpu *c) {
    FN_ENTER(0x7004533330ull);
L_7004533330:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533340(Cpu *c) {
    FN_ENTER(0x7004533340ull);
L_7004533340:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533350(Cpu *c) {
    FN_ENTER(0x7004533350ull);
L_7004533350:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533360(Cpu *c) {
    FN_ENTER(0x7004533360ull);
L_7004533360:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533370(Cpu *c) {
    FN_ENTER(0x7004533370ull);
L_7004533370:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533380(Cpu *c) {
    FN_ENTER(0x7004533380ull);
L_7004533380:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x3f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533390(Cpu *c) {
    FN_ENTER(0x7004533390ull);
L_7004533390:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x400ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x400ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045333a0(Cpu *c) {
    FN_ENTER(0x70045333a0ull);
L_70045333a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x408ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x408ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045333b0(Cpu *c) {
    FN_ENTER(0x70045333b0ull);
L_70045333b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x410ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x410ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045333c0(Cpu *c) {
    FN_ENTER(0x70045333c0ull);
L_70045333c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x418ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x418ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045333d0(Cpu *c) {
    FN_ENTER(0x70045333d0ull);
L_70045333d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x420ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x420ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045333e0(Cpu *c) {
    FN_ENTER(0x70045333e0ull);
L_70045333e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x428ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x428ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045333f0(Cpu *c) {
    FN_ENTER(0x70045333f0ull);
L_70045333f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x430ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x430ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533400(Cpu *c) {
    FN_ENTER(0x7004533400ull);
L_7004533400:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x438ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x438ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533410(Cpu *c) {
    FN_ENTER(0x7004533410ull);
L_7004533410:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x440ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x440ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533420(Cpu *c) {
    FN_ENTER(0x7004533420ull);
L_7004533420:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x448ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x448ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533430(Cpu *c) {
    FN_ENTER(0x7004533430ull);
L_7004533430:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533440(Cpu *c) {
    FN_ENTER(0x7004533440ull);
L_7004533440:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533450(Cpu *c) {
    FN_ENTER(0x7004533450ull);
L_7004533450:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533460(Cpu *c) {
    FN_ENTER(0x7004533460ull);
L_7004533460:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533470(Cpu *c) {
    FN_ENTER(0x7004533470ull);
L_7004533470:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533480(Cpu *c) {
    FN_ENTER(0x7004533480ull);
L_7004533480:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533490(Cpu *c) {
    FN_ENTER(0x7004533490ull);
L_7004533490:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045334a0(Cpu *c) {
    FN_ENTER(0x70045334a0ull);
L_70045334a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045334b0(Cpu *c) {
    FN_ENTER(0x70045334b0ull);
L_70045334b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045334c0(Cpu *c) {
    FN_ENTER(0x70045334c0ull);
L_70045334c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045334d0(Cpu *c) {
    FN_ENTER(0x70045334d0ull);
L_70045334d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045334e0(Cpu *c) {
    FN_ENTER(0x70045334e0ull);
L_70045334e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045334f0(Cpu *c) {
    FN_ENTER(0x70045334f0ull);
L_70045334f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533500(Cpu *c) {
    FN_ENTER(0x7004533500ull);
L_7004533500:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533510(Cpu *c) {
    FN_ENTER(0x7004533510ull);
L_7004533510:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533520(Cpu *c) {
    FN_ENTER(0x7004533520ull);
L_7004533520:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533530(Cpu *c) {
    FN_ENTER(0x7004533530ull);
L_7004533530:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533540(Cpu *c) {
    FN_ENTER(0x7004533540ull);
L_7004533540:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533550(Cpu *c) {
    FN_ENTER(0x7004533550ull);
L_7004533550:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533560(Cpu *c) {
    FN_ENTER(0x7004533560ull);
L_7004533560:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533570(Cpu *c) {
    FN_ENTER(0x7004533570ull);
L_7004533570:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533580(Cpu *c) {
    FN_ENTER(0x7004533580ull);
L_7004533580:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533590(Cpu *c) {
    FN_ENTER(0x7004533590ull);
L_7004533590:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045335a0(Cpu *c) {
    FN_ENTER(0x70045335a0ull);
L_70045335a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045335b0(Cpu *c) {
    FN_ENTER(0x70045335b0ull);
L_70045335b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045335c0(Cpu *c) {
    FN_ENTER(0x70045335c0ull);
L_70045335c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045335d0(Cpu *c) {
    FN_ENTER(0x70045335d0ull);
L_70045335d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045335e0(Cpu *c) {
    FN_ENTER(0x70045335e0ull);
L_70045335e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045335f0(Cpu *c) {
    FN_ENTER(0x70045335f0ull);
L_70045335f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533600(Cpu *c) {
    FN_ENTER(0x7004533600ull);
L_7004533600:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533610(Cpu *c) {
    FN_ENTER(0x7004533610ull);
L_7004533610:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533620(Cpu *c) {
    FN_ENTER(0x7004533620ull);
L_7004533620:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533630(Cpu *c) {
    FN_ENTER(0x7004533630ull);
L_7004533630:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533640(Cpu *c) {
    FN_ENTER(0x7004533640ull);
L_7004533640:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533650(Cpu *c) {
    FN_ENTER(0x7004533650ull);
L_7004533650:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533660(Cpu *c) {
    FN_ENTER(0x7004533660ull);
L_7004533660:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533670(Cpu *c) {
    FN_ENTER(0x7004533670ull);
L_7004533670:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533680(Cpu *c) {
    FN_ENTER(0x7004533680ull);
L_7004533680:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533690(Cpu *c) {
    FN_ENTER(0x7004533690ull);
L_7004533690:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045336a0(Cpu *c) {
    FN_ENTER(0x70045336a0ull);
L_70045336a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045336b0(Cpu *c) {
    FN_ENTER(0x70045336b0ull);
L_70045336b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045336c0(Cpu *c) {
    FN_ENTER(0x70045336c0ull);
L_70045336c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045336d0(Cpu *c) {
    FN_ENTER(0x70045336d0ull);
L_70045336d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045336e0(Cpu *c) {
    FN_ENTER(0x70045336e0ull);
L_70045336e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045336f0(Cpu *c) {
    FN_ENTER(0x70045336f0ull);
L_70045336f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533700(Cpu *c) {
    FN_ENTER(0x7004533700ull);
L_7004533700:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533710(Cpu *c) {
    FN_ENTER(0x7004533710ull);
L_7004533710:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533720(Cpu *c) {
    FN_ENTER(0x7004533720ull);
L_7004533720:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533730(Cpu *c) {
    FN_ENTER(0x7004533730ull);
L_7004533730:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533740(Cpu *c) {
    FN_ENTER(0x7004533740ull);
L_7004533740:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533750(Cpu *c) {
    FN_ENTER(0x7004533750ull);
L_7004533750:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533760(Cpu *c) {
    FN_ENTER(0x7004533760ull);
L_7004533760:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533770(Cpu *c) {
    FN_ENTER(0x7004533770ull);
L_7004533770:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533780(Cpu *c) {
    FN_ENTER(0x7004533780ull);
L_7004533780:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533790(Cpu *c) {
    FN_ENTER(0x7004533790ull);
L_7004533790:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045337a0(Cpu *c) {
    FN_ENTER(0x70045337a0ull);
L_70045337a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045337b0(Cpu *c) {
    FN_ENTER(0x70045337b0ull);
L_70045337b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045337c0(Cpu *c) {
    FN_ENTER(0x70045337c0ull);
L_70045337c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045337d0(Cpu *c) {
    FN_ENTER(0x70045337d0ull);
L_70045337d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045337e0(Cpu *c) {
    FN_ENTER(0x70045337e0ull);
L_70045337e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045337f0(Cpu *c) {
    FN_ENTER(0x70045337f0ull);
L_70045337f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533800(Cpu *c) {
    FN_ENTER(0x7004533800ull);
L_7004533800:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533810(Cpu *c) {
    FN_ENTER(0x7004533810ull);
L_7004533810:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533820(Cpu *c) {
    FN_ENTER(0x7004533820ull);
L_7004533820:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533830(Cpu *c) {
    FN_ENTER(0x7004533830ull);
L_7004533830:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533840(Cpu *c) {
    FN_ENTER(0x7004533840ull);
L_7004533840:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533850(Cpu *c) {
    FN_ENTER(0x7004533850ull);
L_7004533850:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533860(Cpu *c) {
    FN_ENTER(0x7004533860ull);
L_7004533860:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533870(Cpu *c) {
    FN_ENTER(0x7004533870ull);
L_7004533870:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533880(Cpu *c) {
    FN_ENTER(0x7004533880ull);
L_7004533880:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533890(Cpu *c) {
    FN_ENTER(0x7004533890ull);
L_7004533890:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045338a0(Cpu *c) {
    FN_ENTER(0x70045338a0ull);
L_70045338a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045338b0(Cpu *c) {
    FN_ENTER(0x70045338b0ull);
L_70045338b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045338c0(Cpu *c) {
    FN_ENTER(0x70045338c0ull);
L_70045338c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045338d0(Cpu *c) {
    FN_ENTER(0x70045338d0ull);
L_70045338d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045338e0(Cpu *c) {
    FN_ENTER(0x70045338e0ull);
L_70045338e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045338f0(Cpu *c) {
    FN_ENTER(0x70045338f0ull);
L_70045338f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533900(Cpu *c) {
    FN_ENTER(0x7004533900ull);
L_7004533900:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533910(Cpu *c) {
    FN_ENTER(0x7004533910ull);
L_7004533910:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533920(Cpu *c) {
    FN_ENTER(0x7004533920ull);
L_7004533920:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533930(Cpu *c) {
    FN_ENTER(0x7004533930ull);
L_7004533930:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533940(Cpu *c) {
    FN_ENTER(0x7004533940ull);
L_7004533940:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533950(Cpu *c) {
    FN_ENTER(0x7004533950ull);
L_7004533950:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533960(Cpu *c) {
    FN_ENTER(0x7004533960ull);
L_7004533960:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533970(Cpu *c) {
    FN_ENTER(0x7004533970ull);
L_7004533970:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533980(Cpu *c) {
    FN_ENTER(0x7004533980ull);
L_7004533980:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533990(Cpu *c) {
    FN_ENTER(0x7004533990ull);
L_7004533990:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045339a0(Cpu *c) {
    FN_ENTER(0x70045339a0ull);
L_70045339a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045339b0(Cpu *c) {
    FN_ENTER(0x70045339b0ull);
L_70045339b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045339c0(Cpu *c) {
    FN_ENTER(0x70045339c0ull);
L_70045339c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045339d0(Cpu *c) {
    FN_ENTER(0x70045339d0ull);
L_70045339d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045339e0(Cpu *c) {
    FN_ENTER(0x70045339e0ull);
L_70045339e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045339f0(Cpu *c) {
    FN_ENTER(0x70045339f0ull);
L_70045339f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a00(Cpu *c) {
    FN_ENTER(0x7004533a00ull);
L_7004533a00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a10(Cpu *c) {
    FN_ENTER(0x7004533a10ull);
L_7004533a10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a20(Cpu *c) {
    FN_ENTER(0x7004533a20ull);
L_7004533a20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a30(Cpu *c) {
    FN_ENTER(0x7004533a30ull);
L_7004533a30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a40(Cpu *c) {
    FN_ENTER(0x7004533a40ull);
L_7004533a40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a50(Cpu *c) {
    FN_ENTER(0x7004533a50ull);
L_7004533a50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a60(Cpu *c) {
    FN_ENTER(0x7004533a60ull);
L_7004533a60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a70(Cpu *c) {
    FN_ENTER(0x7004533a70ull);
L_7004533a70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a80(Cpu *c) {
    FN_ENTER(0x7004533a80ull);
L_7004533a80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533a90(Cpu *c) {
    FN_ENTER(0x7004533a90ull);
L_7004533a90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533aa0(Cpu *c) {
    FN_ENTER(0x7004533aa0ull);
L_7004533aa0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ab0(Cpu *c) {
    FN_ENTER(0x7004533ab0ull);
L_7004533ab0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ac0(Cpu *c) {
    FN_ENTER(0x7004533ac0ull);
L_7004533ac0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ad0(Cpu *c) {
    FN_ENTER(0x7004533ad0ull);
L_7004533ad0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ae0(Cpu *c) {
    FN_ENTER(0x7004533ae0ull);
L_7004533ae0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533af0(Cpu *c) {
    FN_ENTER(0x7004533af0ull);
L_7004533af0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b00(Cpu *c) {
    FN_ENTER(0x7004533b00ull);
L_7004533b00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b10(Cpu *c) {
    FN_ENTER(0x7004533b10ull);
L_7004533b10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b20(Cpu *c) {
    FN_ENTER(0x7004533b20ull);
L_7004533b20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b30(Cpu *c) {
    FN_ENTER(0x7004533b30ull);
L_7004533b30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b40(Cpu *c) {
    FN_ENTER(0x7004533b40ull);
L_7004533b40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b50(Cpu *c) {
    FN_ENTER(0x7004533b50ull);
L_7004533b50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b60(Cpu *c) {
    FN_ENTER(0x7004533b60ull);
L_7004533b60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b70(Cpu *c) {
    FN_ENTER(0x7004533b70ull);
L_7004533b70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b80(Cpu *c) {
    FN_ENTER(0x7004533b80ull);
L_7004533b80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533b90(Cpu *c) {
    FN_ENTER(0x7004533b90ull);
L_7004533b90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ba0(Cpu *c) {
    FN_ENTER(0x7004533ba0ull);
L_7004533ba0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533bb0(Cpu *c) {
    FN_ENTER(0x7004533bb0ull);
L_7004533bb0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533bc0(Cpu *c) {
    FN_ENTER(0x7004533bc0ull);
L_7004533bc0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533bd0(Cpu *c) {
    FN_ENTER(0x7004533bd0ull);
L_7004533bd0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533be0(Cpu *c) {
    FN_ENTER(0x7004533be0ull);
L_7004533be0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533bf0(Cpu *c) {
    FN_ENTER(0x7004533bf0ull);
L_7004533bf0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c00(Cpu *c) {
    FN_ENTER(0x7004533c00ull);
L_7004533c00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c10(Cpu *c) {
    FN_ENTER(0x7004533c10ull);
L_7004533c10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c20(Cpu *c) {
    FN_ENTER(0x7004533c20ull);
L_7004533c20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c30(Cpu *c) {
    FN_ENTER(0x7004533c30ull);
L_7004533c30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c40(Cpu *c) {
    FN_ENTER(0x7004533c40ull);
L_7004533c40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c50(Cpu *c) {
    FN_ENTER(0x7004533c50ull);
L_7004533c50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c60(Cpu *c) {
    FN_ENTER(0x7004533c60ull);
L_7004533c60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c70(Cpu *c) {
    FN_ENTER(0x7004533c70ull);
L_7004533c70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c80(Cpu *c) {
    FN_ENTER(0x7004533c80ull);
L_7004533c80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533c90(Cpu *c) {
    FN_ENTER(0x7004533c90ull);
L_7004533c90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ca0(Cpu *c) {
    FN_ENTER(0x7004533ca0ull);
L_7004533ca0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533cb0(Cpu *c) {
    FN_ENTER(0x7004533cb0ull);
L_7004533cb0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533cc0(Cpu *c) {
    FN_ENTER(0x7004533cc0ull);
L_7004533cc0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533cd0(Cpu *c) {
    FN_ENTER(0x7004533cd0ull);
L_7004533cd0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ce0(Cpu *c) {
    FN_ENTER(0x7004533ce0ull);
L_7004533ce0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533cf0(Cpu *c) {
    FN_ENTER(0x7004533cf0ull);
L_7004533cf0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d00(Cpu *c) {
    FN_ENTER(0x7004533d00ull);
L_7004533d00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d10(Cpu *c) {
    FN_ENTER(0x7004533d10ull);
L_7004533d10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d20(Cpu *c) {
    FN_ENTER(0x7004533d20ull);
L_7004533d20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d30(Cpu *c) {
    FN_ENTER(0x7004533d30ull);
L_7004533d30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d40(Cpu *c) {
    FN_ENTER(0x7004533d40ull);
L_7004533d40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d50(Cpu *c) {
    FN_ENTER(0x7004533d50ull);
L_7004533d50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d60(Cpu *c) {
    FN_ENTER(0x7004533d60ull);
L_7004533d60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d70(Cpu *c) {
    FN_ENTER(0x7004533d70ull);
L_7004533d70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d80(Cpu *c) {
    FN_ENTER(0x7004533d80ull);
L_7004533d80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533d90(Cpu *c) {
    FN_ENTER(0x7004533d90ull);
L_7004533d90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533da0(Cpu *c) {
    FN_ENTER(0x7004533da0ull);
L_7004533da0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533db0(Cpu *c) {
    FN_ENTER(0x7004533db0ull);
L_7004533db0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533dc0(Cpu *c) {
    FN_ENTER(0x7004533dc0ull);
L_7004533dc0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533dd0(Cpu *c) {
    FN_ENTER(0x7004533dd0ull);
L_7004533dd0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533de0(Cpu *c) {
    FN_ENTER(0x7004533de0ull);
L_7004533de0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533df0(Cpu *c) {
    FN_ENTER(0x7004533df0ull);
L_7004533df0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e00(Cpu *c) {
    FN_ENTER(0x7004533e00ull);
L_7004533e00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e10(Cpu *c) {
    FN_ENTER(0x7004533e10ull);
L_7004533e10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e20(Cpu *c) {
    FN_ENTER(0x7004533e20ull);
L_7004533e20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e30(Cpu *c) {
    FN_ENTER(0x7004533e30ull);
L_7004533e30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e40(Cpu *c) {
    FN_ENTER(0x7004533e40ull);
L_7004533e40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e50(Cpu *c) {
    FN_ENTER(0x7004533e50ull);
L_7004533e50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e60(Cpu *c) {
    FN_ENTER(0x7004533e60ull);
L_7004533e60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e70(Cpu *c) {
    FN_ENTER(0x7004533e70ull);
L_7004533e70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e80(Cpu *c) {
    FN_ENTER(0x7004533e80ull);
L_7004533e80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533e90(Cpu *c) {
    FN_ENTER(0x7004533e90ull);
L_7004533e90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ea0(Cpu *c) {
    FN_ENTER(0x7004533ea0ull);
L_7004533ea0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533eb0(Cpu *c) {
    FN_ENTER(0x7004533eb0ull);
L_7004533eb0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ec0(Cpu *c) {
    FN_ENTER(0x7004533ec0ull);
L_7004533ec0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ed0(Cpu *c) {
    FN_ENTER(0x7004533ed0ull);
L_7004533ed0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ee0(Cpu *c) {
    FN_ENTER(0x7004533ee0ull);
L_7004533ee0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ef0(Cpu *c) {
    FN_ENTER(0x7004533ef0ull);
L_7004533ef0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f00(Cpu *c) {
    FN_ENTER(0x7004533f00ull);
L_7004533f00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f10(Cpu *c) {
    FN_ENTER(0x7004533f10ull);
L_7004533f10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f20(Cpu *c) {
    FN_ENTER(0x7004533f20ull);
L_7004533f20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f30(Cpu *c) {
    FN_ENTER(0x7004533f30ull);
L_7004533f30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f40(Cpu *c) {
    FN_ENTER(0x7004533f40ull);
L_7004533f40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f50(Cpu *c) {
    FN_ENTER(0x7004533f50ull);
L_7004533f50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f60(Cpu *c) {
    FN_ENTER(0x7004533f60ull);
L_7004533f60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f70(Cpu *c) {
    FN_ENTER(0x7004533f70ull);
L_7004533f70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f80(Cpu *c) {
    FN_ENTER(0x7004533f80ull);
L_7004533f80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533f90(Cpu *c) {
    FN_ENTER(0x7004533f90ull);
L_7004533f90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533fa0(Cpu *c) {
    FN_ENTER(0x7004533fa0ull);
L_7004533fa0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533fb0(Cpu *c) {
    FN_ENTER(0x7004533fb0ull);
L_7004533fb0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533fc0(Cpu *c) {
    FN_ENTER(0x7004533fc0ull);
L_7004533fc0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533fd0(Cpu *c) {
    FN_ENTER(0x7004533fd0ull);
L_7004533fd0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533fe0(Cpu *c) {
    FN_ENTER(0x7004533fe0ull);
L_7004533fe0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004533ff0(Cpu *c) {
    FN_ENTER(0x7004533ff0ull);
L_7004533ff0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534000(Cpu *c) {
    FN_ENTER(0x7004534000ull);
L_7004534000:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534010(Cpu *c) {
    FN_ENTER(0x7004534010ull);
L_7004534010:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534020(Cpu *c) {
    FN_ENTER(0x7004534020ull);
L_7004534020:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534030(Cpu *c) {
    FN_ENTER(0x7004534030ull);
L_7004534030:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534040(Cpu *c) {
    FN_ENTER(0x7004534040ull);
L_7004534040:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534050(Cpu *c) {
    FN_ENTER(0x7004534050ull);
L_7004534050:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534060(Cpu *c) {
    FN_ENTER(0x7004534060ull);
L_7004534060:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534070(Cpu *c) {
    FN_ENTER(0x7004534070ull);
L_7004534070:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534080(Cpu *c) {
    FN_ENTER(0x7004534080ull);
L_7004534080:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534090(Cpu *c) {
    FN_ENTER(0x7004534090ull);
L_7004534090:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045340a0(Cpu *c) {
    FN_ENTER(0x70045340a0ull);
L_70045340a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045340b0(Cpu *c) {
    FN_ENTER(0x70045340b0ull);
L_70045340b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045340c0(Cpu *c) {
    FN_ENTER(0x70045340c0ull);
L_70045340c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045340d0(Cpu *c) {
    FN_ENTER(0x70045340d0ull);
L_70045340d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045340e0(Cpu *c) {
    FN_ENTER(0x70045340e0ull);
L_70045340e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045340f0(Cpu *c) {
    FN_ENTER(0x70045340f0ull);
L_70045340f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534100(Cpu *c) {
    FN_ENTER(0x7004534100ull);
L_7004534100:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534110(Cpu *c) {
    FN_ENTER(0x7004534110ull);
L_7004534110:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534120(Cpu *c) {
    FN_ENTER(0x7004534120ull);
L_7004534120:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534130(Cpu *c) {
    FN_ENTER(0x7004534130ull);
L_7004534130:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534140(Cpu *c) {
    FN_ENTER(0x7004534140ull);
L_7004534140:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534150(Cpu *c) {
    FN_ENTER(0x7004534150ull);
L_7004534150:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534160(Cpu *c) {
    FN_ENTER(0x7004534160ull);
L_7004534160:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534170(Cpu *c) {
    FN_ENTER(0x7004534170ull);
L_7004534170:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534180(Cpu *c) {
    FN_ENTER(0x7004534180ull);
L_7004534180:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534190(Cpu *c) {
    FN_ENTER(0x7004534190ull);
L_7004534190:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045341a0(Cpu *c) {
    FN_ENTER(0x70045341a0ull);
L_70045341a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045341b0(Cpu *c) {
    FN_ENTER(0x70045341b0ull);
L_70045341b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045341c0(Cpu *c) {
    FN_ENTER(0x70045341c0ull);
L_70045341c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045341d0(Cpu *c) {
    FN_ENTER(0x70045341d0ull);
L_70045341d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045341e0(Cpu *c) {
    FN_ENTER(0x70045341e0ull);
L_70045341e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045341f0(Cpu *c) {
    FN_ENTER(0x70045341f0ull);
L_70045341f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534200(Cpu *c) {
    FN_ENTER(0x7004534200ull);
L_7004534200:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534210(Cpu *c) {
    FN_ENTER(0x7004534210ull);
L_7004534210:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534220(Cpu *c) {
    FN_ENTER(0x7004534220ull);
L_7004534220:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534230(Cpu *c) {
    FN_ENTER(0x7004534230ull);
L_7004534230:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534240(Cpu *c) {
    FN_ENTER(0x7004534240ull);
L_7004534240:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534250(Cpu *c) {
    FN_ENTER(0x7004534250ull);
L_7004534250:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534260(Cpu *c) {
    FN_ENTER(0x7004534260ull);
L_7004534260:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534270(Cpu *c) {
    FN_ENTER(0x7004534270ull);
L_7004534270:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534280(Cpu *c) {
    FN_ENTER(0x7004534280ull);
L_7004534280:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534290(Cpu *c) {
    FN_ENTER(0x7004534290ull);
L_7004534290:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045342a0(Cpu *c) {
    FN_ENTER(0x70045342a0ull);
L_70045342a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045342b0(Cpu *c) {
    FN_ENTER(0x70045342b0ull);
L_70045342b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045342c0(Cpu *c) {
    FN_ENTER(0x70045342c0ull);
L_70045342c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045342d0(Cpu *c) {
    FN_ENTER(0x70045342d0ull);
L_70045342d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045342e0(Cpu *c) {
    FN_ENTER(0x70045342e0ull);
L_70045342e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045342f0(Cpu *c) {
    FN_ENTER(0x70045342f0ull);
L_70045342f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534300(Cpu *c) {
    FN_ENTER(0x7004534300ull);
L_7004534300:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534310(Cpu *c) {
    FN_ENTER(0x7004534310ull);
L_7004534310:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534320(Cpu *c) {
    FN_ENTER(0x7004534320ull);
L_7004534320:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534330(Cpu *c) {
    FN_ENTER(0x7004534330ull);
L_7004534330:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534340(Cpu *c) {
    FN_ENTER(0x7004534340ull);
L_7004534340:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534350(Cpu *c) {
    FN_ENTER(0x7004534350ull);
L_7004534350:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534360(Cpu *c) {
    FN_ENTER(0x7004534360ull);
L_7004534360:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534370(Cpu *c) {
    FN_ENTER(0x7004534370ull);
L_7004534370:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534380(Cpu *c) {
    FN_ENTER(0x7004534380ull);
L_7004534380:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534390(Cpu *c) {
    FN_ENTER(0x7004534390ull);
L_7004534390:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045343a0(Cpu *c) {
    FN_ENTER(0x70045343a0ull);
L_70045343a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045343b0(Cpu *c) {
    FN_ENTER(0x70045343b0ull);
L_70045343b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045343c0(Cpu *c) {
    FN_ENTER(0x70045343c0ull);
L_70045343c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045343d0(Cpu *c) {
    FN_ENTER(0x70045343d0ull);
L_70045343d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045343e0(Cpu *c) {
    FN_ENTER(0x70045343e0ull);
L_70045343e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045343f0(Cpu *c) {
    FN_ENTER(0x70045343f0ull);
L_70045343f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534400(Cpu *c) {
    FN_ENTER(0x7004534400ull);
L_7004534400:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534410(Cpu *c) {
    FN_ENTER(0x7004534410ull);
L_7004534410:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534420(Cpu *c) {
    FN_ENTER(0x7004534420ull);
L_7004534420:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534430(Cpu *c) {
    FN_ENTER(0x7004534430ull);
L_7004534430:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534440(Cpu *c) {
    FN_ENTER(0x7004534440ull);
L_7004534440:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534450(Cpu *c) {
    FN_ENTER(0x7004534450ull);
L_7004534450:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534460(Cpu *c) {
    FN_ENTER(0x7004534460ull);
L_7004534460:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534470(Cpu *c) {
    FN_ENTER(0x7004534470ull);
L_7004534470:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534480(Cpu *c) {
    FN_ENTER(0x7004534480ull);
L_7004534480:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534490(Cpu *c) {
    FN_ENTER(0x7004534490ull);
L_7004534490:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045344a0(Cpu *c) {
    FN_ENTER(0x70045344a0ull);
L_70045344a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045344b0(Cpu *c) {
    FN_ENTER(0x70045344b0ull);
L_70045344b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045344c0(Cpu *c) {
    FN_ENTER(0x70045344c0ull);
L_70045344c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045344d0(Cpu *c) {
    FN_ENTER(0x70045344d0ull);
L_70045344d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045344e0(Cpu *c) {
    FN_ENTER(0x70045344e0ull);
L_70045344e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045344f0(Cpu *c) {
    FN_ENTER(0x70045344f0ull);
L_70045344f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534500(Cpu *c) {
    FN_ENTER(0x7004534500ull);
L_7004534500:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534510(Cpu *c) {
    FN_ENTER(0x7004534510ull);
L_7004534510:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534520(Cpu *c) {
    FN_ENTER(0x7004534520ull);
L_7004534520:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534530(Cpu *c) {
    FN_ENTER(0x7004534530ull);
L_7004534530:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534540(Cpu *c) {
    FN_ENTER(0x7004534540ull);
L_7004534540:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534550(Cpu *c) {
    FN_ENTER(0x7004534550ull);
L_7004534550:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534560(Cpu *c) {
    FN_ENTER(0x7004534560ull);
L_7004534560:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534570(Cpu *c) {
    FN_ENTER(0x7004534570ull);
L_7004534570:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534580(Cpu *c) {
    FN_ENTER(0x7004534580ull);
L_7004534580:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534590(Cpu *c) {
    FN_ENTER(0x7004534590ull);
L_7004534590:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045345a0(Cpu *c) {
    FN_ENTER(0x70045345a0ull);
L_70045345a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045345b0(Cpu *c) {
    FN_ENTER(0x70045345b0ull);
L_70045345b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045345c0(Cpu *c) {
    FN_ENTER(0x70045345c0ull);
L_70045345c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045345d0(Cpu *c) {
    FN_ENTER(0x70045345d0ull);
L_70045345d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045345e0(Cpu *c) {
    FN_ENTER(0x70045345e0ull);
L_70045345e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045345f0(Cpu *c) {
    FN_ENTER(0x70045345f0ull);
L_70045345f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534600(Cpu *c) {
    FN_ENTER(0x7004534600ull);
L_7004534600:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534610(Cpu *c) {
    FN_ENTER(0x7004534610ull);
L_7004534610:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534620(Cpu *c) {
    FN_ENTER(0x7004534620ull);
L_7004534620:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534630(Cpu *c) {
    FN_ENTER(0x7004534630ull);
L_7004534630:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534640(Cpu *c) {
    FN_ENTER(0x7004534640ull);
L_7004534640:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534650(Cpu *c) {
    FN_ENTER(0x7004534650ull);
L_7004534650:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534660(Cpu *c) {
    FN_ENTER(0x7004534660ull);
L_7004534660:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534670(Cpu *c) {
    FN_ENTER(0x7004534670ull);
L_7004534670:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534680(Cpu *c) {
    FN_ENTER(0x7004534680ull);
L_7004534680:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534690(Cpu *c) {
    FN_ENTER(0x7004534690ull);
L_7004534690:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045346a0(Cpu *c) {
    FN_ENTER(0x70045346a0ull);
L_70045346a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045346b0(Cpu *c) {
    FN_ENTER(0x70045346b0ull);
L_70045346b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045346c0(Cpu *c) {
    FN_ENTER(0x70045346c0ull);
L_70045346c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045346d0(Cpu *c) {
    FN_ENTER(0x70045346d0ull);
L_70045346d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045346e0(Cpu *c) {
    FN_ENTER(0x70045346e0ull);
L_70045346e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045346f0(Cpu *c) {
    FN_ENTER(0x70045346f0ull);
L_70045346f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534700(Cpu *c) {
    FN_ENTER(0x7004534700ull);
L_7004534700:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534710(Cpu *c) {
    FN_ENTER(0x7004534710ull);
L_7004534710:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534720(Cpu *c) {
    FN_ENTER(0x7004534720ull);
L_7004534720:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534730(Cpu *c) {
    FN_ENTER(0x7004534730ull);
L_7004534730:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534740(Cpu *c) {
    FN_ENTER(0x7004534740ull);
L_7004534740:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534750(Cpu *c) {
    FN_ENTER(0x7004534750ull);
L_7004534750:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534760(Cpu *c) {
    FN_ENTER(0x7004534760ull);
L_7004534760:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534770(Cpu *c) {
    FN_ENTER(0x7004534770ull);
L_7004534770:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534780(Cpu *c) {
    FN_ENTER(0x7004534780ull);
L_7004534780:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534790(Cpu *c) {
    FN_ENTER(0x7004534790ull);
L_7004534790:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045347a0(Cpu *c) {
    FN_ENTER(0x70045347a0ull);
L_70045347a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045347b0(Cpu *c) {
    FN_ENTER(0x70045347b0ull);
L_70045347b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045347c0(Cpu *c) {
    FN_ENTER(0x70045347c0ull);
L_70045347c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045347d0(Cpu *c) {
    FN_ENTER(0x70045347d0ull);
L_70045347d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045347e0(Cpu *c) {
    FN_ENTER(0x70045347e0ull);
L_70045347e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045347f0(Cpu *c) {
    FN_ENTER(0x70045347f0ull);
L_70045347f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534800(Cpu *c) {
    FN_ENTER(0x7004534800ull);
L_7004534800:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534810(Cpu *c) {
    FN_ENTER(0x7004534810ull);
L_7004534810:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534820(Cpu *c) {
    FN_ENTER(0x7004534820ull);
L_7004534820:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534830(Cpu *c) {
    FN_ENTER(0x7004534830ull);
L_7004534830:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534840(Cpu *c) {
    FN_ENTER(0x7004534840ull);
L_7004534840:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534850(Cpu *c) {
    FN_ENTER(0x7004534850ull);
L_7004534850:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534860(Cpu *c) {
    FN_ENTER(0x7004534860ull);
L_7004534860:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534870(Cpu *c) {
    FN_ENTER(0x7004534870ull);
L_7004534870:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534880(Cpu *c) {
    FN_ENTER(0x7004534880ull);
L_7004534880:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534890(Cpu *c) {
    FN_ENTER(0x7004534890ull);
L_7004534890:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045348a0(Cpu *c) {
    FN_ENTER(0x70045348a0ull);
L_70045348a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045348b0(Cpu *c) {
    FN_ENTER(0x70045348b0ull);
L_70045348b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045348c0(Cpu *c) {
    FN_ENTER(0x70045348c0ull);
L_70045348c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045348d0(Cpu *c) {
    FN_ENTER(0x70045348d0ull);
L_70045348d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045348e0(Cpu *c) {
    FN_ENTER(0x70045348e0ull);
L_70045348e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045348f0(Cpu *c) {
    FN_ENTER(0x70045348f0ull);
L_70045348f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534900(Cpu *c) {
    FN_ENTER(0x7004534900ull);
L_7004534900:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534910(Cpu *c) {
    FN_ENTER(0x7004534910ull);
L_7004534910:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534920(Cpu *c) {
    FN_ENTER(0x7004534920ull);
L_7004534920:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534930(Cpu *c) {
    FN_ENTER(0x7004534930ull);
L_7004534930:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534940(Cpu *c) {
    FN_ENTER(0x7004534940ull);
L_7004534940:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534950(Cpu *c) {
    FN_ENTER(0x7004534950ull);
L_7004534950:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534960(Cpu *c) {
    FN_ENTER(0x7004534960ull);
L_7004534960:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534970(Cpu *c) {
    FN_ENTER(0x7004534970ull);
L_7004534970:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534980(Cpu *c) {
    FN_ENTER(0x7004534980ull);
L_7004534980:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534990(Cpu *c) {
    FN_ENTER(0x7004534990ull);
L_7004534990:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045349a0(Cpu *c) {
    FN_ENTER(0x70045349a0ull);
L_70045349a0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045349b0(Cpu *c) {
    FN_ENTER(0x70045349b0ull);
L_70045349b0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045349c0(Cpu *c) {
    FN_ENTER(0x70045349c0ull);
L_70045349c0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045349d0(Cpu *c) {
    FN_ENTER(0x70045349d0ull);
L_70045349d0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045349e0(Cpu *c) {
    FN_ENTER(0x70045349e0ull);
L_70045349e0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045349f0(Cpu *c) {
    FN_ENTER(0x70045349f0ull);
L_70045349f0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a00(Cpu *c) {
    FN_ENTER(0x7004534a00ull);
L_7004534a00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a10(Cpu *c) {
    FN_ENTER(0x7004534a10ull);
L_7004534a10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a20(Cpu *c) {
    FN_ENTER(0x7004534a20ull);
L_7004534a20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a30(Cpu *c) {
    FN_ENTER(0x7004534a30ull);
L_7004534a30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a40(Cpu *c) {
    FN_ENTER(0x7004534a40ull);
L_7004534a40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a50(Cpu *c) {
    FN_ENTER(0x7004534a50ull);
L_7004534a50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a60(Cpu *c) {
    FN_ENTER(0x7004534a60ull);
L_7004534a60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a70(Cpu *c) {
    FN_ENTER(0x7004534a70ull);
L_7004534a70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a80(Cpu *c) {
    FN_ENTER(0x7004534a80ull);
L_7004534a80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534a90(Cpu *c) {
    FN_ENTER(0x7004534a90ull);
L_7004534a90:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534aa0(Cpu *c) {
    FN_ENTER(0x7004534aa0ull);
L_7004534aa0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ab0(Cpu *c) {
    FN_ENTER(0x7004534ab0ull);
L_7004534ab0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ac0(Cpu *c) {
    FN_ENTER(0x7004534ac0ull);
L_7004534ac0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ad0(Cpu *c) {
    FN_ENTER(0x7004534ad0ull);
L_7004534ad0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ae0(Cpu *c) {
    FN_ENTER(0x7004534ae0ull);
L_7004534ae0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534af0(Cpu *c) {
    FN_ENTER(0x7004534af0ull);
L_7004534af0:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b00(Cpu *c) {
    FN_ENTER(0x7004534b00ull);
L_7004534b00:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b10(Cpu *c) {
    FN_ENTER(0x7004534b10ull);
L_7004534b10:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b20(Cpu *c) {
    FN_ENTER(0x7004534b20ull);
L_7004534b20:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b30(Cpu *c) {
    FN_ENTER(0x7004534b30ull);
L_7004534b30:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b40(Cpu *c) {
    FN_ENTER(0x7004534b40ull);
L_7004534b40:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b50(Cpu *c) {
    FN_ENTER(0x7004534b50ull);
L_7004534b50:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b60(Cpu *c) {
    FN_ENTER(0x7004534b60ull);
L_7004534b60:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b70(Cpu *c) {
    FN_ENTER(0x7004534b70ull);
L_7004534b70:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b80(Cpu *c) {
    FN_ENTER(0x7004534b80ull);
L_7004534b80:;
    c->x[16] = (uint64_t)(0x7004c32000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534b90(Cpu *c) {
    FN_ENTER(0x7004534b90ull);
L_7004534b90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ba0(Cpu *c) {
    FN_ENTER(0x7004534ba0ull);
L_7004534ba0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534bb0(Cpu *c) {
    FN_ENTER(0x7004534bb0ull);
L_7004534bb0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534bc0(Cpu *c) {
    FN_ENTER(0x7004534bc0ull);
L_7004534bc0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534bd0(Cpu *c) {
    FN_ENTER(0x7004534bd0ull);
L_7004534bd0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534be0(Cpu *c) {
    FN_ENTER(0x7004534be0ull);
L_7004534be0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534bf0(Cpu *c) {
    FN_ENTER(0x7004534bf0ull);
L_7004534bf0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c00(Cpu *c) {
    FN_ENTER(0x7004534c00ull);
L_7004534c00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c10(Cpu *c) {
    FN_ENTER(0x7004534c10ull);
L_7004534c10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c20(Cpu *c) {
    FN_ENTER(0x7004534c20ull);
L_7004534c20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c30(Cpu *c) {
    FN_ENTER(0x7004534c30ull);
L_7004534c30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c40(Cpu *c) {
    FN_ENTER(0x7004534c40ull);
L_7004534c40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c50(Cpu *c) {
    FN_ENTER(0x7004534c50ull);
L_7004534c50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c60(Cpu *c) {
    FN_ENTER(0x7004534c60ull);
L_7004534c60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c70(Cpu *c) {
    FN_ENTER(0x7004534c70ull);
L_7004534c70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c80(Cpu *c) {
    FN_ENTER(0x7004534c80ull);
L_7004534c80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534c90(Cpu *c) {
    FN_ENTER(0x7004534c90ull);
L_7004534c90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ca0(Cpu *c) {
    FN_ENTER(0x7004534ca0ull);
L_7004534ca0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534cb0(Cpu *c) {
    FN_ENTER(0x7004534cb0ull);
L_7004534cb0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534cc0(Cpu *c) {
    FN_ENTER(0x7004534cc0ull);
L_7004534cc0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534cd0(Cpu *c) {
    FN_ENTER(0x7004534cd0ull);
L_7004534cd0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ce0(Cpu *c) {
    FN_ENTER(0x7004534ce0ull);
L_7004534ce0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534cf0(Cpu *c) {
    FN_ENTER(0x7004534cf0ull);
L_7004534cf0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d00(Cpu *c) {
    FN_ENTER(0x7004534d00ull);
L_7004534d00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d10(Cpu *c) {
    FN_ENTER(0x7004534d10ull);
L_7004534d10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d20(Cpu *c) {
    FN_ENTER(0x7004534d20ull);
L_7004534d20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d30(Cpu *c) {
    FN_ENTER(0x7004534d30ull);
L_7004534d30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d40(Cpu *c) {
    FN_ENTER(0x7004534d40ull);
L_7004534d40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d50(Cpu *c) {
    FN_ENTER(0x7004534d50ull);
L_7004534d50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d60(Cpu *c) {
    FN_ENTER(0x7004534d60ull);
L_7004534d60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d70(Cpu *c) {
    FN_ENTER(0x7004534d70ull);
L_7004534d70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d80(Cpu *c) {
    FN_ENTER(0x7004534d80ull);
L_7004534d80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534d90(Cpu *c) {
    FN_ENTER(0x7004534d90ull);
L_7004534d90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x100ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x100ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534da0(Cpu *c) {
    FN_ENTER(0x7004534da0ull);
L_7004534da0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x108ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x108ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534db0(Cpu *c) {
    FN_ENTER(0x7004534db0ull);
L_7004534db0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x110ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x110ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534dc0(Cpu *c) {
    FN_ENTER(0x7004534dc0ull);
L_7004534dc0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x118ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x118ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534dd0(Cpu *c) {
    FN_ENTER(0x7004534dd0ull);
L_7004534dd0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x120ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x120ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534de0(Cpu *c) {
    FN_ENTER(0x7004534de0ull);
L_7004534de0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x128ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x128ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534df0(Cpu *c) {
    FN_ENTER(0x7004534df0ull);
L_7004534df0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x130ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x130ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e00(Cpu *c) {
    FN_ENTER(0x7004534e00ull);
L_7004534e00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x138ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x138ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e10(Cpu *c) {
    FN_ENTER(0x7004534e10ull);
L_7004534e10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x140ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x140ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e20(Cpu *c) {
    FN_ENTER(0x7004534e20ull);
L_7004534e20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x148ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x148ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e30(Cpu *c) {
    FN_ENTER(0x7004534e30ull);
L_7004534e30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x150ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x150ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e40(Cpu *c) {
    FN_ENTER(0x7004534e40ull);
L_7004534e40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x158ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x158ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e50(Cpu *c) {
    FN_ENTER(0x7004534e50ull);
L_7004534e50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x160ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x160ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e60(Cpu *c) {
    FN_ENTER(0x7004534e60ull);
L_7004534e60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x168ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x168ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e70(Cpu *c) {
    FN_ENTER(0x7004534e70ull);
L_7004534e70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x170ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x170ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e80(Cpu *c) {
    FN_ENTER(0x7004534e80ull);
L_7004534e80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x178ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x178ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534e90(Cpu *c) {
    FN_ENTER(0x7004534e90ull);
L_7004534e90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x180ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x180ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ea0(Cpu *c) {
    FN_ENTER(0x7004534ea0ull);
L_7004534ea0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x188ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x188ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534eb0(Cpu *c) {
    FN_ENTER(0x7004534eb0ull);
L_7004534eb0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x190ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x190ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ec0(Cpu *c) {
    FN_ENTER(0x7004534ec0ull);
L_7004534ec0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x198ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x198ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ed0(Cpu *c) {
    FN_ENTER(0x7004534ed0ull);
L_7004534ed0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ee0(Cpu *c) {
    FN_ENTER(0x7004534ee0ull);
L_7004534ee0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ef0(Cpu *c) {
    FN_ENTER(0x7004534ef0ull);
L_7004534ef0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f00(Cpu *c) {
    FN_ENTER(0x7004534f00ull);
L_7004534f00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f10(Cpu *c) {
    FN_ENTER(0x7004534f10ull);
L_7004534f10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f20(Cpu *c) {
    FN_ENTER(0x7004534f20ull);
L_7004534f20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f30(Cpu *c) {
    FN_ENTER(0x7004534f30ull);
L_7004534f30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f40(Cpu *c) {
    FN_ENTER(0x7004534f40ull);
L_7004534f40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f50(Cpu *c) {
    FN_ENTER(0x7004534f50ull);
L_7004534f50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f60(Cpu *c) {
    FN_ENTER(0x7004534f60ull);
L_7004534f60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f70(Cpu *c) {
    FN_ENTER(0x7004534f70ull);
L_7004534f70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f80(Cpu *c) {
    FN_ENTER(0x7004534f80ull);
L_7004534f80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x1f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534f90(Cpu *c) {
    FN_ENTER(0x7004534f90ull);
L_7004534f90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x200ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x200ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534fa0(Cpu *c) {
    FN_ENTER(0x7004534fa0ull);
L_7004534fa0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x208ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x208ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534fb0(Cpu *c) {
    FN_ENTER(0x7004534fb0ull);
L_7004534fb0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x210ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x210ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534fc0(Cpu *c) {
    FN_ENTER(0x7004534fc0ull);
L_7004534fc0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x218ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x218ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534fd0(Cpu *c) {
    FN_ENTER(0x7004534fd0ull);
L_7004534fd0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x220ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x220ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534fe0(Cpu *c) {
    FN_ENTER(0x7004534fe0ull);
L_7004534fe0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x228ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x228ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004534ff0(Cpu *c) {
    FN_ENTER(0x7004534ff0ull);
L_7004534ff0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x230ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x230ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535000(Cpu *c) {
    FN_ENTER(0x7004535000ull);
L_7004535000:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x238ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x238ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535010(Cpu *c) {
    FN_ENTER(0x7004535010ull);
L_7004535010:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x240ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x240ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535020(Cpu *c) {
    FN_ENTER(0x7004535020ull);
L_7004535020:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x248ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x248ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535030(Cpu *c) {
    FN_ENTER(0x7004535030ull);
L_7004535030:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x250ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x250ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535040(Cpu *c) {
    FN_ENTER(0x7004535040ull);
L_7004535040:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x258ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x258ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535050(Cpu *c) {
    FN_ENTER(0x7004535050ull);
L_7004535050:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x260ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x260ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535060(Cpu *c) {
    FN_ENTER(0x7004535060ull);
L_7004535060:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x268ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x268ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535070(Cpu *c) {
    FN_ENTER(0x7004535070ull);
L_7004535070:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x270ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x270ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535080(Cpu *c) {
    FN_ENTER(0x7004535080ull);
L_7004535080:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x278ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x278ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535090(Cpu *c) {
    FN_ENTER(0x7004535090ull);
L_7004535090:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x280ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x280ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045350a0(Cpu *c) {
    FN_ENTER(0x70045350a0ull);
L_70045350a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x288ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x288ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045350b0(Cpu *c) {
    FN_ENTER(0x70045350b0ull);
L_70045350b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x290ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x290ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045350c0(Cpu *c) {
    FN_ENTER(0x70045350c0ull);
L_70045350c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x298ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x298ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045350d0(Cpu *c) {
    FN_ENTER(0x70045350d0ull);
L_70045350d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045350e0(Cpu *c) {
    FN_ENTER(0x70045350e0ull);
L_70045350e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045350f0(Cpu *c) {
    FN_ENTER(0x70045350f0ull);
L_70045350f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535100(Cpu *c) {
    FN_ENTER(0x7004535100ull);
L_7004535100:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535110(Cpu *c) {
    FN_ENTER(0x7004535110ull);
L_7004535110:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535120(Cpu *c) {
    FN_ENTER(0x7004535120ull);
L_7004535120:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535130(Cpu *c) {
    FN_ENTER(0x7004535130ull);
L_7004535130:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535140(Cpu *c) {
    FN_ENTER(0x7004535140ull);
L_7004535140:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535150(Cpu *c) {
    FN_ENTER(0x7004535150ull);
L_7004535150:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535160(Cpu *c) {
    FN_ENTER(0x7004535160ull);
L_7004535160:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535170(Cpu *c) {
    FN_ENTER(0x7004535170ull);
L_7004535170:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535180(Cpu *c) {
    FN_ENTER(0x7004535180ull);
L_7004535180:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x2f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535190(Cpu *c) {
    FN_ENTER(0x7004535190ull);
L_7004535190:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x300ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x300ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045351a0(Cpu *c) {
    FN_ENTER(0x70045351a0ull);
L_70045351a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x308ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x308ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045351b0(Cpu *c) {
    FN_ENTER(0x70045351b0ull);
L_70045351b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x310ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x310ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045351c0(Cpu *c) {
    FN_ENTER(0x70045351c0ull);
L_70045351c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x318ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x318ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045351d0(Cpu *c) {
    FN_ENTER(0x70045351d0ull);
L_70045351d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x320ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x320ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045351e0(Cpu *c) {
    FN_ENTER(0x70045351e0ull);
L_70045351e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x328ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x328ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045351f0(Cpu *c) {
    FN_ENTER(0x70045351f0ull);
L_70045351f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x330ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x330ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535200(Cpu *c) {
    FN_ENTER(0x7004535200ull);
L_7004535200:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x338ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x338ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535210(Cpu *c) {
    FN_ENTER(0x7004535210ull);
L_7004535210:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x340ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x340ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535220(Cpu *c) {
    FN_ENTER(0x7004535220ull);
L_7004535220:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x348ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x348ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535230(Cpu *c) {
    FN_ENTER(0x7004535230ull);
L_7004535230:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x350ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x350ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535240(Cpu *c) {
    FN_ENTER(0x7004535240ull);
L_7004535240:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x358ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x358ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535250(Cpu *c) {
    FN_ENTER(0x7004535250ull);
L_7004535250:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x360ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x360ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535260(Cpu *c) {
    FN_ENTER(0x7004535260ull);
L_7004535260:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x368ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x368ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535270(Cpu *c) {
    FN_ENTER(0x7004535270ull);
L_7004535270:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x370ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x370ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535280(Cpu *c) {
    FN_ENTER(0x7004535280ull);
L_7004535280:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x378ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x378ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535290(Cpu *c) {
    FN_ENTER(0x7004535290ull);
L_7004535290:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x380ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x380ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045352a0(Cpu *c) {
    FN_ENTER(0x70045352a0ull);
L_70045352a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x388ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x388ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045352b0(Cpu *c) {
    FN_ENTER(0x70045352b0ull);
L_70045352b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x390ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x390ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045352c0(Cpu *c) {
    FN_ENTER(0x70045352c0ull);
L_70045352c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x398ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x398ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045352d0(Cpu *c) {
    FN_ENTER(0x70045352d0ull);
L_70045352d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045352e0(Cpu *c) {
    FN_ENTER(0x70045352e0ull);
L_70045352e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045352f0(Cpu *c) {
    FN_ENTER(0x70045352f0ull);
L_70045352f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535300(Cpu *c) {
    FN_ENTER(0x7004535300ull);
L_7004535300:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535310(Cpu *c) {
    FN_ENTER(0x7004535310ull);
L_7004535310:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535320(Cpu *c) {
    FN_ENTER(0x7004535320ull);
L_7004535320:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535330(Cpu *c) {
    FN_ENTER(0x7004535330ull);
L_7004535330:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535340(Cpu *c) {
    FN_ENTER(0x7004535340ull);
L_7004535340:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535350(Cpu *c) {
    FN_ENTER(0x7004535350ull);
L_7004535350:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535360(Cpu *c) {
    FN_ENTER(0x7004535360ull);
L_7004535360:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535370(Cpu *c) {
    FN_ENTER(0x7004535370ull);
L_7004535370:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535380(Cpu *c) {
    FN_ENTER(0x7004535380ull);
L_7004535380:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x3f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535390(Cpu *c) {
    FN_ENTER(0x7004535390ull);
L_7004535390:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x400ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x400ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045353a0(Cpu *c) {
    FN_ENTER(0x70045353a0ull);
L_70045353a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x408ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x408ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045353b0(Cpu *c) {
    FN_ENTER(0x70045353b0ull);
L_70045353b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x410ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x410ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045353c0(Cpu *c) {
    FN_ENTER(0x70045353c0ull);
L_70045353c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x418ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x418ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045353d0(Cpu *c) {
    FN_ENTER(0x70045353d0ull);
L_70045353d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x420ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x420ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045353e0(Cpu *c) {
    FN_ENTER(0x70045353e0ull);
L_70045353e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x428ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x428ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045353f0(Cpu *c) {
    FN_ENTER(0x70045353f0ull);
L_70045353f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x430ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x430ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535400(Cpu *c) {
    FN_ENTER(0x7004535400ull);
L_7004535400:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x438ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x438ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535410(Cpu *c) {
    FN_ENTER(0x7004535410ull);
L_7004535410:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x440ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x440ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535420(Cpu *c) {
    FN_ENTER(0x7004535420ull);
L_7004535420:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x448ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x448ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535430(Cpu *c) {
    FN_ENTER(0x7004535430ull);
L_7004535430:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535440(Cpu *c) {
    FN_ENTER(0x7004535440ull);
L_7004535440:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535450(Cpu *c) {
    FN_ENTER(0x7004535450ull);
L_7004535450:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535460(Cpu *c) {
    FN_ENTER(0x7004535460ull);
L_7004535460:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535470(Cpu *c) {
    FN_ENTER(0x7004535470ull);
L_7004535470:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535480(Cpu *c) {
    FN_ENTER(0x7004535480ull);
L_7004535480:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535490(Cpu *c) {
    FN_ENTER(0x7004535490ull);
L_7004535490:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045354a0(Cpu *c) {
    FN_ENTER(0x70045354a0ull);
L_70045354a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045354b0(Cpu *c) {
    FN_ENTER(0x70045354b0ull);
L_70045354b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045354c0(Cpu *c) {
    FN_ENTER(0x70045354c0ull);
L_70045354c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045354d0(Cpu *c) {
    FN_ENTER(0x70045354d0ull);
L_70045354d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045354e0(Cpu *c) {
    FN_ENTER(0x70045354e0ull);
L_70045354e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045354f0(Cpu *c) {
    FN_ENTER(0x70045354f0ull);
L_70045354f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535500(Cpu *c) {
    FN_ENTER(0x7004535500ull);
L_7004535500:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535510(Cpu *c) {
    FN_ENTER(0x7004535510ull);
L_7004535510:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535520(Cpu *c) {
    FN_ENTER(0x7004535520ull);
L_7004535520:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535530(Cpu *c) {
    FN_ENTER(0x7004535530ull);
L_7004535530:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535540(Cpu *c) {
    FN_ENTER(0x7004535540ull);
L_7004535540:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535550(Cpu *c) {
    FN_ENTER(0x7004535550ull);
L_7004535550:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535560(Cpu *c) {
    FN_ENTER(0x7004535560ull);
L_7004535560:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535570(Cpu *c) {
    FN_ENTER(0x7004535570ull);
L_7004535570:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535580(Cpu *c) {
    FN_ENTER(0x7004535580ull);
L_7004535580:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535590(Cpu *c) {
    FN_ENTER(0x7004535590ull);
L_7004535590:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045355a0(Cpu *c) {
    FN_ENTER(0x70045355a0ull);
L_70045355a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045355b0(Cpu *c) {
    FN_ENTER(0x70045355b0ull);
L_70045355b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045355c0(Cpu *c) {
    FN_ENTER(0x70045355c0ull);
L_70045355c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045355d0(Cpu *c) {
    FN_ENTER(0x70045355d0ull);
L_70045355d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045355e0(Cpu *c) {
    FN_ENTER(0x70045355e0ull);
L_70045355e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045355f0(Cpu *c) {
    FN_ENTER(0x70045355f0ull);
L_70045355f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535600(Cpu *c) {
    FN_ENTER(0x7004535600ull);
L_7004535600:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535610(Cpu *c) {
    FN_ENTER(0x7004535610ull);
L_7004535610:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535620(Cpu *c) {
    FN_ENTER(0x7004535620ull);
L_7004535620:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535630(Cpu *c) {
    FN_ENTER(0x7004535630ull);
L_7004535630:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535640(Cpu *c) {
    FN_ENTER(0x7004535640ull);
L_7004535640:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535650(Cpu *c) {
    FN_ENTER(0x7004535650ull);
L_7004535650:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535660(Cpu *c) {
    FN_ENTER(0x7004535660ull);
L_7004535660:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535670(Cpu *c) {
    FN_ENTER(0x7004535670ull);
L_7004535670:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535680(Cpu *c) {
    FN_ENTER(0x7004535680ull);
L_7004535680:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535690(Cpu *c) {
    FN_ENTER(0x7004535690ull);
L_7004535690:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045356a0(Cpu *c) {
    FN_ENTER(0x70045356a0ull);
L_70045356a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045356b0(Cpu *c) {
    FN_ENTER(0x70045356b0ull);
L_70045356b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045356c0(Cpu *c) {
    FN_ENTER(0x70045356c0ull);
L_70045356c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045356d0(Cpu *c) {
    FN_ENTER(0x70045356d0ull);
L_70045356d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045356e0(Cpu *c) {
    FN_ENTER(0x70045356e0ull);
L_70045356e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045356f0(Cpu *c) {
    FN_ENTER(0x70045356f0ull);
L_70045356f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535700(Cpu *c) {
    FN_ENTER(0x7004535700ull);
L_7004535700:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535710(Cpu *c) {
    FN_ENTER(0x7004535710ull);
L_7004535710:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535720(Cpu *c) {
    FN_ENTER(0x7004535720ull);
L_7004535720:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535730(Cpu *c) {
    FN_ENTER(0x7004535730ull);
L_7004535730:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535740(Cpu *c) {
    FN_ENTER(0x7004535740ull);
L_7004535740:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535750(Cpu *c) {
    FN_ENTER(0x7004535750ull);
L_7004535750:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535760(Cpu *c) {
    FN_ENTER(0x7004535760ull);
L_7004535760:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535770(Cpu *c) {
    FN_ENTER(0x7004535770ull);
L_7004535770:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535780(Cpu *c) {
    FN_ENTER(0x7004535780ull);
L_7004535780:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535790(Cpu *c) {
    FN_ENTER(0x7004535790ull);
L_7004535790:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045357a0(Cpu *c) {
    FN_ENTER(0x70045357a0ull);
L_70045357a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045357b0(Cpu *c) {
    FN_ENTER(0x70045357b0ull);
L_70045357b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045357c0(Cpu *c) {
    FN_ENTER(0x70045357c0ull);
L_70045357c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045357d0(Cpu *c) {
    FN_ENTER(0x70045357d0ull);
L_70045357d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045357e0(Cpu *c) {
    FN_ENTER(0x70045357e0ull);
L_70045357e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045357f0(Cpu *c) {
    FN_ENTER(0x70045357f0ull);
L_70045357f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535800(Cpu *c) {
    FN_ENTER(0x7004535800ull);
L_7004535800:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535810(Cpu *c) {
    FN_ENTER(0x7004535810ull);
L_7004535810:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535820(Cpu *c) {
    FN_ENTER(0x7004535820ull);
L_7004535820:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535830(Cpu *c) {
    FN_ENTER(0x7004535830ull);
L_7004535830:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535840(Cpu *c) {
    FN_ENTER(0x7004535840ull);
L_7004535840:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535850(Cpu *c) {
    FN_ENTER(0x7004535850ull);
L_7004535850:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535860(Cpu *c) {
    FN_ENTER(0x7004535860ull);
L_7004535860:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535870(Cpu *c) {
    FN_ENTER(0x7004535870ull);
L_7004535870:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535880(Cpu *c) {
    FN_ENTER(0x7004535880ull);
L_7004535880:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535890(Cpu *c) {
    FN_ENTER(0x7004535890ull);
L_7004535890:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045358a0(Cpu *c) {
    FN_ENTER(0x70045358a0ull);
L_70045358a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045358b0(Cpu *c) {
    FN_ENTER(0x70045358b0ull);
L_70045358b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045358c0(Cpu *c) {
    FN_ENTER(0x70045358c0ull);
L_70045358c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045358d0(Cpu *c) {
    FN_ENTER(0x70045358d0ull);
L_70045358d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045358e0(Cpu *c) {
    FN_ENTER(0x70045358e0ull);
L_70045358e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045358f0(Cpu *c) {
    FN_ENTER(0x70045358f0ull);
L_70045358f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535900(Cpu *c) {
    FN_ENTER(0x7004535900ull);
L_7004535900:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535910(Cpu *c) {
    FN_ENTER(0x7004535910ull);
L_7004535910:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535920(Cpu *c) {
    FN_ENTER(0x7004535920ull);
L_7004535920:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535930(Cpu *c) {
    FN_ENTER(0x7004535930ull);
L_7004535930:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535940(Cpu *c) {
    FN_ENTER(0x7004535940ull);
L_7004535940:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535950(Cpu *c) {
    FN_ENTER(0x7004535950ull);
L_7004535950:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535960(Cpu *c) {
    FN_ENTER(0x7004535960ull);
L_7004535960:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535970(Cpu *c) {
    FN_ENTER(0x7004535970ull);
L_7004535970:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535980(Cpu *c) {
    FN_ENTER(0x7004535980ull);
L_7004535980:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535990(Cpu *c) {
    FN_ENTER(0x7004535990ull);
L_7004535990:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045359a0(Cpu *c) {
    FN_ENTER(0x70045359a0ull);
L_70045359a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045359b0(Cpu *c) {
    FN_ENTER(0x70045359b0ull);
L_70045359b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045359c0(Cpu *c) {
    FN_ENTER(0x70045359c0ull);
L_70045359c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045359d0(Cpu *c) {
    FN_ENTER(0x70045359d0ull);
L_70045359d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045359e0(Cpu *c) {
    FN_ENTER(0x70045359e0ull);
L_70045359e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045359f0(Cpu *c) {
    FN_ENTER(0x70045359f0ull);
L_70045359f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a00(Cpu *c) {
    FN_ENTER(0x7004535a00ull);
L_7004535a00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a10(Cpu *c) {
    FN_ENTER(0x7004535a10ull);
L_7004535a10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a20(Cpu *c) {
    FN_ENTER(0x7004535a20ull);
L_7004535a20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a30(Cpu *c) {
    FN_ENTER(0x7004535a30ull);
L_7004535a30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a40(Cpu *c) {
    FN_ENTER(0x7004535a40ull);
L_7004535a40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a50(Cpu *c) {
    FN_ENTER(0x7004535a50ull);
L_7004535a50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a60(Cpu *c) {
    FN_ENTER(0x7004535a60ull);
L_7004535a60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a70(Cpu *c) {
    FN_ENTER(0x7004535a70ull);
L_7004535a70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a80(Cpu *c) {
    FN_ENTER(0x7004535a80ull);
L_7004535a80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535a90(Cpu *c) {
    FN_ENTER(0x7004535a90ull);
L_7004535a90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535aa0(Cpu *c) {
    FN_ENTER(0x7004535aa0ull);
L_7004535aa0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ab0(Cpu *c) {
    FN_ENTER(0x7004535ab0ull);
L_7004535ab0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ac0(Cpu *c) {
    FN_ENTER(0x7004535ac0ull);
L_7004535ac0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ad0(Cpu *c) {
    FN_ENTER(0x7004535ad0ull);
L_7004535ad0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ae0(Cpu *c) {
    FN_ENTER(0x7004535ae0ull);
L_7004535ae0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535af0(Cpu *c) {
    FN_ENTER(0x7004535af0ull);
L_7004535af0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b00(Cpu *c) {
    FN_ENTER(0x7004535b00ull);
L_7004535b00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b10(Cpu *c) {
    FN_ENTER(0x7004535b10ull);
L_7004535b10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b20(Cpu *c) {
    FN_ENTER(0x7004535b20ull);
L_7004535b20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b30(Cpu *c) {
    FN_ENTER(0x7004535b30ull);
L_7004535b30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b40(Cpu *c) {
    FN_ENTER(0x7004535b40ull);
L_7004535b40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b50(Cpu *c) {
    FN_ENTER(0x7004535b50ull);
L_7004535b50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b60(Cpu *c) {
    FN_ENTER(0x7004535b60ull);
L_7004535b60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b70(Cpu *c) {
    FN_ENTER(0x7004535b70ull);
L_7004535b70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b80(Cpu *c) {
    FN_ENTER(0x7004535b80ull);
L_7004535b80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535b90(Cpu *c) {
    FN_ENTER(0x7004535b90ull);
L_7004535b90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ba0(Cpu *c) {
    FN_ENTER(0x7004535ba0ull);
L_7004535ba0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535bb0(Cpu *c) {
    FN_ENTER(0x7004535bb0ull);
L_7004535bb0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535bc0(Cpu *c) {
    FN_ENTER(0x7004535bc0ull);
L_7004535bc0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535bd0(Cpu *c) {
    FN_ENTER(0x7004535bd0ull);
L_7004535bd0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535be0(Cpu *c) {
    FN_ENTER(0x7004535be0ull);
L_7004535be0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535bf0(Cpu *c) {
    FN_ENTER(0x7004535bf0ull);
L_7004535bf0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c00(Cpu *c) {
    FN_ENTER(0x7004535c00ull);
L_7004535c00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c10(Cpu *c) {
    FN_ENTER(0x7004535c10ull);
L_7004535c10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c20(Cpu *c) {
    FN_ENTER(0x7004535c20ull);
L_7004535c20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c30(Cpu *c) {
    FN_ENTER(0x7004535c30ull);
L_7004535c30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c40(Cpu *c) {
    FN_ENTER(0x7004535c40ull);
L_7004535c40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c50(Cpu *c) {
    FN_ENTER(0x7004535c50ull);
L_7004535c50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c60(Cpu *c) {
    FN_ENTER(0x7004535c60ull);
L_7004535c60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c70(Cpu *c) {
    FN_ENTER(0x7004535c70ull);
L_7004535c70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c80(Cpu *c) {
    FN_ENTER(0x7004535c80ull);
L_7004535c80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535c90(Cpu *c) {
    FN_ENTER(0x7004535c90ull);
L_7004535c90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ca0(Cpu *c) {
    FN_ENTER(0x7004535ca0ull);
L_7004535ca0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535cb0(Cpu *c) {
    FN_ENTER(0x7004535cb0ull);
L_7004535cb0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535cc0(Cpu *c) {
    FN_ENTER(0x7004535cc0ull);
L_7004535cc0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535cd0(Cpu *c) {
    FN_ENTER(0x7004535cd0ull);
L_7004535cd0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ce0(Cpu *c) {
    FN_ENTER(0x7004535ce0ull);
L_7004535ce0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535cf0(Cpu *c) {
    FN_ENTER(0x7004535cf0ull);
L_7004535cf0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d00(Cpu *c) {
    FN_ENTER(0x7004535d00ull);
L_7004535d00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d10(Cpu *c) {
    FN_ENTER(0x7004535d10ull);
L_7004535d10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d20(Cpu *c) {
    FN_ENTER(0x7004535d20ull);
L_7004535d20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d30(Cpu *c) {
    FN_ENTER(0x7004535d30ull);
L_7004535d30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d40(Cpu *c) {
    FN_ENTER(0x7004535d40ull);
L_7004535d40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d50(Cpu *c) {
    FN_ENTER(0x7004535d50ull);
L_7004535d50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d60(Cpu *c) {
    FN_ENTER(0x7004535d60ull);
L_7004535d60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d70(Cpu *c) {
    FN_ENTER(0x7004535d70ull);
L_7004535d70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d80(Cpu *c) {
    FN_ENTER(0x7004535d80ull);
L_7004535d80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535d90(Cpu *c) {
    FN_ENTER(0x7004535d90ull);
L_7004535d90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535da0(Cpu *c) {
    FN_ENTER(0x7004535da0ull);
L_7004535da0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535db0(Cpu *c) {
    FN_ENTER(0x7004535db0ull);
L_7004535db0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535dc0(Cpu *c) {
    FN_ENTER(0x7004535dc0ull);
L_7004535dc0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535dd0(Cpu *c) {
    FN_ENTER(0x7004535dd0ull);
L_7004535dd0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535de0(Cpu *c) {
    FN_ENTER(0x7004535de0ull);
L_7004535de0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535df0(Cpu *c) {
    FN_ENTER(0x7004535df0ull);
L_7004535df0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e00(Cpu *c) {
    FN_ENTER(0x7004535e00ull);
L_7004535e00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e10(Cpu *c) {
    FN_ENTER(0x7004535e10ull);
L_7004535e10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e20(Cpu *c) {
    FN_ENTER(0x7004535e20ull);
L_7004535e20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e30(Cpu *c) {
    FN_ENTER(0x7004535e30ull);
L_7004535e30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e40(Cpu *c) {
    FN_ENTER(0x7004535e40ull);
L_7004535e40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e50(Cpu *c) {
    FN_ENTER(0x7004535e50ull);
L_7004535e50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e60(Cpu *c) {
    FN_ENTER(0x7004535e60ull);
L_7004535e60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e70(Cpu *c) {
    FN_ENTER(0x7004535e70ull);
L_7004535e70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e80(Cpu *c) {
    FN_ENTER(0x7004535e80ull);
L_7004535e80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535e90(Cpu *c) {
    FN_ENTER(0x7004535e90ull);
L_7004535e90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ea0(Cpu *c) {
    FN_ENTER(0x7004535ea0ull);
L_7004535ea0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535eb0(Cpu *c) {
    FN_ENTER(0x7004535eb0ull);
L_7004535eb0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ec0(Cpu *c) {
    FN_ENTER(0x7004535ec0ull);
L_7004535ec0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ed0(Cpu *c) {
    FN_ENTER(0x7004535ed0ull);
L_7004535ed0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ee0(Cpu *c) {
    FN_ENTER(0x7004535ee0ull);
L_7004535ee0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ef0(Cpu *c) {
    FN_ENTER(0x7004535ef0ull);
L_7004535ef0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f00(Cpu *c) {
    FN_ENTER(0x7004535f00ull);
L_7004535f00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f10(Cpu *c) {
    FN_ENTER(0x7004535f10ull);
L_7004535f10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f20(Cpu *c) {
    FN_ENTER(0x7004535f20ull);
L_7004535f20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f30(Cpu *c) {
    FN_ENTER(0x7004535f30ull);
L_7004535f30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f40(Cpu *c) {
    FN_ENTER(0x7004535f40ull);
L_7004535f40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f50(Cpu *c) {
    FN_ENTER(0x7004535f50ull);
L_7004535f50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f60(Cpu *c) {
    FN_ENTER(0x7004535f60ull);
L_7004535f60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f70(Cpu *c) {
    FN_ENTER(0x7004535f70ull);
L_7004535f70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f80(Cpu *c) {
    FN_ENTER(0x7004535f80ull);
L_7004535f80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535f90(Cpu *c) {
    FN_ENTER(0x7004535f90ull);
L_7004535f90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535fa0(Cpu *c) {
    FN_ENTER(0x7004535fa0ull);
L_7004535fa0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535fb0(Cpu *c) {
    FN_ENTER(0x7004535fb0ull);
L_7004535fb0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535fc0(Cpu *c) {
    FN_ENTER(0x7004535fc0ull);
L_7004535fc0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535fd0(Cpu *c) {
    FN_ENTER(0x7004535fd0ull);
L_7004535fd0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535fe0(Cpu *c) {
    FN_ENTER(0x7004535fe0ull);
L_7004535fe0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004535ff0(Cpu *c) {
    FN_ENTER(0x7004535ff0ull);
L_7004535ff0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536000(Cpu *c) {
    FN_ENTER(0x7004536000ull);
L_7004536000:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536010(Cpu *c) {
    FN_ENTER(0x7004536010ull);
L_7004536010:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536020(Cpu *c) {
    FN_ENTER(0x7004536020ull);
L_7004536020:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536030(Cpu *c) {
    FN_ENTER(0x7004536030ull);
L_7004536030:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536040(Cpu *c) {
    FN_ENTER(0x7004536040ull);
L_7004536040:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536050(Cpu *c) {
    FN_ENTER(0x7004536050ull);
L_7004536050:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536060(Cpu *c) {
    FN_ENTER(0x7004536060ull);
L_7004536060:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536070(Cpu *c) {
    FN_ENTER(0x7004536070ull);
L_7004536070:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536080(Cpu *c) {
    FN_ENTER(0x7004536080ull);
L_7004536080:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536090(Cpu *c) {
    FN_ENTER(0x7004536090ull);
L_7004536090:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045360a0(Cpu *c) {
    FN_ENTER(0x70045360a0ull);
L_70045360a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045360b0(Cpu *c) {
    FN_ENTER(0x70045360b0ull);
L_70045360b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045360c0(Cpu *c) {
    FN_ENTER(0x70045360c0ull);
L_70045360c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045360d0(Cpu *c) {
    FN_ENTER(0x70045360d0ull);
L_70045360d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045360e0(Cpu *c) {
    FN_ENTER(0x70045360e0ull);
L_70045360e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045360f0(Cpu *c) {
    FN_ENTER(0x70045360f0ull);
L_70045360f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536100(Cpu *c) {
    FN_ENTER(0x7004536100ull);
L_7004536100:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536110(Cpu *c) {
    FN_ENTER(0x7004536110ull);
L_7004536110:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536120(Cpu *c) {
    FN_ENTER(0x7004536120ull);
L_7004536120:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536130(Cpu *c) {
    FN_ENTER(0x7004536130ull);
L_7004536130:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536140(Cpu *c) {
    FN_ENTER(0x7004536140ull);
L_7004536140:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536150(Cpu *c) {
    FN_ENTER(0x7004536150ull);
L_7004536150:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536160(Cpu *c) {
    FN_ENTER(0x7004536160ull);
L_7004536160:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536170(Cpu *c) {
    FN_ENTER(0x7004536170ull);
L_7004536170:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536180(Cpu *c) {
    FN_ENTER(0x7004536180ull);
L_7004536180:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536190(Cpu *c) {
    FN_ENTER(0x7004536190ull);
L_7004536190:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045361a0(Cpu *c) {
    FN_ENTER(0x70045361a0ull);
L_70045361a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045361b0(Cpu *c) {
    FN_ENTER(0x70045361b0ull);
L_70045361b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045361c0(Cpu *c) {
    FN_ENTER(0x70045361c0ull);
L_70045361c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045361d0(Cpu *c) {
    FN_ENTER(0x70045361d0ull);
L_70045361d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045361e0(Cpu *c) {
    FN_ENTER(0x70045361e0ull);
L_70045361e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045361f0(Cpu *c) {
    FN_ENTER(0x70045361f0ull);
L_70045361f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536200(Cpu *c) {
    FN_ENTER(0x7004536200ull);
L_7004536200:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536210(Cpu *c) {
    FN_ENTER(0x7004536210ull);
L_7004536210:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536220(Cpu *c) {
    FN_ENTER(0x7004536220ull);
L_7004536220:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536230(Cpu *c) {
    FN_ENTER(0x7004536230ull);
L_7004536230:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536240(Cpu *c) {
    FN_ENTER(0x7004536240ull);
L_7004536240:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536250(Cpu *c) {
    FN_ENTER(0x7004536250ull);
L_7004536250:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536260(Cpu *c) {
    FN_ENTER(0x7004536260ull);
L_7004536260:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536270(Cpu *c) {
    FN_ENTER(0x7004536270ull);
L_7004536270:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536280(Cpu *c) {
    FN_ENTER(0x7004536280ull);
L_7004536280:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536290(Cpu *c) {
    FN_ENTER(0x7004536290ull);
L_7004536290:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045362a0(Cpu *c) {
    FN_ENTER(0x70045362a0ull);
L_70045362a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045362b0(Cpu *c) {
    FN_ENTER(0x70045362b0ull);
L_70045362b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045362c0(Cpu *c) {
    FN_ENTER(0x70045362c0ull);
L_70045362c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045362d0(Cpu *c) {
    FN_ENTER(0x70045362d0ull);
L_70045362d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045362e0(Cpu *c) {
    FN_ENTER(0x70045362e0ull);
L_70045362e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045362f0(Cpu *c) {
    FN_ENTER(0x70045362f0ull);
L_70045362f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536300(Cpu *c) {
    FN_ENTER(0x7004536300ull);
L_7004536300:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536310(Cpu *c) {
    FN_ENTER(0x7004536310ull);
L_7004536310:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536320(Cpu *c) {
    FN_ENTER(0x7004536320ull);
L_7004536320:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536330(Cpu *c) {
    FN_ENTER(0x7004536330ull);
L_7004536330:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536340(Cpu *c) {
    FN_ENTER(0x7004536340ull);
L_7004536340:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536350(Cpu *c) {
    FN_ENTER(0x7004536350ull);
L_7004536350:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536360(Cpu *c) {
    FN_ENTER(0x7004536360ull);
L_7004536360:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536370(Cpu *c) {
    FN_ENTER(0x7004536370ull);
L_7004536370:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536380(Cpu *c) {
    FN_ENTER(0x7004536380ull);
L_7004536380:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536390(Cpu *c) {
    FN_ENTER(0x7004536390ull);
L_7004536390:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045363a0(Cpu *c) {
    FN_ENTER(0x70045363a0ull);
L_70045363a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045363b0(Cpu *c) {
    FN_ENTER(0x70045363b0ull);
L_70045363b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045363c0(Cpu *c) {
    FN_ENTER(0x70045363c0ull);
L_70045363c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045363d0(Cpu *c) {
    FN_ENTER(0x70045363d0ull);
L_70045363d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045363e0(Cpu *c) {
    FN_ENTER(0x70045363e0ull);
L_70045363e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045363f0(Cpu *c) {
    FN_ENTER(0x70045363f0ull);
L_70045363f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536400(Cpu *c) {
    FN_ENTER(0x7004536400ull);
L_7004536400:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536410(Cpu *c) {
    FN_ENTER(0x7004536410ull);
L_7004536410:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536420(Cpu *c) {
    FN_ENTER(0x7004536420ull);
L_7004536420:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536430(Cpu *c) {
    FN_ENTER(0x7004536430ull);
L_7004536430:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536440(Cpu *c) {
    FN_ENTER(0x7004536440ull);
L_7004536440:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536450(Cpu *c) {
    FN_ENTER(0x7004536450ull);
L_7004536450:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536460(Cpu *c) {
    FN_ENTER(0x7004536460ull);
L_7004536460:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536470(Cpu *c) {
    FN_ENTER(0x7004536470ull);
L_7004536470:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536480(Cpu *c) {
    FN_ENTER(0x7004536480ull);
L_7004536480:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536490(Cpu *c) {
    FN_ENTER(0x7004536490ull);
L_7004536490:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045364a0(Cpu *c) {
    FN_ENTER(0x70045364a0ull);
L_70045364a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045364b0(Cpu *c) {
    FN_ENTER(0x70045364b0ull);
L_70045364b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045364c0(Cpu *c) {
    FN_ENTER(0x70045364c0ull);
L_70045364c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045364d0(Cpu *c) {
    FN_ENTER(0x70045364d0ull);
L_70045364d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045364e0(Cpu *c) {
    FN_ENTER(0x70045364e0ull);
L_70045364e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045364f0(Cpu *c) {
    FN_ENTER(0x70045364f0ull);
L_70045364f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536500(Cpu *c) {
    FN_ENTER(0x7004536500ull);
L_7004536500:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536510(Cpu *c) {
    FN_ENTER(0x7004536510ull);
L_7004536510:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536520(Cpu *c) {
    FN_ENTER(0x7004536520ull);
L_7004536520:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536530(Cpu *c) {
    FN_ENTER(0x7004536530ull);
L_7004536530:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536540(Cpu *c) {
    FN_ENTER(0x7004536540ull);
L_7004536540:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536550(Cpu *c) {
    FN_ENTER(0x7004536550ull);
L_7004536550:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536560(Cpu *c) {
    FN_ENTER(0x7004536560ull);
L_7004536560:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536570(Cpu *c) {
    FN_ENTER(0x7004536570ull);
L_7004536570:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536580(Cpu *c) {
    FN_ENTER(0x7004536580ull);
L_7004536580:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536590(Cpu *c) {
    FN_ENTER(0x7004536590ull);
L_7004536590:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045365a0(Cpu *c) {
    FN_ENTER(0x70045365a0ull);
L_70045365a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045365b0(Cpu *c) {
    FN_ENTER(0x70045365b0ull);
L_70045365b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045365c0(Cpu *c) {
    FN_ENTER(0x70045365c0ull);
L_70045365c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045365d0(Cpu *c) {
    FN_ENTER(0x70045365d0ull);
L_70045365d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045365e0(Cpu *c) {
    FN_ENTER(0x70045365e0ull);
L_70045365e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045365f0(Cpu *c) {
    FN_ENTER(0x70045365f0ull);
L_70045365f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536600(Cpu *c) {
    FN_ENTER(0x7004536600ull);
L_7004536600:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536610(Cpu *c) {
    FN_ENTER(0x7004536610ull);
L_7004536610:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536620(Cpu *c) {
    FN_ENTER(0x7004536620ull);
L_7004536620:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536630(Cpu *c) {
    FN_ENTER(0x7004536630ull);
L_7004536630:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536640(Cpu *c) {
    FN_ENTER(0x7004536640ull);
L_7004536640:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536650(Cpu *c) {
    FN_ENTER(0x7004536650ull);
L_7004536650:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536660(Cpu *c) {
    FN_ENTER(0x7004536660ull);
L_7004536660:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536670(Cpu *c) {
    FN_ENTER(0x7004536670ull);
L_7004536670:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536680(Cpu *c) {
    FN_ENTER(0x7004536680ull);
L_7004536680:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536690(Cpu *c) {
    FN_ENTER(0x7004536690ull);
L_7004536690:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045366a0(Cpu *c) {
    FN_ENTER(0x70045366a0ull);
L_70045366a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045366b0(Cpu *c) {
    FN_ENTER(0x70045366b0ull);
L_70045366b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045366c0(Cpu *c) {
    FN_ENTER(0x70045366c0ull);
L_70045366c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045366d0(Cpu *c) {
    FN_ENTER(0x70045366d0ull);
L_70045366d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045366e0(Cpu *c) {
    FN_ENTER(0x70045366e0ull);
L_70045366e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045366f0(Cpu *c) {
    FN_ENTER(0x70045366f0ull);
L_70045366f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536700(Cpu *c) {
    FN_ENTER(0x7004536700ull);
L_7004536700:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536710(Cpu *c) {
    FN_ENTER(0x7004536710ull);
L_7004536710:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536720(Cpu *c) {
    FN_ENTER(0x7004536720ull);
L_7004536720:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536730(Cpu *c) {
    FN_ENTER(0x7004536730ull);
L_7004536730:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536740(Cpu *c) {
    FN_ENTER(0x7004536740ull);
L_7004536740:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536750(Cpu *c) {
    FN_ENTER(0x7004536750ull);
L_7004536750:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536760(Cpu *c) {
    FN_ENTER(0x7004536760ull);
L_7004536760:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536770(Cpu *c) {
    FN_ENTER(0x7004536770ull);
L_7004536770:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536780(Cpu *c) {
    FN_ENTER(0x7004536780ull);
L_7004536780:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536790(Cpu *c) {
    FN_ENTER(0x7004536790ull);
L_7004536790:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045367a0(Cpu *c) {
    FN_ENTER(0x70045367a0ull);
L_70045367a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045367b0(Cpu *c) {
    FN_ENTER(0x70045367b0ull);
L_70045367b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045367c0(Cpu *c) {
    FN_ENTER(0x70045367c0ull);
L_70045367c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045367d0(Cpu *c) {
    FN_ENTER(0x70045367d0ull);
L_70045367d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045367e0(Cpu *c) {
    FN_ENTER(0x70045367e0ull);
L_70045367e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045367f0(Cpu *c) {
    FN_ENTER(0x70045367f0ull);
L_70045367f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536800(Cpu *c) {
    FN_ENTER(0x7004536800ull);
L_7004536800:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536810(Cpu *c) {
    FN_ENTER(0x7004536810ull);
L_7004536810:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536820(Cpu *c) {
    FN_ENTER(0x7004536820ull);
L_7004536820:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536830(Cpu *c) {
    FN_ENTER(0x7004536830ull);
L_7004536830:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536840(Cpu *c) {
    FN_ENTER(0x7004536840ull);
L_7004536840:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536850(Cpu *c) {
    FN_ENTER(0x7004536850ull);
L_7004536850:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536860(Cpu *c) {
    FN_ENTER(0x7004536860ull);
L_7004536860:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536870(Cpu *c) {
    FN_ENTER(0x7004536870ull);
L_7004536870:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536880(Cpu *c) {
    FN_ENTER(0x7004536880ull);
L_7004536880:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536890(Cpu *c) {
    FN_ENTER(0x7004536890ull);
L_7004536890:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045368a0(Cpu *c) {
    FN_ENTER(0x70045368a0ull);
L_70045368a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045368b0(Cpu *c) {
    FN_ENTER(0x70045368b0ull);
L_70045368b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045368c0(Cpu *c) {
    FN_ENTER(0x70045368c0ull);
L_70045368c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045368d0(Cpu *c) {
    FN_ENTER(0x70045368d0ull);
L_70045368d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045368e0(Cpu *c) {
    FN_ENTER(0x70045368e0ull);
L_70045368e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045368f0(Cpu *c) {
    FN_ENTER(0x70045368f0ull);
L_70045368f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536900(Cpu *c) {
    FN_ENTER(0x7004536900ull);
L_7004536900:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536910(Cpu *c) {
    FN_ENTER(0x7004536910ull);
L_7004536910:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536920(Cpu *c) {
    FN_ENTER(0x7004536920ull);
L_7004536920:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536930(Cpu *c) {
    FN_ENTER(0x7004536930ull);
L_7004536930:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536940(Cpu *c) {
    FN_ENTER(0x7004536940ull);
L_7004536940:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536950(Cpu *c) {
    FN_ENTER(0x7004536950ull);
L_7004536950:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536960(Cpu *c) {
    FN_ENTER(0x7004536960ull);
L_7004536960:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536970(Cpu *c) {
    FN_ENTER(0x7004536970ull);
L_7004536970:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536980(Cpu *c) {
    FN_ENTER(0x7004536980ull);
L_7004536980:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536990(Cpu *c) {
    FN_ENTER(0x7004536990ull);
L_7004536990:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045369a0(Cpu *c) {
    FN_ENTER(0x70045369a0ull);
L_70045369a0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045369b0(Cpu *c) {
    FN_ENTER(0x70045369b0ull);
L_70045369b0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045369c0(Cpu *c) {
    FN_ENTER(0x70045369c0ull);
L_70045369c0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045369d0(Cpu *c) {
    FN_ENTER(0x70045369d0ull);
L_70045369d0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045369e0(Cpu *c) {
    FN_ENTER(0x70045369e0ull);
L_70045369e0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045369f0(Cpu *c) {
    FN_ENTER(0x70045369f0ull);
L_70045369f0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a00(Cpu *c) {
    FN_ENTER(0x7004536a00ull);
L_7004536a00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a10(Cpu *c) {
    FN_ENTER(0x7004536a10ull);
L_7004536a10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a20(Cpu *c) {
    FN_ENTER(0x7004536a20ull);
L_7004536a20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a30(Cpu *c) {
    FN_ENTER(0x7004536a30ull);
L_7004536a30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a40(Cpu *c) {
    FN_ENTER(0x7004536a40ull);
L_7004536a40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a50(Cpu *c) {
    FN_ENTER(0x7004536a50ull);
L_7004536a50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a60(Cpu *c) {
    FN_ENTER(0x7004536a60ull);
L_7004536a60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a70(Cpu *c) {
    FN_ENTER(0x7004536a70ull);
L_7004536a70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a80(Cpu *c) {
    FN_ENTER(0x7004536a80ull);
L_7004536a80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536a90(Cpu *c) {
    FN_ENTER(0x7004536a90ull);
L_7004536a90:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536aa0(Cpu *c) {
    FN_ENTER(0x7004536aa0ull);
L_7004536aa0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ab0(Cpu *c) {
    FN_ENTER(0x7004536ab0ull);
L_7004536ab0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ac0(Cpu *c) {
    FN_ENTER(0x7004536ac0ull);
L_7004536ac0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ad0(Cpu *c) {
    FN_ENTER(0x7004536ad0ull);
L_7004536ad0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ae0(Cpu *c) {
    FN_ENTER(0x7004536ae0ull);
L_7004536ae0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536af0(Cpu *c) {
    FN_ENTER(0x7004536af0ull);
L_7004536af0:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b00(Cpu *c) {
    FN_ENTER(0x7004536b00ull);
L_7004536b00:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b10(Cpu *c) {
    FN_ENTER(0x7004536b10ull);
L_7004536b10:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b20(Cpu *c) {
    FN_ENTER(0x7004536b20ull);
L_7004536b20:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b30(Cpu *c) {
    FN_ENTER(0x7004536b30ull);
L_7004536b30:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b40(Cpu *c) {
    FN_ENTER(0x7004536b40ull);
L_7004536b40:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b50(Cpu *c) {
    FN_ENTER(0x7004536b50ull);
L_7004536b50:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b60(Cpu *c) {
    FN_ENTER(0x7004536b60ull);
L_7004536b60:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b70(Cpu *c) {
    FN_ENTER(0x7004536b70ull);
L_7004536b70:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b80(Cpu *c) {
    FN_ENTER(0x7004536b80ull);
L_7004536b80:;
    c->x[16] = (uint64_t)(0x7004c33000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536b90(Cpu *c) {
    FN_ENTER(0x7004536b90ull);
L_7004536b90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ba0(Cpu *c) {
    FN_ENTER(0x7004536ba0ull);
L_7004536ba0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536bb0(Cpu *c) {
    FN_ENTER(0x7004536bb0ull);
L_7004536bb0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536bc0(Cpu *c) {
    FN_ENTER(0x7004536bc0ull);
L_7004536bc0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536bd0(Cpu *c) {
    FN_ENTER(0x7004536bd0ull);
L_7004536bd0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536be0(Cpu *c) {
    FN_ENTER(0x7004536be0ull);
L_7004536be0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536bf0(Cpu *c) {
    FN_ENTER(0x7004536bf0ull);
L_7004536bf0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c00(Cpu *c) {
    FN_ENTER(0x7004536c00ull);
L_7004536c00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c10(Cpu *c) {
    FN_ENTER(0x7004536c10ull);
L_7004536c10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c20(Cpu *c) {
    FN_ENTER(0x7004536c20ull);
L_7004536c20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c30(Cpu *c) {
    FN_ENTER(0x7004536c30ull);
L_7004536c30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c40(Cpu *c) {
    FN_ENTER(0x7004536c40ull);
L_7004536c40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c50(Cpu *c) {
    FN_ENTER(0x7004536c50ull);
L_7004536c50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c60(Cpu *c) {
    FN_ENTER(0x7004536c60ull);
L_7004536c60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c70(Cpu *c) {
    FN_ENTER(0x7004536c70ull);
L_7004536c70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c80(Cpu *c) {
    FN_ENTER(0x7004536c80ull);
L_7004536c80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536c90(Cpu *c) {
    FN_ENTER(0x7004536c90ull);
L_7004536c90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ca0(Cpu *c) {
    FN_ENTER(0x7004536ca0ull);
L_7004536ca0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536cb0(Cpu *c) {
    FN_ENTER(0x7004536cb0ull);
L_7004536cb0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536cc0(Cpu *c) {
    FN_ENTER(0x7004536cc0ull);
L_7004536cc0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536cd0(Cpu *c) {
    FN_ENTER(0x7004536cd0ull);
L_7004536cd0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ce0(Cpu *c) {
    FN_ENTER(0x7004536ce0ull);
L_7004536ce0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536cf0(Cpu *c) {
    FN_ENTER(0x7004536cf0ull);
L_7004536cf0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d00(Cpu *c) {
    FN_ENTER(0x7004536d00ull);
L_7004536d00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d10(Cpu *c) {
    FN_ENTER(0x7004536d10ull);
L_7004536d10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d20(Cpu *c) {
    FN_ENTER(0x7004536d20ull);
L_7004536d20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d30(Cpu *c) {
    FN_ENTER(0x7004536d30ull);
L_7004536d30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d40(Cpu *c) {
    FN_ENTER(0x7004536d40ull);
L_7004536d40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d50(Cpu *c) {
    FN_ENTER(0x7004536d50ull);
L_7004536d50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d60(Cpu *c) {
    FN_ENTER(0x7004536d60ull);
L_7004536d60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d70(Cpu *c) {
    FN_ENTER(0x7004536d70ull);
L_7004536d70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d80(Cpu *c) {
    FN_ENTER(0x7004536d80ull);
L_7004536d80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536d90(Cpu *c) {
    FN_ENTER(0x7004536d90ull);
L_7004536d90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x100ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x100ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536da0(Cpu *c) {
    FN_ENTER(0x7004536da0ull);
L_7004536da0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x108ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x108ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536db0(Cpu *c) {
    FN_ENTER(0x7004536db0ull);
L_7004536db0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x110ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x110ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536dc0(Cpu *c) {
    FN_ENTER(0x7004536dc0ull);
L_7004536dc0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x118ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x118ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536dd0(Cpu *c) {
    FN_ENTER(0x7004536dd0ull);
L_7004536dd0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x120ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x120ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536de0(Cpu *c) {
    FN_ENTER(0x7004536de0ull);
L_7004536de0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x128ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x128ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536df0(Cpu *c) {
    FN_ENTER(0x7004536df0ull);
L_7004536df0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x130ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x130ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e00(Cpu *c) {
    FN_ENTER(0x7004536e00ull);
L_7004536e00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x138ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x138ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e10(Cpu *c) {
    FN_ENTER(0x7004536e10ull);
L_7004536e10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x140ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x140ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e20(Cpu *c) {
    FN_ENTER(0x7004536e20ull);
L_7004536e20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x148ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x148ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e30(Cpu *c) {
    FN_ENTER(0x7004536e30ull);
L_7004536e30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x150ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x150ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e40(Cpu *c) {
    FN_ENTER(0x7004536e40ull);
L_7004536e40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x158ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x158ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e50(Cpu *c) {
    FN_ENTER(0x7004536e50ull);
L_7004536e50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x160ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x160ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e60(Cpu *c) {
    FN_ENTER(0x7004536e60ull);
L_7004536e60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x168ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x168ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e70(Cpu *c) {
    FN_ENTER(0x7004536e70ull);
L_7004536e70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x170ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x170ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e80(Cpu *c) {
    FN_ENTER(0x7004536e80ull);
L_7004536e80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x178ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x178ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536e90(Cpu *c) {
    FN_ENTER(0x7004536e90ull);
L_7004536e90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x180ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x180ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ea0(Cpu *c) {
    FN_ENTER(0x7004536ea0ull);
L_7004536ea0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x188ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x188ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536eb0(Cpu *c) {
    FN_ENTER(0x7004536eb0ull);
L_7004536eb0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x190ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x190ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ec0(Cpu *c) {
    FN_ENTER(0x7004536ec0ull);
L_7004536ec0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x198ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x198ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ed0(Cpu *c) {
    FN_ENTER(0x7004536ed0ull);
L_7004536ed0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ee0(Cpu *c) {
    FN_ENTER(0x7004536ee0ull);
L_7004536ee0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ef0(Cpu *c) {
    FN_ENTER(0x7004536ef0ull);
L_7004536ef0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f00(Cpu *c) {
    FN_ENTER(0x7004536f00ull);
L_7004536f00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f10(Cpu *c) {
    FN_ENTER(0x7004536f10ull);
L_7004536f10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f20(Cpu *c) {
    FN_ENTER(0x7004536f20ull);
L_7004536f20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f30(Cpu *c) {
    FN_ENTER(0x7004536f30ull);
L_7004536f30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f40(Cpu *c) {
    FN_ENTER(0x7004536f40ull);
L_7004536f40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f50(Cpu *c) {
    FN_ENTER(0x7004536f50ull);
L_7004536f50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f60(Cpu *c) {
    FN_ENTER(0x7004536f60ull);
L_7004536f60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f70(Cpu *c) {
    FN_ENTER(0x7004536f70ull);
L_7004536f70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f80(Cpu *c) {
    FN_ENTER(0x7004536f80ull);
L_7004536f80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x1f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536f90(Cpu *c) {
    FN_ENTER(0x7004536f90ull);
L_7004536f90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x200ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x200ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536fa0(Cpu *c) {
    FN_ENTER(0x7004536fa0ull);
L_7004536fa0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x208ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x208ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536fb0(Cpu *c) {
    FN_ENTER(0x7004536fb0ull);
L_7004536fb0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x210ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x210ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536fc0(Cpu *c) {
    FN_ENTER(0x7004536fc0ull);
L_7004536fc0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x218ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x218ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536fd0(Cpu *c) {
    FN_ENTER(0x7004536fd0ull);
L_7004536fd0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x220ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x220ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536fe0(Cpu *c) {
    FN_ENTER(0x7004536fe0ull);
L_7004536fe0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x228ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x228ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004536ff0(Cpu *c) {
    FN_ENTER(0x7004536ff0ull);
L_7004536ff0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x230ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x230ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537000(Cpu *c) {
    FN_ENTER(0x7004537000ull);
L_7004537000:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x238ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x238ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537010(Cpu *c) {
    FN_ENTER(0x7004537010ull);
L_7004537010:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x240ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x240ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537020(Cpu *c) {
    FN_ENTER(0x7004537020ull);
L_7004537020:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x248ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x248ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537030(Cpu *c) {
    FN_ENTER(0x7004537030ull);
L_7004537030:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x250ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x250ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537040(Cpu *c) {
    FN_ENTER(0x7004537040ull);
L_7004537040:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x258ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x258ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537050(Cpu *c) {
    FN_ENTER(0x7004537050ull);
L_7004537050:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x260ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x260ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537060(Cpu *c) {
    FN_ENTER(0x7004537060ull);
L_7004537060:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x268ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x268ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537070(Cpu *c) {
    FN_ENTER(0x7004537070ull);
L_7004537070:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x270ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x270ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537080(Cpu *c) {
    FN_ENTER(0x7004537080ull);
L_7004537080:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x278ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x278ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537090(Cpu *c) {
    FN_ENTER(0x7004537090ull);
L_7004537090:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x280ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x280ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045370a0(Cpu *c) {
    FN_ENTER(0x70045370a0ull);
L_70045370a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x288ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x288ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045370b0(Cpu *c) {
    FN_ENTER(0x70045370b0ull);
L_70045370b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x290ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x290ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045370c0(Cpu *c) {
    FN_ENTER(0x70045370c0ull);
L_70045370c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x298ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x298ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045370d0(Cpu *c) {
    FN_ENTER(0x70045370d0ull);
L_70045370d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045370e0(Cpu *c) {
    FN_ENTER(0x70045370e0ull);
L_70045370e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045370f0(Cpu *c) {
    FN_ENTER(0x70045370f0ull);
L_70045370f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537100(Cpu *c) {
    FN_ENTER(0x7004537100ull);
L_7004537100:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537110(Cpu *c) {
    FN_ENTER(0x7004537110ull);
L_7004537110:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537120(Cpu *c) {
    FN_ENTER(0x7004537120ull);
L_7004537120:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537130(Cpu *c) {
    FN_ENTER(0x7004537130ull);
L_7004537130:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537140(Cpu *c) {
    FN_ENTER(0x7004537140ull);
L_7004537140:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537150(Cpu *c) {
    FN_ENTER(0x7004537150ull);
L_7004537150:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537160(Cpu *c) {
    FN_ENTER(0x7004537160ull);
L_7004537160:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537170(Cpu *c) {
    FN_ENTER(0x7004537170ull);
L_7004537170:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537180(Cpu *c) {
    FN_ENTER(0x7004537180ull);
L_7004537180:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x2f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537190(Cpu *c) {
    FN_ENTER(0x7004537190ull);
L_7004537190:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x300ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x300ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045371a0(Cpu *c) {
    FN_ENTER(0x70045371a0ull);
L_70045371a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x308ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x308ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045371b0(Cpu *c) {
    FN_ENTER(0x70045371b0ull);
L_70045371b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x310ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x310ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045371c0(Cpu *c) {
    FN_ENTER(0x70045371c0ull);
L_70045371c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x318ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x318ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045371d0(Cpu *c) {
    FN_ENTER(0x70045371d0ull);
L_70045371d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x320ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x320ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045371e0(Cpu *c) {
    FN_ENTER(0x70045371e0ull);
L_70045371e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x328ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x328ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045371f0(Cpu *c) {
    FN_ENTER(0x70045371f0ull);
L_70045371f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x330ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x330ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537200(Cpu *c) {
    FN_ENTER(0x7004537200ull);
L_7004537200:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x338ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x338ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537210(Cpu *c) {
    FN_ENTER(0x7004537210ull);
L_7004537210:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x340ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x340ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537220(Cpu *c) {
    FN_ENTER(0x7004537220ull);
L_7004537220:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x348ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x348ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537230(Cpu *c) {
    FN_ENTER(0x7004537230ull);
L_7004537230:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x350ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x350ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537240(Cpu *c) {
    FN_ENTER(0x7004537240ull);
L_7004537240:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x358ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x358ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537250(Cpu *c) {
    FN_ENTER(0x7004537250ull);
L_7004537250:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x360ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x360ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537260(Cpu *c) {
    FN_ENTER(0x7004537260ull);
L_7004537260:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x368ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x368ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537270(Cpu *c) {
    FN_ENTER(0x7004537270ull);
L_7004537270:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x370ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x370ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537280(Cpu *c) {
    FN_ENTER(0x7004537280ull);
L_7004537280:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x378ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x378ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537290(Cpu *c) {
    FN_ENTER(0x7004537290ull);
L_7004537290:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x380ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x380ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045372a0(Cpu *c) {
    FN_ENTER(0x70045372a0ull);
L_70045372a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x388ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x388ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045372b0(Cpu *c) {
    FN_ENTER(0x70045372b0ull);
L_70045372b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x390ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x390ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045372c0(Cpu *c) {
    FN_ENTER(0x70045372c0ull);
L_70045372c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x398ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x398ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045372d0(Cpu *c) {
    FN_ENTER(0x70045372d0ull);
L_70045372d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045372e0(Cpu *c) {
    FN_ENTER(0x70045372e0ull);
L_70045372e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045372f0(Cpu *c) {
    FN_ENTER(0x70045372f0ull);
L_70045372f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537300(Cpu *c) {
    FN_ENTER(0x7004537300ull);
L_7004537300:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537310(Cpu *c) {
    FN_ENTER(0x7004537310ull);
L_7004537310:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537320(Cpu *c) {
    FN_ENTER(0x7004537320ull);
L_7004537320:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537330(Cpu *c) {
    FN_ENTER(0x7004537330ull);
L_7004537330:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537340(Cpu *c) {
    FN_ENTER(0x7004537340ull);
L_7004537340:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537350(Cpu *c) {
    FN_ENTER(0x7004537350ull);
L_7004537350:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537360(Cpu *c) {
    FN_ENTER(0x7004537360ull);
L_7004537360:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537370(Cpu *c) {
    FN_ENTER(0x7004537370ull);
L_7004537370:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537380(Cpu *c) {
    FN_ENTER(0x7004537380ull);
L_7004537380:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x3f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537390(Cpu *c) {
    FN_ENTER(0x7004537390ull);
L_7004537390:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x400ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x400ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045373a0(Cpu *c) {
    FN_ENTER(0x70045373a0ull);
L_70045373a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x408ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x408ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045373b0(Cpu *c) {
    FN_ENTER(0x70045373b0ull);
L_70045373b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x410ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x410ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045373c0(Cpu *c) {
    FN_ENTER(0x70045373c0ull);
L_70045373c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x418ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x418ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045373d0(Cpu *c) {
    FN_ENTER(0x70045373d0ull);
L_70045373d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x420ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x420ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045373e0(Cpu *c) {
    FN_ENTER(0x70045373e0ull);
L_70045373e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x428ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x428ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045373f0(Cpu *c) {
    FN_ENTER(0x70045373f0ull);
L_70045373f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x430ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x430ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537400(Cpu *c) {
    FN_ENTER(0x7004537400ull);
L_7004537400:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x438ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x438ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537410(Cpu *c) {
    FN_ENTER(0x7004537410ull);
L_7004537410:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x440ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x440ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537420(Cpu *c) {
    FN_ENTER(0x7004537420ull);
L_7004537420:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x448ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x448ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537430(Cpu *c) {
    FN_ENTER(0x7004537430ull);
L_7004537430:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537440(Cpu *c) {
    FN_ENTER(0x7004537440ull);
L_7004537440:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537450(Cpu *c) {
    FN_ENTER(0x7004537450ull);
L_7004537450:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537460(Cpu *c) {
    FN_ENTER(0x7004537460ull);
L_7004537460:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537470(Cpu *c) {
    FN_ENTER(0x7004537470ull);
L_7004537470:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537480(Cpu *c) {
    FN_ENTER(0x7004537480ull);
L_7004537480:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537490(Cpu *c) {
    FN_ENTER(0x7004537490ull);
L_7004537490:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045374a0(Cpu *c) {
    FN_ENTER(0x70045374a0ull);
L_70045374a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045374b0(Cpu *c) {
    FN_ENTER(0x70045374b0ull);
L_70045374b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045374c0(Cpu *c) {
    FN_ENTER(0x70045374c0ull);
L_70045374c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045374d0(Cpu *c) {
    FN_ENTER(0x70045374d0ull);
L_70045374d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045374e0(Cpu *c) {
    FN_ENTER(0x70045374e0ull);
L_70045374e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045374f0(Cpu *c) {
    FN_ENTER(0x70045374f0ull);
L_70045374f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537500(Cpu *c) {
    FN_ENTER(0x7004537500ull);
L_7004537500:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537510(Cpu *c) {
    FN_ENTER(0x7004537510ull);
L_7004537510:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537520(Cpu *c) {
    FN_ENTER(0x7004537520ull);
L_7004537520:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537530(Cpu *c) {
    FN_ENTER(0x7004537530ull);
L_7004537530:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537540(Cpu *c) {
    FN_ENTER(0x7004537540ull);
L_7004537540:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537550(Cpu *c) {
    FN_ENTER(0x7004537550ull);
L_7004537550:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537560(Cpu *c) {
    FN_ENTER(0x7004537560ull);
L_7004537560:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537570(Cpu *c) {
    FN_ENTER(0x7004537570ull);
L_7004537570:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537580(Cpu *c) {
    FN_ENTER(0x7004537580ull);
L_7004537580:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537590(Cpu *c) {
    FN_ENTER(0x7004537590ull);
L_7004537590:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045375a0(Cpu *c) {
    FN_ENTER(0x70045375a0ull);
L_70045375a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045375b0(Cpu *c) {
    FN_ENTER(0x70045375b0ull);
L_70045375b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045375c0(Cpu *c) {
    FN_ENTER(0x70045375c0ull);
L_70045375c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045375d0(Cpu *c) {
    FN_ENTER(0x70045375d0ull);
L_70045375d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045375e0(Cpu *c) {
    FN_ENTER(0x70045375e0ull);
L_70045375e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045375f0(Cpu *c) {
    FN_ENTER(0x70045375f0ull);
L_70045375f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537600(Cpu *c) {
    FN_ENTER(0x7004537600ull);
L_7004537600:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537610(Cpu *c) {
    FN_ENTER(0x7004537610ull);
L_7004537610:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537620(Cpu *c) {
    FN_ENTER(0x7004537620ull);
L_7004537620:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537630(Cpu *c) {
    FN_ENTER(0x7004537630ull);
L_7004537630:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537640(Cpu *c) {
    FN_ENTER(0x7004537640ull);
L_7004537640:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537650(Cpu *c) {
    FN_ENTER(0x7004537650ull);
L_7004537650:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537660(Cpu *c) {
    FN_ENTER(0x7004537660ull);
L_7004537660:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537670(Cpu *c) {
    FN_ENTER(0x7004537670ull);
L_7004537670:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537680(Cpu *c) {
    FN_ENTER(0x7004537680ull);
L_7004537680:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537690(Cpu *c) {
    FN_ENTER(0x7004537690ull);
L_7004537690:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045376a0(Cpu *c) {
    FN_ENTER(0x70045376a0ull);
L_70045376a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045376b0(Cpu *c) {
    FN_ENTER(0x70045376b0ull);
L_70045376b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045376c0(Cpu *c) {
    FN_ENTER(0x70045376c0ull);
L_70045376c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045376d0(Cpu *c) {
    FN_ENTER(0x70045376d0ull);
L_70045376d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045376e0(Cpu *c) {
    FN_ENTER(0x70045376e0ull);
L_70045376e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045376f0(Cpu *c) {
    FN_ENTER(0x70045376f0ull);
L_70045376f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537700(Cpu *c) {
    FN_ENTER(0x7004537700ull);
L_7004537700:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537710(Cpu *c) {
    FN_ENTER(0x7004537710ull);
L_7004537710:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537720(Cpu *c) {
    FN_ENTER(0x7004537720ull);
L_7004537720:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537730(Cpu *c) {
    FN_ENTER(0x7004537730ull);
L_7004537730:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537740(Cpu *c) {
    FN_ENTER(0x7004537740ull);
L_7004537740:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537750(Cpu *c) {
    FN_ENTER(0x7004537750ull);
L_7004537750:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537760(Cpu *c) {
    FN_ENTER(0x7004537760ull);
L_7004537760:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537770(Cpu *c) {
    FN_ENTER(0x7004537770ull);
L_7004537770:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537780(Cpu *c) {
    FN_ENTER(0x7004537780ull);
L_7004537780:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537790(Cpu *c) {
    FN_ENTER(0x7004537790ull);
L_7004537790:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045377a0(Cpu *c) {
    FN_ENTER(0x70045377a0ull);
L_70045377a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045377b0(Cpu *c) {
    FN_ENTER(0x70045377b0ull);
L_70045377b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045377c0(Cpu *c) {
    FN_ENTER(0x70045377c0ull);
L_70045377c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045377d0(Cpu *c) {
    FN_ENTER(0x70045377d0ull);
L_70045377d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045377e0(Cpu *c) {
    FN_ENTER(0x70045377e0ull);
L_70045377e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045377f0(Cpu *c) {
    FN_ENTER(0x70045377f0ull);
L_70045377f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537800(Cpu *c) {
    FN_ENTER(0x7004537800ull);
L_7004537800:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537810(Cpu *c) {
    FN_ENTER(0x7004537810ull);
L_7004537810:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537820(Cpu *c) {
    FN_ENTER(0x7004537820ull);
L_7004537820:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537830(Cpu *c) {
    FN_ENTER(0x7004537830ull);
L_7004537830:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537840(Cpu *c) {
    FN_ENTER(0x7004537840ull);
L_7004537840:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537850(Cpu *c) {
    FN_ENTER(0x7004537850ull);
L_7004537850:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537860(Cpu *c) {
    FN_ENTER(0x7004537860ull);
L_7004537860:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537870(Cpu *c) {
    FN_ENTER(0x7004537870ull);
L_7004537870:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537880(Cpu *c) {
    FN_ENTER(0x7004537880ull);
L_7004537880:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537890(Cpu *c) {
    FN_ENTER(0x7004537890ull);
L_7004537890:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045378a0(Cpu *c) {
    FN_ENTER(0x70045378a0ull);
L_70045378a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045378b0(Cpu *c) {
    FN_ENTER(0x70045378b0ull);
L_70045378b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045378c0(Cpu *c) {
    FN_ENTER(0x70045378c0ull);
L_70045378c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045378d0(Cpu *c) {
    FN_ENTER(0x70045378d0ull);
L_70045378d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045378e0(Cpu *c) {
    FN_ENTER(0x70045378e0ull);
L_70045378e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045378f0(Cpu *c) {
    FN_ENTER(0x70045378f0ull);
L_70045378f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537900(Cpu *c) {
    FN_ENTER(0x7004537900ull);
L_7004537900:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537910(Cpu *c) {
    FN_ENTER(0x7004537910ull);
L_7004537910:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537920(Cpu *c) {
    FN_ENTER(0x7004537920ull);
L_7004537920:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537930(Cpu *c) {
    FN_ENTER(0x7004537930ull);
L_7004537930:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537940(Cpu *c) {
    FN_ENTER(0x7004537940ull);
L_7004537940:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537950(Cpu *c) {
    FN_ENTER(0x7004537950ull);
L_7004537950:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537960(Cpu *c) {
    FN_ENTER(0x7004537960ull);
L_7004537960:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537970(Cpu *c) {
    FN_ENTER(0x7004537970ull);
L_7004537970:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537980(Cpu *c) {
    FN_ENTER(0x7004537980ull);
L_7004537980:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537990(Cpu *c) {
    FN_ENTER(0x7004537990ull);
L_7004537990:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045379a0(Cpu *c) {
    FN_ENTER(0x70045379a0ull);
L_70045379a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045379b0(Cpu *c) {
    FN_ENTER(0x70045379b0ull);
L_70045379b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045379c0(Cpu *c) {
    FN_ENTER(0x70045379c0ull);
L_70045379c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045379d0(Cpu *c) {
    FN_ENTER(0x70045379d0ull);
L_70045379d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045379e0(Cpu *c) {
    FN_ENTER(0x70045379e0ull);
L_70045379e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045379f0(Cpu *c) {
    FN_ENTER(0x70045379f0ull);
L_70045379f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a00(Cpu *c) {
    FN_ENTER(0x7004537a00ull);
L_7004537a00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a10(Cpu *c) {
    FN_ENTER(0x7004537a10ull);
L_7004537a10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a20(Cpu *c) {
    FN_ENTER(0x7004537a20ull);
L_7004537a20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a30(Cpu *c) {
    FN_ENTER(0x7004537a30ull);
L_7004537a30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a40(Cpu *c) {
    FN_ENTER(0x7004537a40ull);
L_7004537a40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a50(Cpu *c) {
    FN_ENTER(0x7004537a50ull);
L_7004537a50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a60(Cpu *c) {
    FN_ENTER(0x7004537a60ull);
L_7004537a60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a70(Cpu *c) {
    FN_ENTER(0x7004537a70ull);
L_7004537a70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a80(Cpu *c) {
    FN_ENTER(0x7004537a80ull);
L_7004537a80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537a90(Cpu *c) {
    FN_ENTER(0x7004537a90ull);
L_7004537a90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537aa0(Cpu *c) {
    FN_ENTER(0x7004537aa0ull);
L_7004537aa0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ab0(Cpu *c) {
    FN_ENTER(0x7004537ab0ull);
L_7004537ab0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ac0(Cpu *c) {
    FN_ENTER(0x7004537ac0ull);
L_7004537ac0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ad0(Cpu *c) {
    FN_ENTER(0x7004537ad0ull);
L_7004537ad0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ae0(Cpu *c) {
    FN_ENTER(0x7004537ae0ull);
L_7004537ae0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537af0(Cpu *c) {
    FN_ENTER(0x7004537af0ull);
L_7004537af0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b00(Cpu *c) {
    FN_ENTER(0x7004537b00ull);
L_7004537b00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b10(Cpu *c) {
    FN_ENTER(0x7004537b10ull);
L_7004537b10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b20(Cpu *c) {
    FN_ENTER(0x7004537b20ull);
L_7004537b20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b30(Cpu *c) {
    FN_ENTER(0x7004537b30ull);
L_7004537b30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b40(Cpu *c) {
    FN_ENTER(0x7004537b40ull);
L_7004537b40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b50(Cpu *c) {
    FN_ENTER(0x7004537b50ull);
L_7004537b50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b60(Cpu *c) {
    FN_ENTER(0x7004537b60ull);
L_7004537b60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b70(Cpu *c) {
    FN_ENTER(0x7004537b70ull);
L_7004537b70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b80(Cpu *c) {
    FN_ENTER(0x7004537b80ull);
L_7004537b80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537b90(Cpu *c) {
    FN_ENTER(0x7004537b90ull);
L_7004537b90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ba0(Cpu *c) {
    FN_ENTER(0x7004537ba0ull);
L_7004537ba0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537bb0(Cpu *c) {
    FN_ENTER(0x7004537bb0ull);
L_7004537bb0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537bc0(Cpu *c) {
    FN_ENTER(0x7004537bc0ull);
L_7004537bc0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537bd0(Cpu *c) {
    FN_ENTER(0x7004537bd0ull);
L_7004537bd0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537be0(Cpu *c) {
    FN_ENTER(0x7004537be0ull);
L_7004537be0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537bf0(Cpu *c) {
    FN_ENTER(0x7004537bf0ull);
L_7004537bf0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c00(Cpu *c) {
    FN_ENTER(0x7004537c00ull);
L_7004537c00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c10(Cpu *c) {
    FN_ENTER(0x7004537c10ull);
L_7004537c10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c20(Cpu *c) {
    FN_ENTER(0x7004537c20ull);
L_7004537c20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c30(Cpu *c) {
    FN_ENTER(0x7004537c30ull);
L_7004537c30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c40(Cpu *c) {
    FN_ENTER(0x7004537c40ull);
L_7004537c40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c50(Cpu *c) {
    FN_ENTER(0x7004537c50ull);
L_7004537c50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c60(Cpu *c) {
    FN_ENTER(0x7004537c60ull);
L_7004537c60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c70(Cpu *c) {
    FN_ENTER(0x7004537c70ull);
L_7004537c70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c80(Cpu *c) {
    FN_ENTER(0x7004537c80ull);
L_7004537c80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537c90(Cpu *c) {
    FN_ENTER(0x7004537c90ull);
L_7004537c90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ca0(Cpu *c) {
    FN_ENTER(0x7004537ca0ull);
L_7004537ca0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537cb0(Cpu *c) {
    FN_ENTER(0x7004537cb0ull);
L_7004537cb0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537cc0(Cpu *c) {
    FN_ENTER(0x7004537cc0ull);
L_7004537cc0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537cd0(Cpu *c) {
    FN_ENTER(0x7004537cd0ull);
L_7004537cd0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ce0(Cpu *c) {
    FN_ENTER(0x7004537ce0ull);
L_7004537ce0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537cf0(Cpu *c) {
    FN_ENTER(0x7004537cf0ull);
L_7004537cf0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d00(Cpu *c) {
    FN_ENTER(0x7004537d00ull);
L_7004537d00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d10(Cpu *c) {
    FN_ENTER(0x7004537d10ull);
L_7004537d10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d20(Cpu *c) {
    FN_ENTER(0x7004537d20ull);
L_7004537d20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d30(Cpu *c) {
    FN_ENTER(0x7004537d30ull);
L_7004537d30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d40(Cpu *c) {
    FN_ENTER(0x7004537d40ull);
L_7004537d40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d50(Cpu *c) {
    FN_ENTER(0x7004537d50ull);
L_7004537d50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d60(Cpu *c) {
    FN_ENTER(0x7004537d60ull);
L_7004537d60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d70(Cpu *c) {
    FN_ENTER(0x7004537d70ull);
L_7004537d70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d80(Cpu *c) {
    FN_ENTER(0x7004537d80ull);
L_7004537d80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537d90(Cpu *c) {
    FN_ENTER(0x7004537d90ull);
L_7004537d90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537da0(Cpu *c) {
    FN_ENTER(0x7004537da0ull);
L_7004537da0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537db0(Cpu *c) {
    FN_ENTER(0x7004537db0ull);
L_7004537db0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537dc0(Cpu *c) {
    FN_ENTER(0x7004537dc0ull);
L_7004537dc0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537dd0(Cpu *c) {
    FN_ENTER(0x7004537dd0ull);
L_7004537dd0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537de0(Cpu *c) {
    FN_ENTER(0x7004537de0ull);
L_7004537de0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537df0(Cpu *c) {
    FN_ENTER(0x7004537df0ull);
L_7004537df0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e00(Cpu *c) {
    FN_ENTER(0x7004537e00ull);
L_7004537e00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e10(Cpu *c) {
    FN_ENTER(0x7004537e10ull);
L_7004537e10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e20(Cpu *c) {
    FN_ENTER(0x7004537e20ull);
L_7004537e20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e30(Cpu *c) {
    FN_ENTER(0x7004537e30ull);
L_7004537e30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e40(Cpu *c) {
    FN_ENTER(0x7004537e40ull);
L_7004537e40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e50(Cpu *c) {
    FN_ENTER(0x7004537e50ull);
L_7004537e50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e60(Cpu *c) {
    FN_ENTER(0x7004537e60ull);
L_7004537e60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e70(Cpu *c) {
    FN_ENTER(0x7004537e70ull);
L_7004537e70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e80(Cpu *c) {
    FN_ENTER(0x7004537e80ull);
L_7004537e80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537e90(Cpu *c) {
    FN_ENTER(0x7004537e90ull);
L_7004537e90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ea0(Cpu *c) {
    FN_ENTER(0x7004537ea0ull);
L_7004537ea0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537eb0(Cpu *c) {
    FN_ENTER(0x7004537eb0ull);
L_7004537eb0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ec0(Cpu *c) {
    FN_ENTER(0x7004537ec0ull);
L_7004537ec0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ed0(Cpu *c) {
    FN_ENTER(0x7004537ed0ull);
L_7004537ed0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ee0(Cpu *c) {
    FN_ENTER(0x7004537ee0ull);
L_7004537ee0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ef0(Cpu *c) {
    FN_ENTER(0x7004537ef0ull);
L_7004537ef0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f00(Cpu *c) {
    FN_ENTER(0x7004537f00ull);
L_7004537f00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f10(Cpu *c) {
    FN_ENTER(0x7004537f10ull);
L_7004537f10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f20(Cpu *c) {
    FN_ENTER(0x7004537f20ull);
L_7004537f20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f30(Cpu *c) {
    FN_ENTER(0x7004537f30ull);
L_7004537f30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f40(Cpu *c) {
    FN_ENTER(0x7004537f40ull);
L_7004537f40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f50(Cpu *c) {
    FN_ENTER(0x7004537f50ull);
L_7004537f50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f60(Cpu *c) {
    FN_ENTER(0x7004537f60ull);
L_7004537f60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f70(Cpu *c) {
    FN_ENTER(0x7004537f70ull);
L_7004537f70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f80(Cpu *c) {
    FN_ENTER(0x7004537f80ull);
L_7004537f80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537f90(Cpu *c) {
    FN_ENTER(0x7004537f90ull);
L_7004537f90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537fa0(Cpu *c) {
    FN_ENTER(0x7004537fa0ull);
L_7004537fa0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537fb0(Cpu *c) {
    FN_ENTER(0x7004537fb0ull);
L_7004537fb0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537fc0(Cpu *c) {
    FN_ENTER(0x7004537fc0ull);
L_7004537fc0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537fd0(Cpu *c) {
    FN_ENTER(0x7004537fd0ull);
L_7004537fd0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537fe0(Cpu *c) {
    FN_ENTER(0x7004537fe0ull);
L_7004537fe0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004537ff0(Cpu *c) {
    FN_ENTER(0x7004537ff0ull);
L_7004537ff0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538000(Cpu *c) {
    FN_ENTER(0x7004538000ull);
L_7004538000:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538010(Cpu *c) {
    FN_ENTER(0x7004538010ull);
L_7004538010:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538020(Cpu *c) {
    FN_ENTER(0x7004538020ull);
L_7004538020:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538030(Cpu *c) {
    FN_ENTER(0x7004538030ull);
L_7004538030:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538040(Cpu *c) {
    FN_ENTER(0x7004538040ull);
L_7004538040:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538050(Cpu *c) {
    FN_ENTER(0x7004538050ull);
L_7004538050:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538060(Cpu *c) {
    FN_ENTER(0x7004538060ull);
L_7004538060:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538070(Cpu *c) {
    FN_ENTER(0x7004538070ull);
L_7004538070:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538080(Cpu *c) {
    FN_ENTER(0x7004538080ull);
L_7004538080:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538090(Cpu *c) {
    FN_ENTER(0x7004538090ull);
L_7004538090:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045380a0(Cpu *c) {
    FN_ENTER(0x70045380a0ull);
L_70045380a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045380b0(Cpu *c) {
    FN_ENTER(0x70045380b0ull);
L_70045380b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045380c0(Cpu *c) {
    FN_ENTER(0x70045380c0ull);
L_70045380c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045380d0(Cpu *c) {
    FN_ENTER(0x70045380d0ull);
L_70045380d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045380e0(Cpu *c) {
    FN_ENTER(0x70045380e0ull);
L_70045380e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045380f0(Cpu *c) {
    FN_ENTER(0x70045380f0ull);
L_70045380f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538100(Cpu *c) {
    FN_ENTER(0x7004538100ull);
L_7004538100:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538110(Cpu *c) {
    FN_ENTER(0x7004538110ull);
L_7004538110:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538120(Cpu *c) {
    FN_ENTER(0x7004538120ull);
L_7004538120:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538130(Cpu *c) {
    FN_ENTER(0x7004538130ull);
L_7004538130:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538140(Cpu *c) {
    FN_ENTER(0x7004538140ull);
L_7004538140:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538150(Cpu *c) {
    FN_ENTER(0x7004538150ull);
L_7004538150:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538160(Cpu *c) {
    FN_ENTER(0x7004538160ull);
L_7004538160:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538170(Cpu *c) {
    FN_ENTER(0x7004538170ull);
L_7004538170:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538180(Cpu *c) {
    FN_ENTER(0x7004538180ull);
L_7004538180:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538190(Cpu *c) {
    FN_ENTER(0x7004538190ull);
L_7004538190:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045381a0(Cpu *c) {
    FN_ENTER(0x70045381a0ull);
L_70045381a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045381b0(Cpu *c) {
    FN_ENTER(0x70045381b0ull);
L_70045381b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045381c0(Cpu *c) {
    FN_ENTER(0x70045381c0ull);
L_70045381c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045381d0(Cpu *c) {
    FN_ENTER(0x70045381d0ull);
L_70045381d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045381e0(Cpu *c) {
    FN_ENTER(0x70045381e0ull);
L_70045381e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045381f0(Cpu *c) {
    FN_ENTER(0x70045381f0ull);
L_70045381f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538200(Cpu *c) {
    FN_ENTER(0x7004538200ull);
L_7004538200:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538210(Cpu *c) {
    FN_ENTER(0x7004538210ull);
L_7004538210:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538220(Cpu *c) {
    FN_ENTER(0x7004538220ull);
L_7004538220:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538230(Cpu *c) {
    FN_ENTER(0x7004538230ull);
L_7004538230:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538240(Cpu *c) {
    FN_ENTER(0x7004538240ull);
L_7004538240:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538250(Cpu *c) {
    FN_ENTER(0x7004538250ull);
L_7004538250:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538260(Cpu *c) {
    FN_ENTER(0x7004538260ull);
L_7004538260:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538270(Cpu *c) {
    FN_ENTER(0x7004538270ull);
L_7004538270:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538280(Cpu *c) {
    FN_ENTER(0x7004538280ull);
L_7004538280:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538290(Cpu *c) {
    FN_ENTER(0x7004538290ull);
L_7004538290:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045382a0(Cpu *c) {
    FN_ENTER(0x70045382a0ull);
L_70045382a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045382b0(Cpu *c) {
    FN_ENTER(0x70045382b0ull);
L_70045382b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045382c0(Cpu *c) {
    FN_ENTER(0x70045382c0ull);
L_70045382c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045382d0(Cpu *c) {
    FN_ENTER(0x70045382d0ull);
L_70045382d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045382e0(Cpu *c) {
    FN_ENTER(0x70045382e0ull);
L_70045382e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045382f0(Cpu *c) {
    FN_ENTER(0x70045382f0ull);
L_70045382f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538300(Cpu *c) {
    FN_ENTER(0x7004538300ull);
L_7004538300:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538310(Cpu *c) {
    FN_ENTER(0x7004538310ull);
L_7004538310:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538320(Cpu *c) {
    FN_ENTER(0x7004538320ull);
L_7004538320:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538330(Cpu *c) {
    FN_ENTER(0x7004538330ull);
L_7004538330:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538340(Cpu *c) {
    FN_ENTER(0x7004538340ull);
L_7004538340:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538350(Cpu *c) {
    FN_ENTER(0x7004538350ull);
L_7004538350:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538360(Cpu *c) {
    FN_ENTER(0x7004538360ull);
L_7004538360:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538370(Cpu *c) {
    FN_ENTER(0x7004538370ull);
L_7004538370:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538380(Cpu *c) {
    FN_ENTER(0x7004538380ull);
L_7004538380:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538390(Cpu *c) {
    FN_ENTER(0x7004538390ull);
L_7004538390:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045383a0(Cpu *c) {
    FN_ENTER(0x70045383a0ull);
L_70045383a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045383b0(Cpu *c) {
    FN_ENTER(0x70045383b0ull);
L_70045383b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045383c0(Cpu *c) {
    FN_ENTER(0x70045383c0ull);
L_70045383c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045383d0(Cpu *c) {
    FN_ENTER(0x70045383d0ull);
L_70045383d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045383e0(Cpu *c) {
    FN_ENTER(0x70045383e0ull);
L_70045383e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045383f0(Cpu *c) {
    FN_ENTER(0x70045383f0ull);
L_70045383f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538400(Cpu *c) {
    FN_ENTER(0x7004538400ull);
L_7004538400:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538410(Cpu *c) {
    FN_ENTER(0x7004538410ull);
L_7004538410:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538420(Cpu *c) {
    FN_ENTER(0x7004538420ull);
L_7004538420:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538430(Cpu *c) {
    FN_ENTER(0x7004538430ull);
L_7004538430:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538440(Cpu *c) {
    FN_ENTER(0x7004538440ull);
L_7004538440:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538450(Cpu *c) {
    FN_ENTER(0x7004538450ull);
L_7004538450:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538460(Cpu *c) {
    FN_ENTER(0x7004538460ull);
L_7004538460:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538470(Cpu *c) {
    FN_ENTER(0x7004538470ull);
L_7004538470:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538480(Cpu *c) {
    FN_ENTER(0x7004538480ull);
L_7004538480:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538490(Cpu *c) {
    FN_ENTER(0x7004538490ull);
L_7004538490:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045384a0(Cpu *c) {
    FN_ENTER(0x70045384a0ull);
L_70045384a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045384b0(Cpu *c) {
    FN_ENTER(0x70045384b0ull);
L_70045384b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045384c0(Cpu *c) {
    FN_ENTER(0x70045384c0ull);
L_70045384c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045384d0(Cpu *c) {
    FN_ENTER(0x70045384d0ull);
L_70045384d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045384e0(Cpu *c) {
    FN_ENTER(0x70045384e0ull);
L_70045384e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045384f0(Cpu *c) {
    FN_ENTER(0x70045384f0ull);
L_70045384f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538500(Cpu *c) {
    FN_ENTER(0x7004538500ull);
L_7004538500:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538510(Cpu *c) {
    FN_ENTER(0x7004538510ull);
L_7004538510:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538520(Cpu *c) {
    FN_ENTER(0x7004538520ull);
L_7004538520:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538530(Cpu *c) {
    FN_ENTER(0x7004538530ull);
L_7004538530:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538540(Cpu *c) {
    FN_ENTER(0x7004538540ull);
L_7004538540:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538550(Cpu *c) {
    FN_ENTER(0x7004538550ull);
L_7004538550:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538560(Cpu *c) {
    FN_ENTER(0x7004538560ull);
L_7004538560:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538570(Cpu *c) {
    FN_ENTER(0x7004538570ull);
L_7004538570:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538580(Cpu *c) {
    FN_ENTER(0x7004538580ull);
L_7004538580:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538590(Cpu *c) {
    FN_ENTER(0x7004538590ull);
L_7004538590:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045385a0(Cpu *c) {
    FN_ENTER(0x70045385a0ull);
L_70045385a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045385b0(Cpu *c) {
    FN_ENTER(0x70045385b0ull);
L_70045385b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045385c0(Cpu *c) {
    FN_ENTER(0x70045385c0ull);
L_70045385c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045385d0(Cpu *c) {
    FN_ENTER(0x70045385d0ull);
L_70045385d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045385e0(Cpu *c) {
    FN_ENTER(0x70045385e0ull);
L_70045385e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045385f0(Cpu *c) {
    FN_ENTER(0x70045385f0ull);
L_70045385f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538600(Cpu *c) {
    FN_ENTER(0x7004538600ull);
L_7004538600:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538610(Cpu *c) {
    FN_ENTER(0x7004538610ull);
L_7004538610:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538620(Cpu *c) {
    FN_ENTER(0x7004538620ull);
L_7004538620:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538630(Cpu *c) {
    FN_ENTER(0x7004538630ull);
L_7004538630:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538640(Cpu *c) {
    FN_ENTER(0x7004538640ull);
L_7004538640:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538650(Cpu *c) {
    FN_ENTER(0x7004538650ull);
L_7004538650:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538660(Cpu *c) {
    FN_ENTER(0x7004538660ull);
L_7004538660:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538670(Cpu *c) {
    FN_ENTER(0x7004538670ull);
L_7004538670:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538680(Cpu *c) {
    FN_ENTER(0x7004538680ull);
L_7004538680:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538690(Cpu *c) {
    FN_ENTER(0x7004538690ull);
L_7004538690:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045386a0(Cpu *c) {
    FN_ENTER(0x70045386a0ull);
L_70045386a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045386b0(Cpu *c) {
    FN_ENTER(0x70045386b0ull);
L_70045386b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045386c0(Cpu *c) {
    FN_ENTER(0x70045386c0ull);
L_70045386c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045386d0(Cpu *c) {
    FN_ENTER(0x70045386d0ull);
L_70045386d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045386e0(Cpu *c) {
    FN_ENTER(0x70045386e0ull);
L_70045386e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045386f0(Cpu *c) {
    FN_ENTER(0x70045386f0ull);
L_70045386f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538700(Cpu *c) {
    FN_ENTER(0x7004538700ull);
L_7004538700:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538710(Cpu *c) {
    FN_ENTER(0x7004538710ull);
L_7004538710:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538720(Cpu *c) {
    FN_ENTER(0x7004538720ull);
L_7004538720:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538730(Cpu *c) {
    FN_ENTER(0x7004538730ull);
L_7004538730:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538740(Cpu *c) {
    FN_ENTER(0x7004538740ull);
L_7004538740:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538750(Cpu *c) {
    FN_ENTER(0x7004538750ull);
L_7004538750:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538760(Cpu *c) {
    FN_ENTER(0x7004538760ull);
L_7004538760:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538770(Cpu *c) {
    FN_ENTER(0x7004538770ull);
L_7004538770:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538780(Cpu *c) {
    FN_ENTER(0x7004538780ull);
L_7004538780:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538790(Cpu *c) {
    FN_ENTER(0x7004538790ull);
L_7004538790:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045387a0(Cpu *c) {
    FN_ENTER(0x70045387a0ull);
L_70045387a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045387b0(Cpu *c) {
    FN_ENTER(0x70045387b0ull);
L_70045387b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045387c0(Cpu *c) {
    FN_ENTER(0x70045387c0ull);
L_70045387c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045387d0(Cpu *c) {
    FN_ENTER(0x70045387d0ull);
L_70045387d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045387e0(Cpu *c) {
    FN_ENTER(0x70045387e0ull);
L_70045387e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045387f0(Cpu *c) {
    FN_ENTER(0x70045387f0ull);
L_70045387f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538800(Cpu *c) {
    FN_ENTER(0x7004538800ull);
L_7004538800:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538810(Cpu *c) {
    FN_ENTER(0x7004538810ull);
L_7004538810:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538820(Cpu *c) {
    FN_ENTER(0x7004538820ull);
L_7004538820:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538830(Cpu *c) {
    FN_ENTER(0x7004538830ull);
L_7004538830:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538840(Cpu *c) {
    FN_ENTER(0x7004538840ull);
L_7004538840:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538850(Cpu *c) {
    FN_ENTER(0x7004538850ull);
L_7004538850:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538860(Cpu *c) {
    FN_ENTER(0x7004538860ull);
L_7004538860:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538870(Cpu *c) {
    FN_ENTER(0x7004538870ull);
L_7004538870:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538880(Cpu *c) {
    FN_ENTER(0x7004538880ull);
L_7004538880:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538890(Cpu *c) {
    FN_ENTER(0x7004538890ull);
L_7004538890:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045388a0(Cpu *c) {
    FN_ENTER(0x70045388a0ull);
L_70045388a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045388b0(Cpu *c) {
    FN_ENTER(0x70045388b0ull);
L_70045388b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045388c0(Cpu *c) {
    FN_ENTER(0x70045388c0ull);
L_70045388c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045388d0(Cpu *c) {
    FN_ENTER(0x70045388d0ull);
L_70045388d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045388e0(Cpu *c) {
    FN_ENTER(0x70045388e0ull);
L_70045388e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045388f0(Cpu *c) {
    FN_ENTER(0x70045388f0ull);
L_70045388f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538900(Cpu *c) {
    FN_ENTER(0x7004538900ull);
L_7004538900:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538910(Cpu *c) {
    FN_ENTER(0x7004538910ull);
L_7004538910:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538920(Cpu *c) {
    FN_ENTER(0x7004538920ull);
L_7004538920:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538930(Cpu *c) {
    FN_ENTER(0x7004538930ull);
L_7004538930:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538940(Cpu *c) {
    FN_ENTER(0x7004538940ull);
L_7004538940:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538950(Cpu *c) {
    FN_ENTER(0x7004538950ull);
L_7004538950:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538960(Cpu *c) {
    FN_ENTER(0x7004538960ull);
L_7004538960:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538970(Cpu *c) {
    FN_ENTER(0x7004538970ull);
L_7004538970:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538980(Cpu *c) {
    FN_ENTER(0x7004538980ull);
L_7004538980:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538990(Cpu *c) {
    FN_ENTER(0x7004538990ull);
L_7004538990:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045389a0(Cpu *c) {
    FN_ENTER(0x70045389a0ull);
L_70045389a0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045389b0(Cpu *c) {
    FN_ENTER(0x70045389b0ull);
L_70045389b0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045389c0(Cpu *c) {
    FN_ENTER(0x70045389c0ull);
L_70045389c0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045389d0(Cpu *c) {
    FN_ENTER(0x70045389d0ull);
L_70045389d0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045389e0(Cpu *c) {
    FN_ENTER(0x70045389e0ull);
L_70045389e0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045389f0(Cpu *c) {
    FN_ENTER(0x70045389f0ull);
L_70045389f0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a00(Cpu *c) {
    FN_ENTER(0x7004538a00ull);
L_7004538a00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a10(Cpu *c) {
    FN_ENTER(0x7004538a10ull);
L_7004538a10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a20(Cpu *c) {
    FN_ENTER(0x7004538a20ull);
L_7004538a20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a30(Cpu *c) {
    FN_ENTER(0x7004538a30ull);
L_7004538a30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a40(Cpu *c) {
    FN_ENTER(0x7004538a40ull);
L_7004538a40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a50(Cpu *c) {
    FN_ENTER(0x7004538a50ull);
L_7004538a50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a60(Cpu *c) {
    FN_ENTER(0x7004538a60ull);
L_7004538a60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a70(Cpu *c) {
    FN_ENTER(0x7004538a70ull);
L_7004538a70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a80(Cpu *c) {
    FN_ENTER(0x7004538a80ull);
L_7004538a80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538a90(Cpu *c) {
    FN_ENTER(0x7004538a90ull);
L_7004538a90:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538aa0(Cpu *c) {
    FN_ENTER(0x7004538aa0ull);
L_7004538aa0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538ab0(Cpu *c) {
    FN_ENTER(0x7004538ab0ull);
L_7004538ab0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538ac0(Cpu *c) {
    FN_ENTER(0x7004538ac0ull);
L_7004538ac0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538ad0(Cpu *c) {
    FN_ENTER(0x7004538ad0ull);
L_7004538ad0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538ae0(Cpu *c) {
    FN_ENTER(0x7004538ae0ull);
L_7004538ae0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538af0(Cpu *c) {
    FN_ENTER(0x7004538af0ull);
L_7004538af0:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b00(Cpu *c) {
    FN_ENTER(0x7004538b00ull);
L_7004538b00:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b10(Cpu *c) {
    FN_ENTER(0x7004538b10ull);
L_7004538b10:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b20(Cpu *c) {
    FN_ENTER(0x7004538b20ull);
L_7004538b20:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b30(Cpu *c) {
    FN_ENTER(0x7004538b30ull);
L_7004538b30:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b40(Cpu *c) {
    FN_ENTER(0x7004538b40ull);
L_7004538b40:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b50(Cpu *c) {
    FN_ENTER(0x7004538b50ull);
L_7004538b50:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b60(Cpu *c) {
    FN_ENTER(0x7004538b60ull);
L_7004538b60:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b70(Cpu *c) {
    FN_ENTER(0x7004538b70ull);
L_7004538b70:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b80(Cpu *c) {
    FN_ENTER(0x7004538b80ull);
L_7004538b80:;
    c->x[16] = (uint64_t)(0x7004c34000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538b90(Cpu *c) {
    FN_ENTER(0x7004538b90ull);
L_7004538b90:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538ba0(Cpu *c) {
    FN_ENTER(0x7004538ba0ull);
L_7004538ba0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538bb0(Cpu *c) {
    FN_ENTER(0x7004538bb0ull);
L_7004538bb0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538bc0(Cpu *c) {
    FN_ENTER(0x7004538bc0ull);
L_7004538bc0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538bd0(Cpu *c) {
    FN_ENTER(0x7004538bd0ull);
L_7004538bd0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538be0(Cpu *c) {
    FN_ENTER(0x7004538be0ull);
L_7004538be0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538bf0(Cpu *c) {
    FN_ENTER(0x7004538bf0ull);
L_7004538bf0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c00(Cpu *c) {
    FN_ENTER(0x7004538c00ull);
L_7004538c00:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c10(Cpu *c) {
    FN_ENTER(0x7004538c10ull);
L_7004538c10:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c20(Cpu *c) {
    FN_ENTER(0x7004538c20ull);
L_7004538c20:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c30(Cpu *c) {
    FN_ENTER(0x7004538c30ull);
L_7004538c30:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c40(Cpu *c) {
    FN_ENTER(0x7004538c40ull);
L_7004538c40:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c50(Cpu *c) {
    FN_ENTER(0x7004538c50ull);
L_7004538c50:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c60(Cpu *c) {
    FN_ENTER(0x7004538c60ull);
L_7004538c60:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c70(Cpu *c) {
    FN_ENTER(0x7004538c70ull);
L_7004538c70:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c80(Cpu *c) {
    FN_ENTER(0x7004538c80ull);
L_7004538c80:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538c90(Cpu *c) {
    FN_ENTER(0x7004538c90ull);
L_7004538c90:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538ca0(Cpu *c) {
    FN_ENTER(0x7004538ca0ull);
L_7004538ca0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538cb0(Cpu *c) {
    FN_ENTER(0x7004538cb0ull);
L_7004538cb0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538cc0(Cpu *c) {
    FN_ENTER(0x7004538cc0ull);
L_7004538cc0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538cd0(Cpu *c) {
    FN_ENTER(0x7004538cd0ull);
L_7004538cd0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538ce0(Cpu *c) {
    FN_ENTER(0x7004538ce0ull);
L_7004538ce0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538cf0(Cpu *c) {
    FN_ENTER(0x7004538cf0ull);
L_7004538cf0:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538d00(Cpu *c) {
    FN_ENTER(0x7004538d00ull);
L_7004538d00:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538d10(Cpu *c) {
    FN_ENTER(0x7004538d10ull);
L_7004538d10:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538d20(Cpu *c) {
    FN_ENTER(0x7004538d20ull);
L_7004538d20:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538d30(Cpu *c) {
    FN_ENTER(0x7004538d30ull);
L_7004538d30:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538d40(Cpu *c) {
    FN_ENTER(0x7004538d40ull);
L_7004538d40:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538d50(Cpu *c) {
    FN_ENTER(0x7004538d50ull);
L_7004538d50:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004538d60(Cpu *c) {
    FN_ENTER(0x7004538d60ull);
L_7004538d60:;
    c->x[16] = (uint64_t)(0x7004c35000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
