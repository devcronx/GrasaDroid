#include "cpu.h"
#include "simd.h"
void f_7004527430(Cpu *c) {
    FN_ENTER(0x7004527430ull);
L_7004527430:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527440(Cpu *c) {
    FN_ENTER(0x7004527440ull);
L_7004527440:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527450(Cpu *c) {
    FN_ENTER(0x7004527450ull);
L_7004527450:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527460(Cpu *c) {
    FN_ENTER(0x7004527460ull);
L_7004527460:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527470(Cpu *c) {
    FN_ENTER(0x7004527470ull);
L_7004527470:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527480(Cpu *c) {
    FN_ENTER(0x7004527480ull);
L_7004527480:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527490(Cpu *c) {
    FN_ENTER(0x7004527490ull);
L_7004527490:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045274a0(Cpu *c) {
    FN_ENTER(0x70045274a0ull);
L_70045274a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045274b0(Cpu *c) {
    FN_ENTER(0x70045274b0ull);
L_70045274b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045274c0(Cpu *c) {
    FN_ENTER(0x70045274c0ull);
L_70045274c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045274d0(Cpu *c) {
    FN_ENTER(0x70045274d0ull);
L_70045274d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045274e0(Cpu *c) {
    FN_ENTER(0x70045274e0ull);
L_70045274e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045274f0(Cpu *c) {
    FN_ENTER(0x70045274f0ull);
L_70045274f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527500(Cpu *c) {
    FN_ENTER(0x7004527500ull);
L_7004527500:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527510(Cpu *c) {
    FN_ENTER(0x7004527510ull);
L_7004527510:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527520(Cpu *c) {
    FN_ENTER(0x7004527520ull);
L_7004527520:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527530(Cpu *c) {
    FN_ENTER(0x7004527530ull);
L_7004527530:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527540(Cpu *c) {
    FN_ENTER(0x7004527540ull);
L_7004527540:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527550(Cpu *c) {
    FN_ENTER(0x7004527550ull);
L_7004527550:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527560(Cpu *c) {
    FN_ENTER(0x7004527560ull);
L_7004527560:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527570(Cpu *c) {
    FN_ENTER(0x7004527570ull);
L_7004527570:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527580(Cpu *c) {
    FN_ENTER(0x7004527580ull);
L_7004527580:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527590(Cpu *c) {
    FN_ENTER(0x7004527590ull);
L_7004527590:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045275a0(Cpu *c) {
    FN_ENTER(0x70045275a0ull);
L_70045275a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045275b0(Cpu *c) {
    FN_ENTER(0x70045275b0ull);
L_70045275b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045275c0(Cpu *c) {
    FN_ENTER(0x70045275c0ull);
L_70045275c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045275d0(Cpu *c) {
    FN_ENTER(0x70045275d0ull);
L_70045275d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045275e0(Cpu *c) {
    FN_ENTER(0x70045275e0ull);
L_70045275e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045275f0(Cpu *c) {
    FN_ENTER(0x70045275f0ull);
L_70045275f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527600(Cpu *c) {
    FN_ENTER(0x7004527600ull);
L_7004527600:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527610(Cpu *c) {
    FN_ENTER(0x7004527610ull);
L_7004527610:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527620(Cpu *c) {
    FN_ENTER(0x7004527620ull);
L_7004527620:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527630(Cpu *c) {
    FN_ENTER(0x7004527630ull);
L_7004527630:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527640(Cpu *c) {
    FN_ENTER(0x7004527640ull);
L_7004527640:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527650(Cpu *c) {
    FN_ENTER(0x7004527650ull);
L_7004527650:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527660(Cpu *c) {
    FN_ENTER(0x7004527660ull);
L_7004527660:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527670(Cpu *c) {
    FN_ENTER(0x7004527670ull);
L_7004527670:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527680(Cpu *c) {
    FN_ENTER(0x7004527680ull);
L_7004527680:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527690(Cpu *c) {
    FN_ENTER(0x7004527690ull);
L_7004527690:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045276a0(Cpu *c) {
    FN_ENTER(0x70045276a0ull);
L_70045276a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045276b0(Cpu *c) {
    FN_ENTER(0x70045276b0ull);
L_70045276b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045276c0(Cpu *c) {
    FN_ENTER(0x70045276c0ull);
L_70045276c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045276d0(Cpu *c) {
    FN_ENTER(0x70045276d0ull);
L_70045276d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045276e0(Cpu *c) {
    FN_ENTER(0x70045276e0ull);
L_70045276e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045276f0(Cpu *c) {
    FN_ENTER(0x70045276f0ull);
L_70045276f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527700(Cpu *c) {
    FN_ENTER(0x7004527700ull);
L_7004527700:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527710(Cpu *c) {
    FN_ENTER(0x7004527710ull);
L_7004527710:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527720(Cpu *c) {
    FN_ENTER(0x7004527720ull);
L_7004527720:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527730(Cpu *c) {
    FN_ENTER(0x7004527730ull);
L_7004527730:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527740(Cpu *c) {
    FN_ENTER(0x7004527740ull);
L_7004527740:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527750(Cpu *c) {
    FN_ENTER(0x7004527750ull);
L_7004527750:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527760(Cpu *c) {
    FN_ENTER(0x7004527760ull);
L_7004527760:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527770(Cpu *c) {
    FN_ENTER(0x7004527770ull);
L_7004527770:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527780(Cpu *c) {
    FN_ENTER(0x7004527780ull);
L_7004527780:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527790(Cpu *c) {
    FN_ENTER(0x7004527790ull);
L_7004527790:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045277a0(Cpu *c) {
    FN_ENTER(0x70045277a0ull);
L_70045277a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045277b0(Cpu *c) {
    FN_ENTER(0x70045277b0ull);
L_70045277b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045277c0(Cpu *c) {
    FN_ENTER(0x70045277c0ull);
L_70045277c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045277d0(Cpu *c) {
    FN_ENTER(0x70045277d0ull);
L_70045277d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045277e0(Cpu *c) {
    FN_ENTER(0x70045277e0ull);
L_70045277e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045277f0(Cpu *c) {
    FN_ENTER(0x70045277f0ull);
L_70045277f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527800(Cpu *c) {
    FN_ENTER(0x7004527800ull);
L_7004527800:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527810(Cpu *c) {
    FN_ENTER(0x7004527810ull);
L_7004527810:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527820(Cpu *c) {
    FN_ENTER(0x7004527820ull);
L_7004527820:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527830(Cpu *c) {
    FN_ENTER(0x7004527830ull);
L_7004527830:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527840(Cpu *c) {
    FN_ENTER(0x7004527840ull);
L_7004527840:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527850(Cpu *c) {
    FN_ENTER(0x7004527850ull);
L_7004527850:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527860(Cpu *c) {
    FN_ENTER(0x7004527860ull);
L_7004527860:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527870(Cpu *c) {
    FN_ENTER(0x7004527870ull);
L_7004527870:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527880(Cpu *c) {
    FN_ENTER(0x7004527880ull);
L_7004527880:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527890(Cpu *c) {
    FN_ENTER(0x7004527890ull);
L_7004527890:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045278a0(Cpu *c) {
    FN_ENTER(0x70045278a0ull);
L_70045278a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045278b0(Cpu *c) {
    FN_ENTER(0x70045278b0ull);
L_70045278b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045278c0(Cpu *c) {
    FN_ENTER(0x70045278c0ull);
L_70045278c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045278d0(Cpu *c) {
    FN_ENTER(0x70045278d0ull);
L_70045278d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045278e0(Cpu *c) {
    FN_ENTER(0x70045278e0ull);
L_70045278e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045278f0(Cpu *c) {
    FN_ENTER(0x70045278f0ull);
L_70045278f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527900(Cpu *c) {
    FN_ENTER(0x7004527900ull);
L_7004527900:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527910(Cpu *c) {
    FN_ENTER(0x7004527910ull);
L_7004527910:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527920(Cpu *c) {
    FN_ENTER(0x7004527920ull);
L_7004527920:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527930(Cpu *c) {
    FN_ENTER(0x7004527930ull);
L_7004527930:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527940(Cpu *c) {
    FN_ENTER(0x7004527940ull);
L_7004527940:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527950(Cpu *c) {
    FN_ENTER(0x7004527950ull);
L_7004527950:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527960(Cpu *c) {
    FN_ENTER(0x7004527960ull);
L_7004527960:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527970(Cpu *c) {
    FN_ENTER(0x7004527970ull);
L_7004527970:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527980(Cpu *c) {
    FN_ENTER(0x7004527980ull);
L_7004527980:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527990(Cpu *c) {
    FN_ENTER(0x7004527990ull);
L_7004527990:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045279a0(Cpu *c) {
    FN_ENTER(0x70045279a0ull);
L_70045279a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045279b0(Cpu *c) {
    FN_ENTER(0x70045279b0ull);
L_70045279b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045279c0(Cpu *c) {
    FN_ENTER(0x70045279c0ull);
L_70045279c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045279d0(Cpu *c) {
    FN_ENTER(0x70045279d0ull);
L_70045279d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045279e0(Cpu *c) {
    FN_ENTER(0x70045279e0ull);
L_70045279e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045279f0(Cpu *c) {
    FN_ENTER(0x70045279f0ull);
L_70045279f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a00(Cpu *c) {
    FN_ENTER(0x7004527a00ull);
L_7004527a00:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a10(Cpu *c) {
    FN_ENTER(0x7004527a10ull);
L_7004527a10:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a20(Cpu *c) {
    FN_ENTER(0x7004527a20ull);
L_7004527a20:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a30(Cpu *c) {
    FN_ENTER(0x7004527a30ull);
L_7004527a30:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a40(Cpu *c) {
    FN_ENTER(0x7004527a40ull);
L_7004527a40:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a50(Cpu *c) {
    FN_ENTER(0x7004527a50ull);
L_7004527a50:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a60(Cpu *c) {
    FN_ENTER(0x7004527a60ull);
L_7004527a60:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a70(Cpu *c) {
    FN_ENTER(0x7004527a70ull);
L_7004527a70:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a80(Cpu *c) {
    FN_ENTER(0x7004527a80ull);
L_7004527a80:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527a90(Cpu *c) {
    FN_ENTER(0x7004527a90ull);
L_7004527a90:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527aa0(Cpu *c) {
    FN_ENTER(0x7004527aa0ull);
L_7004527aa0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ab0(Cpu *c) {
    FN_ENTER(0x7004527ab0ull);
L_7004527ab0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ac0(Cpu *c) {
    FN_ENTER(0x7004527ac0ull);
L_7004527ac0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ad0(Cpu *c) {
    FN_ENTER(0x7004527ad0ull);
L_7004527ad0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ae0(Cpu *c) {
    FN_ENTER(0x7004527ae0ull);
L_7004527ae0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527af0(Cpu *c) {
    FN_ENTER(0x7004527af0ull);
L_7004527af0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b00(Cpu *c) {
    FN_ENTER(0x7004527b00ull);
L_7004527b00:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b10(Cpu *c) {
    FN_ENTER(0x7004527b10ull);
L_7004527b10:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b20(Cpu *c) {
    FN_ENTER(0x7004527b20ull);
L_7004527b20:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b30(Cpu *c) {
    FN_ENTER(0x7004527b30ull);
L_7004527b30:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b40(Cpu *c) {
    FN_ENTER(0x7004527b40ull);
L_7004527b40:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b50(Cpu *c) {
    FN_ENTER(0x7004527b50ull);
L_7004527b50:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b60(Cpu *c) {
    FN_ENTER(0x7004527b60ull);
L_7004527b60:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b70(Cpu *c) {
    FN_ENTER(0x7004527b70ull);
L_7004527b70:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b80(Cpu *c) {
    FN_ENTER(0x7004527b80ull);
L_7004527b80:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527b90(Cpu *c) {
    FN_ENTER(0x7004527b90ull);
L_7004527b90:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ba0(Cpu *c) {
    FN_ENTER(0x7004527ba0ull);
L_7004527ba0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527bb0(Cpu *c) {
    FN_ENTER(0x7004527bb0ull);
L_7004527bb0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527bc0(Cpu *c) {
    FN_ENTER(0x7004527bc0ull);
L_7004527bc0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527bd0(Cpu *c) {
    FN_ENTER(0x7004527bd0ull);
L_7004527bd0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527be0(Cpu *c) {
    FN_ENTER(0x7004527be0ull);
L_7004527be0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527bf0(Cpu *c) {
    FN_ENTER(0x7004527bf0ull);
L_7004527bf0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c00(Cpu *c) {
    FN_ENTER(0x7004527c00ull);
L_7004527c00:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c10(Cpu *c) {
    FN_ENTER(0x7004527c10ull);
L_7004527c10:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c20(Cpu *c) {
    FN_ENTER(0x7004527c20ull);
L_7004527c20:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c30(Cpu *c) {
    FN_ENTER(0x7004527c30ull);
L_7004527c30:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c40(Cpu *c) {
    FN_ENTER(0x7004527c40ull);
L_7004527c40:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c50(Cpu *c) {
    FN_ENTER(0x7004527c50ull);
L_7004527c50:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c60(Cpu *c) {
    FN_ENTER(0x7004527c60ull);
L_7004527c60:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c70(Cpu *c) {
    FN_ENTER(0x7004527c70ull);
L_7004527c70:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c80(Cpu *c) {
    FN_ENTER(0x7004527c80ull);
L_7004527c80:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527c90(Cpu *c) {
    FN_ENTER(0x7004527c90ull);
L_7004527c90:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ca0(Cpu *c) {
    FN_ENTER(0x7004527ca0ull);
L_7004527ca0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527cb0(Cpu *c) {
    FN_ENTER(0x7004527cb0ull);
L_7004527cb0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527cc0(Cpu *c) {
    FN_ENTER(0x7004527cc0ull);
L_7004527cc0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527cd0(Cpu *c) {
    FN_ENTER(0x7004527cd0ull);
L_7004527cd0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ce0(Cpu *c) {
    FN_ENTER(0x7004527ce0ull);
L_7004527ce0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527cf0(Cpu *c) {
    FN_ENTER(0x7004527cf0ull);
L_7004527cf0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d00(Cpu *c) {
    FN_ENTER(0x7004527d00ull);
L_7004527d00:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d10(Cpu *c) {
    FN_ENTER(0x7004527d10ull);
L_7004527d10:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d20(Cpu *c) {
    FN_ENTER(0x7004527d20ull);
L_7004527d20:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d30(Cpu *c) {
    FN_ENTER(0x7004527d30ull);
L_7004527d30:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d40(Cpu *c) {
    FN_ENTER(0x7004527d40ull);
L_7004527d40:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d50(Cpu *c) {
    FN_ENTER(0x7004527d50ull);
L_7004527d50:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d60(Cpu *c) {
    FN_ENTER(0x7004527d60ull);
L_7004527d60:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d70(Cpu *c) {
    FN_ENTER(0x7004527d70ull);
L_7004527d70:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d80(Cpu *c) {
    FN_ENTER(0x7004527d80ull);
L_7004527d80:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527d90(Cpu *c) {
    FN_ENTER(0x7004527d90ull);
L_7004527d90:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527da0(Cpu *c) {
    FN_ENTER(0x7004527da0ull);
L_7004527da0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527db0(Cpu *c) {
    FN_ENTER(0x7004527db0ull);
L_7004527db0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527dc0(Cpu *c) {
    FN_ENTER(0x7004527dc0ull);
L_7004527dc0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527dd0(Cpu *c) {
    FN_ENTER(0x7004527dd0ull);
L_7004527dd0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527de0(Cpu *c) {
    FN_ENTER(0x7004527de0ull);
L_7004527de0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527df0(Cpu *c) {
    FN_ENTER(0x7004527df0ull);
L_7004527df0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e00(Cpu *c) {
    FN_ENTER(0x7004527e00ull);
L_7004527e00:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e10(Cpu *c) {
    FN_ENTER(0x7004527e10ull);
L_7004527e10:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e20(Cpu *c) {
    FN_ENTER(0x7004527e20ull);
L_7004527e20:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e30(Cpu *c) {
    FN_ENTER(0x7004527e30ull);
L_7004527e30:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e40(Cpu *c) {
    FN_ENTER(0x7004527e40ull);
L_7004527e40:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e50(Cpu *c) {
    FN_ENTER(0x7004527e50ull);
L_7004527e50:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e60(Cpu *c) {
    FN_ENTER(0x7004527e60ull);
L_7004527e60:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e70(Cpu *c) {
    FN_ENTER(0x7004527e70ull);
L_7004527e70:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e80(Cpu *c) {
    FN_ENTER(0x7004527e80ull);
L_7004527e80:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527e90(Cpu *c) {
    FN_ENTER(0x7004527e90ull);
L_7004527e90:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ea0(Cpu *c) {
    FN_ENTER(0x7004527ea0ull);
L_7004527ea0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527eb0(Cpu *c) {
    FN_ENTER(0x7004527eb0ull);
L_7004527eb0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ec0(Cpu *c) {
    FN_ENTER(0x7004527ec0ull);
L_7004527ec0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ed0(Cpu *c) {
    FN_ENTER(0x7004527ed0ull);
L_7004527ed0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ee0(Cpu *c) {
    FN_ENTER(0x7004527ee0ull);
L_7004527ee0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ef0(Cpu *c) {
    FN_ENTER(0x7004527ef0ull);
L_7004527ef0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f00(Cpu *c) {
    FN_ENTER(0x7004527f00ull);
L_7004527f00:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f10(Cpu *c) {
    FN_ENTER(0x7004527f10ull);
L_7004527f10:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f20(Cpu *c) {
    FN_ENTER(0x7004527f20ull);
L_7004527f20:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f30(Cpu *c) {
    FN_ENTER(0x7004527f30ull);
L_7004527f30:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f40(Cpu *c) {
    FN_ENTER(0x7004527f40ull);
L_7004527f40:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f50(Cpu *c) {
    FN_ENTER(0x7004527f50ull);
L_7004527f50:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f60(Cpu *c) {
    FN_ENTER(0x7004527f60ull);
L_7004527f60:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f70(Cpu *c) {
    FN_ENTER(0x7004527f70ull);
L_7004527f70:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f80(Cpu *c) {
    FN_ENTER(0x7004527f80ull);
L_7004527f80:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527f90(Cpu *c) {
    FN_ENTER(0x7004527f90ull);
L_7004527f90:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527fa0(Cpu *c) {
    FN_ENTER(0x7004527fa0ull);
L_7004527fa0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527fb0(Cpu *c) {
    FN_ENTER(0x7004527fb0ull);
L_7004527fb0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527fc0(Cpu *c) {
    FN_ENTER(0x7004527fc0ull);
L_7004527fc0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527fd0(Cpu *c) {
    FN_ENTER(0x7004527fd0ull);
L_7004527fd0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527fe0(Cpu *c) {
    FN_ENTER(0x7004527fe0ull);
L_7004527fe0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004527ff0(Cpu *c) {
    FN_ENTER(0x7004527ff0ull);
L_7004527ff0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528000(Cpu *c) {
    FN_ENTER(0x7004528000ull);
L_7004528000:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528010(Cpu *c) {
    FN_ENTER(0x7004528010ull);
L_7004528010:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528020(Cpu *c) {
    FN_ENTER(0x7004528020ull);
L_7004528020:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528030(Cpu *c) {
    FN_ENTER(0x7004528030ull);
L_7004528030:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528040(Cpu *c) {
    FN_ENTER(0x7004528040ull);
L_7004528040:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528050(Cpu *c) {
    FN_ENTER(0x7004528050ull);
L_7004528050:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528060(Cpu *c) {
    FN_ENTER(0x7004528060ull);
L_7004528060:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528070(Cpu *c) {
    FN_ENTER(0x7004528070ull);
L_7004528070:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528080(Cpu *c) {
    FN_ENTER(0x7004528080ull);
L_7004528080:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528090(Cpu *c) {
    FN_ENTER(0x7004528090ull);
L_7004528090:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045280a0(Cpu *c) {
    FN_ENTER(0x70045280a0ull);
L_70045280a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045280b0(Cpu *c) {
    FN_ENTER(0x70045280b0ull);
L_70045280b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045280c0(Cpu *c) {
    FN_ENTER(0x70045280c0ull);
L_70045280c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045280d0(Cpu *c) {
    FN_ENTER(0x70045280d0ull);
L_70045280d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045280e0(Cpu *c) {
    FN_ENTER(0x70045280e0ull);
L_70045280e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045280f0(Cpu *c) {
    FN_ENTER(0x70045280f0ull);
L_70045280f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528100(Cpu *c) {
    FN_ENTER(0x7004528100ull);
L_7004528100:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528110(Cpu *c) {
    FN_ENTER(0x7004528110ull);
L_7004528110:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528120(Cpu *c) {
    FN_ENTER(0x7004528120ull);
L_7004528120:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528130(Cpu *c) {
    FN_ENTER(0x7004528130ull);
L_7004528130:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528140(Cpu *c) {
    FN_ENTER(0x7004528140ull);
L_7004528140:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528150(Cpu *c) {
    FN_ENTER(0x7004528150ull);
L_7004528150:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528160(Cpu *c) {
    FN_ENTER(0x7004528160ull);
L_7004528160:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528170(Cpu *c) {
    FN_ENTER(0x7004528170ull);
L_7004528170:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528180(Cpu *c) {
    FN_ENTER(0x7004528180ull);
L_7004528180:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528190(Cpu *c) {
    FN_ENTER(0x7004528190ull);
L_7004528190:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045281a0(Cpu *c) {
    FN_ENTER(0x70045281a0ull);
L_70045281a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045281b0(Cpu *c) {
    FN_ENTER(0x70045281b0ull);
L_70045281b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045281c0(Cpu *c) {
    FN_ENTER(0x70045281c0ull);
L_70045281c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045281d0(Cpu *c) {
    FN_ENTER(0x70045281d0ull);
L_70045281d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045281e0(Cpu *c) {
    FN_ENTER(0x70045281e0ull);
L_70045281e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045281f0(Cpu *c) {
    FN_ENTER(0x70045281f0ull);
L_70045281f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528200(Cpu *c) {
    FN_ENTER(0x7004528200ull);
L_7004528200:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528210(Cpu *c) {
    FN_ENTER(0x7004528210ull);
L_7004528210:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528220(Cpu *c) {
    FN_ENTER(0x7004528220ull);
L_7004528220:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528230(Cpu *c) {
    FN_ENTER(0x7004528230ull);
L_7004528230:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528240(Cpu *c) {
    FN_ENTER(0x7004528240ull);
L_7004528240:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528250(Cpu *c) {
    FN_ENTER(0x7004528250ull);
L_7004528250:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528260(Cpu *c) {
    FN_ENTER(0x7004528260ull);
L_7004528260:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528270(Cpu *c) {
    FN_ENTER(0x7004528270ull);
L_7004528270:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528280(Cpu *c) {
    FN_ENTER(0x7004528280ull);
L_7004528280:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528290(Cpu *c) {
    FN_ENTER(0x7004528290ull);
L_7004528290:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045282a0(Cpu *c) {
    FN_ENTER(0x70045282a0ull);
L_70045282a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045282b0(Cpu *c) {
    FN_ENTER(0x70045282b0ull);
L_70045282b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045282c0(Cpu *c) {
    FN_ENTER(0x70045282c0ull);
L_70045282c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045282d0(Cpu *c) {
    FN_ENTER(0x70045282d0ull);
L_70045282d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045282e0(Cpu *c) {
    FN_ENTER(0x70045282e0ull);
L_70045282e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045282f0(Cpu *c) {
    FN_ENTER(0x70045282f0ull);
L_70045282f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528300(Cpu *c) {
    FN_ENTER(0x7004528300ull);
L_7004528300:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528310(Cpu *c) {
    FN_ENTER(0x7004528310ull);
L_7004528310:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528320(Cpu *c) {
    FN_ENTER(0x7004528320ull);
L_7004528320:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528330(Cpu *c) {
    FN_ENTER(0x7004528330ull);
L_7004528330:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528340(Cpu *c) {
    FN_ENTER(0x7004528340ull);
L_7004528340:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528350(Cpu *c) {
    FN_ENTER(0x7004528350ull);
L_7004528350:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528360(Cpu *c) {
    FN_ENTER(0x7004528360ull);
L_7004528360:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528370(Cpu *c) {
    FN_ENTER(0x7004528370ull);
L_7004528370:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528380(Cpu *c) {
    FN_ENTER(0x7004528380ull);
L_7004528380:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528390(Cpu *c) {
    FN_ENTER(0x7004528390ull);
L_7004528390:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045283a0(Cpu *c) {
    FN_ENTER(0x70045283a0ull);
L_70045283a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045283b0(Cpu *c) {
    FN_ENTER(0x70045283b0ull);
L_70045283b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045283c0(Cpu *c) {
    FN_ENTER(0x70045283c0ull);
L_70045283c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045283d0(Cpu *c) {
    FN_ENTER(0x70045283d0ull);
L_70045283d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045283e0(Cpu *c) {
    FN_ENTER(0x70045283e0ull);
L_70045283e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045283f0(Cpu *c) {
    FN_ENTER(0x70045283f0ull);
L_70045283f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528400(Cpu *c) {
    FN_ENTER(0x7004528400ull);
L_7004528400:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528410(Cpu *c) {
    FN_ENTER(0x7004528410ull);
L_7004528410:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528420(Cpu *c) {
    FN_ENTER(0x7004528420ull);
L_7004528420:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528430(Cpu *c) {
    FN_ENTER(0x7004528430ull);
L_7004528430:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528440(Cpu *c) {
    FN_ENTER(0x7004528440ull);
L_7004528440:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528450(Cpu *c) {
    FN_ENTER(0x7004528450ull);
L_7004528450:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528460(Cpu *c) {
    FN_ENTER(0x7004528460ull);
L_7004528460:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528470(Cpu *c) {
    FN_ENTER(0x7004528470ull);
L_7004528470:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528480(Cpu *c) {
    FN_ENTER(0x7004528480ull);
L_7004528480:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528490(Cpu *c) {
    FN_ENTER(0x7004528490ull);
L_7004528490:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045284a0(Cpu *c) {
    FN_ENTER(0x70045284a0ull);
L_70045284a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045284b0(Cpu *c) {
    FN_ENTER(0x70045284b0ull);
L_70045284b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045284c0(Cpu *c) {
    FN_ENTER(0x70045284c0ull);
L_70045284c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045284d0(Cpu *c) {
    FN_ENTER(0x70045284d0ull);
L_70045284d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045284e0(Cpu *c) {
    FN_ENTER(0x70045284e0ull);
L_70045284e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045284f0(Cpu *c) {
    FN_ENTER(0x70045284f0ull);
L_70045284f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528500(Cpu *c) {
    FN_ENTER(0x7004528500ull);
L_7004528500:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528510(Cpu *c) {
    FN_ENTER(0x7004528510ull);
L_7004528510:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528520(Cpu *c) {
    FN_ENTER(0x7004528520ull);
L_7004528520:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528530(Cpu *c) {
    FN_ENTER(0x7004528530ull);
L_7004528530:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528540(Cpu *c) {
    FN_ENTER(0x7004528540ull);
L_7004528540:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528550(Cpu *c) {
    FN_ENTER(0x7004528550ull);
L_7004528550:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528560(Cpu *c) {
    FN_ENTER(0x7004528560ull);
L_7004528560:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528570(Cpu *c) {
    FN_ENTER(0x7004528570ull);
L_7004528570:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528580(Cpu *c) {
    FN_ENTER(0x7004528580ull);
L_7004528580:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528590(Cpu *c) {
    FN_ENTER(0x7004528590ull);
L_7004528590:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045285a0(Cpu *c) {
    FN_ENTER(0x70045285a0ull);
L_70045285a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045285b0(Cpu *c) {
    FN_ENTER(0x70045285b0ull);
L_70045285b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045285c0(Cpu *c) {
    FN_ENTER(0x70045285c0ull);
L_70045285c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045285d0(Cpu *c) {
    FN_ENTER(0x70045285d0ull);
L_70045285d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045285e0(Cpu *c) {
    FN_ENTER(0x70045285e0ull);
L_70045285e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045285f0(Cpu *c) {
    FN_ENTER(0x70045285f0ull);
L_70045285f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528600(Cpu *c) {
    FN_ENTER(0x7004528600ull);
L_7004528600:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528610(Cpu *c) {
    FN_ENTER(0x7004528610ull);
L_7004528610:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528620(Cpu *c) {
    FN_ENTER(0x7004528620ull);
L_7004528620:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528630(Cpu *c) {
    FN_ENTER(0x7004528630ull);
L_7004528630:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528640(Cpu *c) {
    FN_ENTER(0x7004528640ull);
L_7004528640:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528650(Cpu *c) {
    FN_ENTER(0x7004528650ull);
L_7004528650:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528660(Cpu *c) {
    FN_ENTER(0x7004528660ull);
L_7004528660:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528670(Cpu *c) {
    FN_ENTER(0x7004528670ull);
L_7004528670:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528680(Cpu *c) {
    FN_ENTER(0x7004528680ull);
L_7004528680:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528690(Cpu *c) {
    FN_ENTER(0x7004528690ull);
L_7004528690:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045286a0(Cpu *c) {
    FN_ENTER(0x70045286a0ull);
L_70045286a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045286b0(Cpu *c) {
    FN_ENTER(0x70045286b0ull);
L_70045286b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045286c0(Cpu *c) {
    FN_ENTER(0x70045286c0ull);
L_70045286c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045286d0(Cpu *c) {
    FN_ENTER(0x70045286d0ull);
L_70045286d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045286e0(Cpu *c) {
    FN_ENTER(0x70045286e0ull);
L_70045286e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045286f0(Cpu *c) {
    FN_ENTER(0x70045286f0ull);
L_70045286f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528700(Cpu *c) {
    FN_ENTER(0x7004528700ull);
L_7004528700:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528710(Cpu *c) {
    FN_ENTER(0x7004528710ull);
L_7004528710:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528720(Cpu *c) {
    FN_ENTER(0x7004528720ull);
L_7004528720:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528730(Cpu *c) {
    FN_ENTER(0x7004528730ull);
L_7004528730:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528740(Cpu *c) {
    FN_ENTER(0x7004528740ull);
L_7004528740:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528750(Cpu *c) {
    FN_ENTER(0x7004528750ull);
L_7004528750:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528760(Cpu *c) {
    FN_ENTER(0x7004528760ull);
L_7004528760:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528770(Cpu *c) {
    FN_ENTER(0x7004528770ull);
L_7004528770:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528780(Cpu *c) {
    FN_ENTER(0x7004528780ull);
L_7004528780:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528790(Cpu *c) {
    FN_ENTER(0x7004528790ull);
L_7004528790:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045287a0(Cpu *c) {
    FN_ENTER(0x70045287a0ull);
L_70045287a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045287b0(Cpu *c) {
    FN_ENTER(0x70045287b0ull);
L_70045287b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045287c0(Cpu *c) {
    FN_ENTER(0x70045287c0ull);
L_70045287c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045287d0(Cpu *c) {
    FN_ENTER(0x70045287d0ull);
L_70045287d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045287e0(Cpu *c) {
    FN_ENTER(0x70045287e0ull);
L_70045287e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045287f0(Cpu *c) {
    FN_ENTER(0x70045287f0ull);
L_70045287f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528800(Cpu *c) {
    FN_ENTER(0x7004528800ull);
L_7004528800:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528810(Cpu *c) {
    FN_ENTER(0x7004528810ull);
L_7004528810:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528820(Cpu *c) {
    FN_ENTER(0x7004528820ull);
L_7004528820:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528830(Cpu *c) {
    FN_ENTER(0x7004528830ull);
L_7004528830:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528840(Cpu *c) {
    FN_ENTER(0x7004528840ull);
L_7004528840:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528850(Cpu *c) {
    FN_ENTER(0x7004528850ull);
L_7004528850:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528860(Cpu *c) {
    FN_ENTER(0x7004528860ull);
L_7004528860:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528870(Cpu *c) {
    FN_ENTER(0x7004528870ull);
L_7004528870:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528880(Cpu *c) {
    FN_ENTER(0x7004528880ull);
L_7004528880:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528890(Cpu *c) {
    FN_ENTER(0x7004528890ull);
L_7004528890:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045288a0(Cpu *c) {
    FN_ENTER(0x70045288a0ull);
L_70045288a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045288b0(Cpu *c) {
    FN_ENTER(0x70045288b0ull);
L_70045288b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045288c0(Cpu *c) {
    FN_ENTER(0x70045288c0ull);
L_70045288c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045288d0(Cpu *c) {
    FN_ENTER(0x70045288d0ull);
L_70045288d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045288e0(Cpu *c) {
    FN_ENTER(0x70045288e0ull);
L_70045288e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045288f0(Cpu *c) {
    FN_ENTER(0x70045288f0ull);
L_70045288f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528900(Cpu *c) {
    FN_ENTER(0x7004528900ull);
L_7004528900:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528910(Cpu *c) {
    FN_ENTER(0x7004528910ull);
L_7004528910:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528920(Cpu *c) {
    FN_ENTER(0x7004528920ull);
L_7004528920:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528930(Cpu *c) {
    FN_ENTER(0x7004528930ull);
L_7004528930:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528940(Cpu *c) {
    FN_ENTER(0x7004528940ull);
L_7004528940:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528950(Cpu *c) {
    FN_ENTER(0x7004528950ull);
L_7004528950:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528960(Cpu *c) {
    FN_ENTER(0x7004528960ull);
L_7004528960:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528970(Cpu *c) {
    FN_ENTER(0x7004528970ull);
L_7004528970:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528980(Cpu *c) {
    FN_ENTER(0x7004528980ull);
L_7004528980:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528990(Cpu *c) {
    FN_ENTER(0x7004528990ull);
L_7004528990:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045289a0(Cpu *c) {
    FN_ENTER(0x70045289a0ull);
L_70045289a0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045289b0(Cpu *c) {
    FN_ENTER(0x70045289b0ull);
L_70045289b0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045289c0(Cpu *c) {
    FN_ENTER(0x70045289c0ull);
L_70045289c0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045289d0(Cpu *c) {
    FN_ENTER(0x70045289d0ull);
L_70045289d0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045289e0(Cpu *c) {
    FN_ENTER(0x70045289e0ull);
L_70045289e0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045289f0(Cpu *c) {
    FN_ENTER(0x70045289f0ull);
L_70045289f0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a00(Cpu *c) {
    FN_ENTER(0x7004528a00ull);
L_7004528a00:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a10(Cpu *c) {
    FN_ENTER(0x7004528a10ull);
L_7004528a10:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a20(Cpu *c) {
    FN_ENTER(0x7004528a20ull);
L_7004528a20:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a30(Cpu *c) {
    FN_ENTER(0x7004528a30ull);
L_7004528a30:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a40(Cpu *c) {
    FN_ENTER(0x7004528a40ull);
L_7004528a40:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a50(Cpu *c) {
    FN_ENTER(0x7004528a50ull);
L_7004528a50:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a60(Cpu *c) {
    FN_ENTER(0x7004528a60ull);
L_7004528a60:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a70(Cpu *c) {
    FN_ENTER(0x7004528a70ull);
L_7004528a70:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a80(Cpu *c) {
    FN_ENTER(0x7004528a80ull);
L_7004528a80:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528a90(Cpu *c) {
    FN_ENTER(0x7004528a90ull);
L_7004528a90:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528aa0(Cpu *c) {
    FN_ENTER(0x7004528aa0ull);
L_7004528aa0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ab0(Cpu *c) {
    FN_ENTER(0x7004528ab0ull);
L_7004528ab0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ac0(Cpu *c) {
    FN_ENTER(0x7004528ac0ull);
L_7004528ac0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ad0(Cpu *c) {
    FN_ENTER(0x7004528ad0ull);
L_7004528ad0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ae0(Cpu *c) {
    FN_ENTER(0x7004528ae0ull);
L_7004528ae0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528af0(Cpu *c) {
    FN_ENTER(0x7004528af0ull);
L_7004528af0:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b00(Cpu *c) {
    FN_ENTER(0x7004528b00ull);
L_7004528b00:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b10(Cpu *c) {
    FN_ENTER(0x7004528b10ull);
L_7004528b10:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b20(Cpu *c) {
    FN_ENTER(0x7004528b20ull);
L_7004528b20:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b30(Cpu *c) {
    FN_ENTER(0x7004528b30ull);
L_7004528b30:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b40(Cpu *c) {
    FN_ENTER(0x7004528b40ull);
L_7004528b40:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b50(Cpu *c) {
    FN_ENTER(0x7004528b50ull);
L_7004528b50:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b60(Cpu *c) {
    FN_ENTER(0x7004528b60ull);
L_7004528b60:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b70(Cpu *c) {
    FN_ENTER(0x7004528b70ull);
L_7004528b70:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b80(Cpu *c) {
    FN_ENTER(0x7004528b80ull);
L_7004528b80:;
    c->x[16] = (uint64_t)(0x7004c2c000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528b90(Cpu *c) {
    FN_ENTER(0x7004528b90ull);
L_7004528b90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ba0(Cpu *c) {
    FN_ENTER(0x7004528ba0ull);
L_7004528ba0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528bb0(Cpu *c) {
    FN_ENTER(0x7004528bb0ull);
L_7004528bb0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528bc0(Cpu *c) {
    FN_ENTER(0x7004528bc0ull);
L_7004528bc0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528bd0(Cpu *c) {
    FN_ENTER(0x7004528bd0ull);
L_7004528bd0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528be0(Cpu *c) {
    FN_ENTER(0x7004528be0ull);
L_7004528be0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528bf0(Cpu *c) {
    FN_ENTER(0x7004528bf0ull);
L_7004528bf0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c00(Cpu *c) {
    FN_ENTER(0x7004528c00ull);
L_7004528c00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c10(Cpu *c) {
    FN_ENTER(0x7004528c10ull);
L_7004528c10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c20(Cpu *c) {
    FN_ENTER(0x7004528c20ull);
L_7004528c20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c30(Cpu *c) {
    FN_ENTER(0x7004528c30ull);
L_7004528c30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c40(Cpu *c) {
    FN_ENTER(0x7004528c40ull);
L_7004528c40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c50(Cpu *c) {
    FN_ENTER(0x7004528c50ull);
L_7004528c50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c60(Cpu *c) {
    FN_ENTER(0x7004528c60ull);
L_7004528c60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c70(Cpu *c) {
    FN_ENTER(0x7004528c70ull);
L_7004528c70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c80(Cpu *c) {
    FN_ENTER(0x7004528c80ull);
L_7004528c80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528c90(Cpu *c) {
    FN_ENTER(0x7004528c90ull);
L_7004528c90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ca0(Cpu *c) {
    FN_ENTER(0x7004528ca0ull);
L_7004528ca0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528cb0(Cpu *c) {
    FN_ENTER(0x7004528cb0ull);
L_7004528cb0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528cc0(Cpu *c) {
    FN_ENTER(0x7004528cc0ull);
L_7004528cc0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528cd0(Cpu *c) {
    FN_ENTER(0x7004528cd0ull);
L_7004528cd0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ce0(Cpu *c) {
    FN_ENTER(0x7004528ce0ull);
L_7004528ce0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528cf0(Cpu *c) {
    FN_ENTER(0x7004528cf0ull);
L_7004528cf0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d00(Cpu *c) {
    FN_ENTER(0x7004528d00ull);
L_7004528d00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d10(Cpu *c) {
    FN_ENTER(0x7004528d10ull);
L_7004528d10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d20(Cpu *c) {
    FN_ENTER(0x7004528d20ull);
L_7004528d20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d30(Cpu *c) {
    FN_ENTER(0x7004528d30ull);
L_7004528d30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d40(Cpu *c) {
    FN_ENTER(0x7004528d40ull);
L_7004528d40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d50(Cpu *c) {
    FN_ENTER(0x7004528d50ull);
L_7004528d50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d60(Cpu *c) {
    FN_ENTER(0x7004528d60ull);
L_7004528d60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d70(Cpu *c) {
    FN_ENTER(0x7004528d70ull);
L_7004528d70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d80(Cpu *c) {
    FN_ENTER(0x7004528d80ull);
L_7004528d80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528d90(Cpu *c) {
    FN_ENTER(0x7004528d90ull);
L_7004528d90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x100ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x100ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528da0(Cpu *c) {
    FN_ENTER(0x7004528da0ull);
L_7004528da0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x108ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x108ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528db0(Cpu *c) {
    FN_ENTER(0x7004528db0ull);
L_7004528db0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x110ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x110ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528dc0(Cpu *c) {
    FN_ENTER(0x7004528dc0ull);
L_7004528dc0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x118ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x118ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528dd0(Cpu *c) {
    FN_ENTER(0x7004528dd0ull);
L_7004528dd0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x120ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x120ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528de0(Cpu *c) {
    FN_ENTER(0x7004528de0ull);
L_7004528de0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x128ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x128ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528df0(Cpu *c) {
    FN_ENTER(0x7004528df0ull);
L_7004528df0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x130ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x130ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e00(Cpu *c) {
    FN_ENTER(0x7004528e00ull);
L_7004528e00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x138ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x138ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e10(Cpu *c) {
    FN_ENTER(0x7004528e10ull);
L_7004528e10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x140ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x140ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e20(Cpu *c) {
    FN_ENTER(0x7004528e20ull);
L_7004528e20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x148ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x148ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e30(Cpu *c) {
    FN_ENTER(0x7004528e30ull);
L_7004528e30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x150ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x150ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e40(Cpu *c) {
    FN_ENTER(0x7004528e40ull);
L_7004528e40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x158ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x158ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e50(Cpu *c) {
    FN_ENTER(0x7004528e50ull);
L_7004528e50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x160ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x160ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e60(Cpu *c) {
    FN_ENTER(0x7004528e60ull);
L_7004528e60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x168ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x168ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e70(Cpu *c) {
    FN_ENTER(0x7004528e70ull);
L_7004528e70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x170ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x170ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e80(Cpu *c) {
    FN_ENTER(0x7004528e80ull);
L_7004528e80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x178ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x178ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528e90(Cpu *c) {
    FN_ENTER(0x7004528e90ull);
L_7004528e90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x180ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x180ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ea0(Cpu *c) {
    FN_ENTER(0x7004528ea0ull);
L_7004528ea0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x188ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x188ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528eb0(Cpu *c) {
    FN_ENTER(0x7004528eb0ull);
L_7004528eb0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x190ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x190ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ec0(Cpu *c) {
    FN_ENTER(0x7004528ec0ull);
L_7004528ec0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x198ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x198ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ed0(Cpu *c) {
    FN_ENTER(0x7004528ed0ull);
L_7004528ed0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ee0(Cpu *c) {
    FN_ENTER(0x7004528ee0ull);
L_7004528ee0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ef0(Cpu *c) {
    FN_ENTER(0x7004528ef0ull);
L_7004528ef0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f00(Cpu *c) {
    FN_ENTER(0x7004528f00ull);
L_7004528f00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f10(Cpu *c) {
    FN_ENTER(0x7004528f10ull);
L_7004528f10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f20(Cpu *c) {
    FN_ENTER(0x7004528f20ull);
L_7004528f20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f30(Cpu *c) {
    FN_ENTER(0x7004528f30ull);
L_7004528f30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f40(Cpu *c) {
    FN_ENTER(0x7004528f40ull);
L_7004528f40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f50(Cpu *c) {
    FN_ENTER(0x7004528f50ull);
L_7004528f50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f60(Cpu *c) {
    FN_ENTER(0x7004528f60ull);
L_7004528f60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f70(Cpu *c) {
    FN_ENTER(0x7004528f70ull);
L_7004528f70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f80(Cpu *c) {
    FN_ENTER(0x7004528f80ull);
L_7004528f80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x1f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528f90(Cpu *c) {
    FN_ENTER(0x7004528f90ull);
L_7004528f90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x200ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x200ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528fa0(Cpu *c) {
    FN_ENTER(0x7004528fa0ull);
L_7004528fa0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x208ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x208ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528fb0(Cpu *c) {
    FN_ENTER(0x7004528fb0ull);
L_7004528fb0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x210ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x210ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528fc0(Cpu *c) {
    FN_ENTER(0x7004528fc0ull);
L_7004528fc0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x218ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x218ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528fd0(Cpu *c) {
    FN_ENTER(0x7004528fd0ull);
L_7004528fd0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x220ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x220ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528fe0(Cpu *c) {
    FN_ENTER(0x7004528fe0ull);
L_7004528fe0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x228ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x228ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004528ff0(Cpu *c) {
    FN_ENTER(0x7004528ff0ull);
L_7004528ff0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x230ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x230ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529000(Cpu *c) {
    FN_ENTER(0x7004529000ull);
L_7004529000:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x238ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x238ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529010(Cpu *c) {
    FN_ENTER(0x7004529010ull);
L_7004529010:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x240ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x240ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529020(Cpu *c) {
    FN_ENTER(0x7004529020ull);
L_7004529020:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x248ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x248ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529030(Cpu *c) {
    FN_ENTER(0x7004529030ull);
L_7004529030:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x250ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x250ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529040(Cpu *c) {
    FN_ENTER(0x7004529040ull);
L_7004529040:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x258ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x258ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529050(Cpu *c) {
    FN_ENTER(0x7004529050ull);
L_7004529050:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x260ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x260ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529060(Cpu *c) {
    FN_ENTER(0x7004529060ull);
L_7004529060:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x268ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x268ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529070(Cpu *c) {
    FN_ENTER(0x7004529070ull);
L_7004529070:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x270ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x270ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529080(Cpu *c) {
    FN_ENTER(0x7004529080ull);
L_7004529080:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x278ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x278ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529090(Cpu *c) {
    FN_ENTER(0x7004529090ull);
L_7004529090:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x280ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x280ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045290a0(Cpu *c) {
    FN_ENTER(0x70045290a0ull);
L_70045290a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x288ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x288ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045290b0(Cpu *c) {
    FN_ENTER(0x70045290b0ull);
L_70045290b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x290ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x290ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045290c0(Cpu *c) {
    FN_ENTER(0x70045290c0ull);
L_70045290c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x298ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x298ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045290d0(Cpu *c) {
    FN_ENTER(0x70045290d0ull);
L_70045290d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045290e0(Cpu *c) {
    FN_ENTER(0x70045290e0ull);
L_70045290e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045290f0(Cpu *c) {
    FN_ENTER(0x70045290f0ull);
L_70045290f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529100(Cpu *c) {
    FN_ENTER(0x7004529100ull);
L_7004529100:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529110(Cpu *c) {
    FN_ENTER(0x7004529110ull);
L_7004529110:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529120(Cpu *c) {
    FN_ENTER(0x7004529120ull);
L_7004529120:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529130(Cpu *c) {
    FN_ENTER(0x7004529130ull);
L_7004529130:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529140(Cpu *c) {
    FN_ENTER(0x7004529140ull);
L_7004529140:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529150(Cpu *c) {
    FN_ENTER(0x7004529150ull);
L_7004529150:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529160(Cpu *c) {
    FN_ENTER(0x7004529160ull);
L_7004529160:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529170(Cpu *c) {
    FN_ENTER(0x7004529170ull);
L_7004529170:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529180(Cpu *c) {
    FN_ENTER(0x7004529180ull);
L_7004529180:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x2f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529190(Cpu *c) {
    FN_ENTER(0x7004529190ull);
L_7004529190:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x300ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x300ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045291a0(Cpu *c) {
    FN_ENTER(0x70045291a0ull);
L_70045291a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x308ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x308ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045291b0(Cpu *c) {
    FN_ENTER(0x70045291b0ull);
L_70045291b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x310ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x310ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045291c0(Cpu *c) {
    FN_ENTER(0x70045291c0ull);
L_70045291c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x318ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x318ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045291d0(Cpu *c) {
    FN_ENTER(0x70045291d0ull);
L_70045291d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x320ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x320ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045291e0(Cpu *c) {
    FN_ENTER(0x70045291e0ull);
L_70045291e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x328ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x328ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045291f0(Cpu *c) {
    FN_ENTER(0x70045291f0ull);
L_70045291f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x330ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x330ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529200(Cpu *c) {
    FN_ENTER(0x7004529200ull);
L_7004529200:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x338ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x338ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529210(Cpu *c) {
    FN_ENTER(0x7004529210ull);
L_7004529210:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x340ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x340ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529220(Cpu *c) {
    FN_ENTER(0x7004529220ull);
L_7004529220:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x348ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x348ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529230(Cpu *c) {
    FN_ENTER(0x7004529230ull);
L_7004529230:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x350ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x350ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529240(Cpu *c) {
    FN_ENTER(0x7004529240ull);
L_7004529240:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x358ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x358ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529250(Cpu *c) {
    FN_ENTER(0x7004529250ull);
L_7004529250:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x360ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x360ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529260(Cpu *c) {
    FN_ENTER(0x7004529260ull);
L_7004529260:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x368ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x368ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529270(Cpu *c) {
    FN_ENTER(0x7004529270ull);
L_7004529270:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x370ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x370ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529280(Cpu *c) {
    FN_ENTER(0x7004529280ull);
L_7004529280:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x378ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x378ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529290(Cpu *c) {
    FN_ENTER(0x7004529290ull);
L_7004529290:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x380ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x380ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045292a0(Cpu *c) {
    FN_ENTER(0x70045292a0ull);
L_70045292a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x388ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x388ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045292b0(Cpu *c) {
    FN_ENTER(0x70045292b0ull);
L_70045292b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x390ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x390ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045292c0(Cpu *c) {
    FN_ENTER(0x70045292c0ull);
L_70045292c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x398ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x398ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045292d0(Cpu *c) {
    FN_ENTER(0x70045292d0ull);
L_70045292d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045292e0(Cpu *c) {
    FN_ENTER(0x70045292e0ull);
L_70045292e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045292f0(Cpu *c) {
    FN_ENTER(0x70045292f0ull);
L_70045292f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529300(Cpu *c) {
    FN_ENTER(0x7004529300ull);
L_7004529300:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529310(Cpu *c) {
    FN_ENTER(0x7004529310ull);
L_7004529310:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529320(Cpu *c) {
    FN_ENTER(0x7004529320ull);
L_7004529320:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529330(Cpu *c) {
    FN_ENTER(0x7004529330ull);
L_7004529330:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529340(Cpu *c) {
    FN_ENTER(0x7004529340ull);
L_7004529340:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529350(Cpu *c) {
    FN_ENTER(0x7004529350ull);
L_7004529350:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529360(Cpu *c) {
    FN_ENTER(0x7004529360ull);
L_7004529360:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529370(Cpu *c) {
    FN_ENTER(0x7004529370ull);
L_7004529370:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529380(Cpu *c) {
    FN_ENTER(0x7004529380ull);
L_7004529380:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x3f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529390(Cpu *c) {
    FN_ENTER(0x7004529390ull);
L_7004529390:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x400ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x400ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045293a0(Cpu *c) {
    FN_ENTER(0x70045293a0ull);
L_70045293a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x408ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x408ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045293b0(Cpu *c) {
    FN_ENTER(0x70045293b0ull);
L_70045293b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x410ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x410ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045293c0(Cpu *c) {
    FN_ENTER(0x70045293c0ull);
L_70045293c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x418ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x418ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045293d0(Cpu *c) {
    FN_ENTER(0x70045293d0ull);
L_70045293d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x420ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x420ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045293e0(Cpu *c) {
    FN_ENTER(0x70045293e0ull);
L_70045293e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x428ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x428ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045293f0(Cpu *c) {
    FN_ENTER(0x70045293f0ull);
L_70045293f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x430ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x430ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529400(Cpu *c) {
    FN_ENTER(0x7004529400ull);
L_7004529400:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x438ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x438ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529410(Cpu *c) {
    FN_ENTER(0x7004529410ull);
L_7004529410:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x440ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x440ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529420(Cpu *c) {
    FN_ENTER(0x7004529420ull);
L_7004529420:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x448ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x448ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529430(Cpu *c) {
    FN_ENTER(0x7004529430ull);
L_7004529430:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529440(Cpu *c) {
    FN_ENTER(0x7004529440ull);
L_7004529440:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529450(Cpu *c) {
    FN_ENTER(0x7004529450ull);
L_7004529450:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529460(Cpu *c) {
    FN_ENTER(0x7004529460ull);
L_7004529460:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529470(Cpu *c) {
    FN_ENTER(0x7004529470ull);
L_7004529470:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529480(Cpu *c) {
    FN_ENTER(0x7004529480ull);
L_7004529480:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529490(Cpu *c) {
    FN_ENTER(0x7004529490ull);
L_7004529490:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045294a0(Cpu *c) {
    FN_ENTER(0x70045294a0ull);
L_70045294a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045294b0(Cpu *c) {
    FN_ENTER(0x70045294b0ull);
L_70045294b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045294c0(Cpu *c) {
    FN_ENTER(0x70045294c0ull);
L_70045294c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045294d0(Cpu *c) {
    FN_ENTER(0x70045294d0ull);
L_70045294d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045294e0(Cpu *c) {
    FN_ENTER(0x70045294e0ull);
L_70045294e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045294f0(Cpu *c) {
    FN_ENTER(0x70045294f0ull);
L_70045294f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529500(Cpu *c) {
    FN_ENTER(0x7004529500ull);
L_7004529500:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529510(Cpu *c) {
    FN_ENTER(0x7004529510ull);
L_7004529510:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529520(Cpu *c) {
    FN_ENTER(0x7004529520ull);
L_7004529520:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529530(Cpu *c) {
    FN_ENTER(0x7004529530ull);
L_7004529530:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529540(Cpu *c) {
    FN_ENTER(0x7004529540ull);
L_7004529540:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529550(Cpu *c) {
    FN_ENTER(0x7004529550ull);
L_7004529550:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529560(Cpu *c) {
    FN_ENTER(0x7004529560ull);
L_7004529560:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529570(Cpu *c) {
    FN_ENTER(0x7004529570ull);
L_7004529570:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529580(Cpu *c) {
    FN_ENTER(0x7004529580ull);
L_7004529580:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529590(Cpu *c) {
    FN_ENTER(0x7004529590ull);
L_7004529590:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045295a0(Cpu *c) {
    FN_ENTER(0x70045295a0ull);
L_70045295a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045295b0(Cpu *c) {
    FN_ENTER(0x70045295b0ull);
L_70045295b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045295c0(Cpu *c) {
    FN_ENTER(0x70045295c0ull);
L_70045295c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045295d0(Cpu *c) {
    FN_ENTER(0x70045295d0ull);
L_70045295d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045295e0(Cpu *c) {
    FN_ENTER(0x70045295e0ull);
L_70045295e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045295f0(Cpu *c) {
    FN_ENTER(0x70045295f0ull);
L_70045295f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529600(Cpu *c) {
    FN_ENTER(0x7004529600ull);
L_7004529600:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529610(Cpu *c) {
    FN_ENTER(0x7004529610ull);
L_7004529610:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529620(Cpu *c) {
    FN_ENTER(0x7004529620ull);
L_7004529620:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529630(Cpu *c) {
    FN_ENTER(0x7004529630ull);
L_7004529630:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529640(Cpu *c) {
    FN_ENTER(0x7004529640ull);
L_7004529640:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529650(Cpu *c) {
    FN_ENTER(0x7004529650ull);
L_7004529650:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529660(Cpu *c) {
    FN_ENTER(0x7004529660ull);
L_7004529660:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529670(Cpu *c) {
    FN_ENTER(0x7004529670ull);
L_7004529670:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529680(Cpu *c) {
    FN_ENTER(0x7004529680ull);
L_7004529680:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529690(Cpu *c) {
    FN_ENTER(0x7004529690ull);
L_7004529690:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045296a0(Cpu *c) {
    FN_ENTER(0x70045296a0ull);
L_70045296a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045296b0(Cpu *c) {
    FN_ENTER(0x70045296b0ull);
L_70045296b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045296c0(Cpu *c) {
    FN_ENTER(0x70045296c0ull);
L_70045296c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045296d0(Cpu *c) {
    FN_ENTER(0x70045296d0ull);
L_70045296d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045296e0(Cpu *c) {
    FN_ENTER(0x70045296e0ull);
L_70045296e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045296f0(Cpu *c) {
    FN_ENTER(0x70045296f0ull);
L_70045296f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529700(Cpu *c) {
    FN_ENTER(0x7004529700ull);
L_7004529700:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529710(Cpu *c) {
    FN_ENTER(0x7004529710ull);
L_7004529710:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529720(Cpu *c) {
    FN_ENTER(0x7004529720ull);
L_7004529720:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529730(Cpu *c) {
    FN_ENTER(0x7004529730ull);
L_7004529730:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529740(Cpu *c) {
    FN_ENTER(0x7004529740ull);
L_7004529740:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529750(Cpu *c) {
    FN_ENTER(0x7004529750ull);
L_7004529750:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529760(Cpu *c) {
    FN_ENTER(0x7004529760ull);
L_7004529760:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529770(Cpu *c) {
    FN_ENTER(0x7004529770ull);
L_7004529770:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529780(Cpu *c) {
    FN_ENTER(0x7004529780ull);
L_7004529780:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529790(Cpu *c) {
    FN_ENTER(0x7004529790ull);
L_7004529790:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045297a0(Cpu *c) {
    FN_ENTER(0x70045297a0ull);
L_70045297a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045297b0(Cpu *c) {
    FN_ENTER(0x70045297b0ull);
L_70045297b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045297c0(Cpu *c) {
    FN_ENTER(0x70045297c0ull);
L_70045297c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045297d0(Cpu *c) {
    FN_ENTER(0x70045297d0ull);
L_70045297d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045297e0(Cpu *c) {
    FN_ENTER(0x70045297e0ull);
L_70045297e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045297f0(Cpu *c) {
    FN_ENTER(0x70045297f0ull);
L_70045297f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529800(Cpu *c) {
    FN_ENTER(0x7004529800ull);
L_7004529800:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529810(Cpu *c) {
    FN_ENTER(0x7004529810ull);
L_7004529810:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529820(Cpu *c) {
    FN_ENTER(0x7004529820ull);
L_7004529820:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529830(Cpu *c) {
    FN_ENTER(0x7004529830ull);
L_7004529830:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529840(Cpu *c) {
    FN_ENTER(0x7004529840ull);
L_7004529840:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529850(Cpu *c) {
    FN_ENTER(0x7004529850ull);
L_7004529850:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529860(Cpu *c) {
    FN_ENTER(0x7004529860ull);
L_7004529860:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529870(Cpu *c) {
    FN_ENTER(0x7004529870ull);
L_7004529870:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529880(Cpu *c) {
    FN_ENTER(0x7004529880ull);
L_7004529880:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529890(Cpu *c) {
    FN_ENTER(0x7004529890ull);
L_7004529890:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045298a0(Cpu *c) {
    FN_ENTER(0x70045298a0ull);
L_70045298a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045298b0(Cpu *c) {
    FN_ENTER(0x70045298b0ull);
L_70045298b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045298c0(Cpu *c) {
    FN_ENTER(0x70045298c0ull);
L_70045298c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045298d0(Cpu *c) {
    FN_ENTER(0x70045298d0ull);
L_70045298d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045298e0(Cpu *c) {
    FN_ENTER(0x70045298e0ull);
L_70045298e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045298f0(Cpu *c) {
    FN_ENTER(0x70045298f0ull);
L_70045298f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529900(Cpu *c) {
    FN_ENTER(0x7004529900ull);
L_7004529900:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529910(Cpu *c) {
    FN_ENTER(0x7004529910ull);
L_7004529910:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529920(Cpu *c) {
    FN_ENTER(0x7004529920ull);
L_7004529920:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529930(Cpu *c) {
    FN_ENTER(0x7004529930ull);
L_7004529930:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529940(Cpu *c) {
    FN_ENTER(0x7004529940ull);
L_7004529940:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529950(Cpu *c) {
    FN_ENTER(0x7004529950ull);
L_7004529950:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529960(Cpu *c) {
    FN_ENTER(0x7004529960ull);
L_7004529960:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529970(Cpu *c) {
    FN_ENTER(0x7004529970ull);
L_7004529970:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529980(Cpu *c) {
    FN_ENTER(0x7004529980ull);
L_7004529980:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529990(Cpu *c) {
    FN_ENTER(0x7004529990ull);
L_7004529990:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045299a0(Cpu *c) {
    FN_ENTER(0x70045299a0ull);
L_70045299a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045299b0(Cpu *c) {
    FN_ENTER(0x70045299b0ull);
L_70045299b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045299c0(Cpu *c) {
    FN_ENTER(0x70045299c0ull);
L_70045299c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045299d0(Cpu *c) {
    FN_ENTER(0x70045299d0ull);
L_70045299d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045299e0(Cpu *c) {
    FN_ENTER(0x70045299e0ull);
L_70045299e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_70045299f0(Cpu *c) {
    FN_ENTER(0x70045299f0ull);
L_70045299f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a00(Cpu *c) {
    FN_ENTER(0x7004529a00ull);
L_7004529a00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a10(Cpu *c) {
    FN_ENTER(0x7004529a10ull);
L_7004529a10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a20(Cpu *c) {
    FN_ENTER(0x7004529a20ull);
L_7004529a20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a30(Cpu *c) {
    FN_ENTER(0x7004529a30ull);
L_7004529a30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a40(Cpu *c) {
    FN_ENTER(0x7004529a40ull);
L_7004529a40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a50(Cpu *c) {
    FN_ENTER(0x7004529a50ull);
L_7004529a50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a60(Cpu *c) {
    FN_ENTER(0x7004529a60ull);
L_7004529a60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a70(Cpu *c) {
    FN_ENTER(0x7004529a70ull);
L_7004529a70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a80(Cpu *c) {
    FN_ENTER(0x7004529a80ull);
L_7004529a80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529a90(Cpu *c) {
    FN_ENTER(0x7004529a90ull);
L_7004529a90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529aa0(Cpu *c) {
    FN_ENTER(0x7004529aa0ull);
L_7004529aa0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ab0(Cpu *c) {
    FN_ENTER(0x7004529ab0ull);
L_7004529ab0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ac0(Cpu *c) {
    FN_ENTER(0x7004529ac0ull);
L_7004529ac0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ad0(Cpu *c) {
    FN_ENTER(0x7004529ad0ull);
L_7004529ad0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ae0(Cpu *c) {
    FN_ENTER(0x7004529ae0ull);
L_7004529ae0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529af0(Cpu *c) {
    FN_ENTER(0x7004529af0ull);
L_7004529af0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b00(Cpu *c) {
    FN_ENTER(0x7004529b00ull);
L_7004529b00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b10(Cpu *c) {
    FN_ENTER(0x7004529b10ull);
L_7004529b10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b20(Cpu *c) {
    FN_ENTER(0x7004529b20ull);
L_7004529b20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b30(Cpu *c) {
    FN_ENTER(0x7004529b30ull);
L_7004529b30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b40(Cpu *c) {
    FN_ENTER(0x7004529b40ull);
L_7004529b40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b50(Cpu *c) {
    FN_ENTER(0x7004529b50ull);
L_7004529b50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b60(Cpu *c) {
    FN_ENTER(0x7004529b60ull);
L_7004529b60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b70(Cpu *c) {
    FN_ENTER(0x7004529b70ull);
L_7004529b70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b80(Cpu *c) {
    FN_ENTER(0x7004529b80ull);
L_7004529b80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529b90(Cpu *c) {
    FN_ENTER(0x7004529b90ull);
L_7004529b90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ba0(Cpu *c) {
    FN_ENTER(0x7004529ba0ull);
L_7004529ba0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529bb0(Cpu *c) {
    FN_ENTER(0x7004529bb0ull);
L_7004529bb0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529bc0(Cpu *c) {
    FN_ENTER(0x7004529bc0ull);
L_7004529bc0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529bd0(Cpu *c) {
    FN_ENTER(0x7004529bd0ull);
L_7004529bd0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529be0(Cpu *c) {
    FN_ENTER(0x7004529be0ull);
L_7004529be0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529bf0(Cpu *c) {
    FN_ENTER(0x7004529bf0ull);
L_7004529bf0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c00(Cpu *c) {
    FN_ENTER(0x7004529c00ull);
L_7004529c00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c10(Cpu *c) {
    FN_ENTER(0x7004529c10ull);
L_7004529c10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c20(Cpu *c) {
    FN_ENTER(0x7004529c20ull);
L_7004529c20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c30(Cpu *c) {
    FN_ENTER(0x7004529c30ull);
L_7004529c30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c40(Cpu *c) {
    FN_ENTER(0x7004529c40ull);
L_7004529c40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c50(Cpu *c) {
    FN_ENTER(0x7004529c50ull);
L_7004529c50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c60(Cpu *c) {
    FN_ENTER(0x7004529c60ull);
L_7004529c60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c70(Cpu *c) {
    FN_ENTER(0x7004529c70ull);
L_7004529c70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c80(Cpu *c) {
    FN_ENTER(0x7004529c80ull);
L_7004529c80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529c90(Cpu *c) {
    FN_ENTER(0x7004529c90ull);
L_7004529c90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ca0(Cpu *c) {
    FN_ENTER(0x7004529ca0ull);
L_7004529ca0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529cb0(Cpu *c) {
    FN_ENTER(0x7004529cb0ull);
L_7004529cb0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529cc0(Cpu *c) {
    FN_ENTER(0x7004529cc0ull);
L_7004529cc0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529cd0(Cpu *c) {
    FN_ENTER(0x7004529cd0ull);
L_7004529cd0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ce0(Cpu *c) {
    FN_ENTER(0x7004529ce0ull);
L_7004529ce0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529cf0(Cpu *c) {
    FN_ENTER(0x7004529cf0ull);
L_7004529cf0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d00(Cpu *c) {
    FN_ENTER(0x7004529d00ull);
L_7004529d00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d10(Cpu *c) {
    FN_ENTER(0x7004529d10ull);
L_7004529d10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d20(Cpu *c) {
    FN_ENTER(0x7004529d20ull);
L_7004529d20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d30(Cpu *c) {
    FN_ENTER(0x7004529d30ull);
L_7004529d30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d40(Cpu *c) {
    FN_ENTER(0x7004529d40ull);
L_7004529d40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d50(Cpu *c) {
    FN_ENTER(0x7004529d50ull);
L_7004529d50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d60(Cpu *c) {
    FN_ENTER(0x7004529d60ull);
L_7004529d60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d70(Cpu *c) {
    FN_ENTER(0x7004529d70ull);
L_7004529d70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d80(Cpu *c) {
    FN_ENTER(0x7004529d80ull);
L_7004529d80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529d90(Cpu *c) {
    FN_ENTER(0x7004529d90ull);
L_7004529d90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529da0(Cpu *c) {
    FN_ENTER(0x7004529da0ull);
L_7004529da0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529db0(Cpu *c) {
    FN_ENTER(0x7004529db0ull);
L_7004529db0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529dc0(Cpu *c) {
    FN_ENTER(0x7004529dc0ull);
L_7004529dc0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529dd0(Cpu *c) {
    FN_ENTER(0x7004529dd0ull);
L_7004529dd0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529de0(Cpu *c) {
    FN_ENTER(0x7004529de0ull);
L_7004529de0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529df0(Cpu *c) {
    FN_ENTER(0x7004529df0ull);
L_7004529df0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e00(Cpu *c) {
    FN_ENTER(0x7004529e00ull);
L_7004529e00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e10(Cpu *c) {
    FN_ENTER(0x7004529e10ull);
L_7004529e10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e20(Cpu *c) {
    FN_ENTER(0x7004529e20ull);
L_7004529e20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e30(Cpu *c) {
    FN_ENTER(0x7004529e30ull);
L_7004529e30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e40(Cpu *c) {
    FN_ENTER(0x7004529e40ull);
L_7004529e40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e50(Cpu *c) {
    FN_ENTER(0x7004529e50ull);
L_7004529e50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e60(Cpu *c) {
    FN_ENTER(0x7004529e60ull);
L_7004529e60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e70(Cpu *c) {
    FN_ENTER(0x7004529e70ull);
L_7004529e70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e80(Cpu *c) {
    FN_ENTER(0x7004529e80ull);
L_7004529e80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529e90(Cpu *c) {
    FN_ENTER(0x7004529e90ull);
L_7004529e90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ea0(Cpu *c) {
    FN_ENTER(0x7004529ea0ull);
L_7004529ea0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529eb0(Cpu *c) {
    FN_ENTER(0x7004529eb0ull);
L_7004529eb0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ec0(Cpu *c) {
    FN_ENTER(0x7004529ec0ull);
L_7004529ec0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ed0(Cpu *c) {
    FN_ENTER(0x7004529ed0ull);
L_7004529ed0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ee0(Cpu *c) {
    FN_ENTER(0x7004529ee0ull);
L_7004529ee0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ef0(Cpu *c) {
    FN_ENTER(0x7004529ef0ull);
L_7004529ef0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f00(Cpu *c) {
    FN_ENTER(0x7004529f00ull);
L_7004529f00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f10(Cpu *c) {
    FN_ENTER(0x7004529f10ull);
L_7004529f10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f20(Cpu *c) {
    FN_ENTER(0x7004529f20ull);
L_7004529f20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f30(Cpu *c) {
    FN_ENTER(0x7004529f30ull);
L_7004529f30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f40(Cpu *c) {
    FN_ENTER(0x7004529f40ull);
L_7004529f40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f50(Cpu *c) {
    FN_ENTER(0x7004529f50ull);
L_7004529f50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f60(Cpu *c) {
    FN_ENTER(0x7004529f60ull);
L_7004529f60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f70(Cpu *c) {
    FN_ENTER(0x7004529f70ull);
L_7004529f70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f80(Cpu *c) {
    FN_ENTER(0x7004529f80ull);
L_7004529f80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529f90(Cpu *c) {
    FN_ENTER(0x7004529f90ull);
L_7004529f90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529fa0(Cpu *c) {
    FN_ENTER(0x7004529fa0ull);
L_7004529fa0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529fb0(Cpu *c) {
    FN_ENTER(0x7004529fb0ull);
L_7004529fb0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529fc0(Cpu *c) {
    FN_ENTER(0x7004529fc0ull);
L_7004529fc0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529fd0(Cpu *c) {
    FN_ENTER(0x7004529fd0ull);
L_7004529fd0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529fe0(Cpu *c) {
    FN_ENTER(0x7004529fe0ull);
L_7004529fe0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_7004529ff0(Cpu *c) {
    FN_ENTER(0x7004529ff0ull);
L_7004529ff0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a000(Cpu *c) {
    FN_ENTER(0x700452a000ull);
L_700452a000:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a010(Cpu *c) {
    FN_ENTER(0x700452a010ull);
L_700452a010:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a020(Cpu *c) {
    FN_ENTER(0x700452a020ull);
L_700452a020:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a030(Cpu *c) {
    FN_ENTER(0x700452a030ull);
L_700452a030:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a040(Cpu *c) {
    FN_ENTER(0x700452a040ull);
L_700452a040:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a050(Cpu *c) {
    FN_ENTER(0x700452a050ull);
L_700452a050:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a060(Cpu *c) {
    FN_ENTER(0x700452a060ull);
L_700452a060:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a070(Cpu *c) {
    FN_ENTER(0x700452a070ull);
L_700452a070:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a080(Cpu *c) {
    FN_ENTER(0x700452a080ull);
L_700452a080:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a090(Cpu *c) {
    FN_ENTER(0x700452a090ull);
L_700452a090:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a0a0(Cpu *c) {
    FN_ENTER(0x700452a0a0ull);
L_700452a0a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a0b0(Cpu *c) {
    FN_ENTER(0x700452a0b0ull);
L_700452a0b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a0c0(Cpu *c) {
    FN_ENTER(0x700452a0c0ull);
L_700452a0c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a0d0(Cpu *c) {
    FN_ENTER(0x700452a0d0ull);
L_700452a0d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a0e0(Cpu *c) {
    FN_ENTER(0x700452a0e0ull);
L_700452a0e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a0f0(Cpu *c) {
    FN_ENTER(0x700452a0f0ull);
L_700452a0f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a100(Cpu *c) {
    FN_ENTER(0x700452a100ull);
L_700452a100:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a110(Cpu *c) {
    FN_ENTER(0x700452a110ull);
L_700452a110:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a120(Cpu *c) {
    FN_ENTER(0x700452a120ull);
L_700452a120:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a130(Cpu *c) {
    FN_ENTER(0x700452a130ull);
L_700452a130:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a140(Cpu *c) {
    FN_ENTER(0x700452a140ull);
L_700452a140:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a150(Cpu *c) {
    FN_ENTER(0x700452a150ull);
L_700452a150:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a160(Cpu *c) {
    FN_ENTER(0x700452a160ull);
L_700452a160:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a170(Cpu *c) {
    FN_ENTER(0x700452a170ull);
L_700452a170:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a180(Cpu *c) {
    FN_ENTER(0x700452a180ull);
L_700452a180:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a190(Cpu *c) {
    FN_ENTER(0x700452a190ull);
L_700452a190:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a1a0(Cpu *c) {
    FN_ENTER(0x700452a1a0ull);
L_700452a1a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a1b0(Cpu *c) {
    FN_ENTER(0x700452a1b0ull);
L_700452a1b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a1c0(Cpu *c) {
    FN_ENTER(0x700452a1c0ull);
L_700452a1c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a1d0(Cpu *c) {
    FN_ENTER(0x700452a1d0ull);
L_700452a1d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a1e0(Cpu *c) {
    FN_ENTER(0x700452a1e0ull);
L_700452a1e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a1f0(Cpu *c) {
    FN_ENTER(0x700452a1f0ull);
L_700452a1f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a200(Cpu *c) {
    FN_ENTER(0x700452a200ull);
L_700452a200:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a210(Cpu *c) {
    FN_ENTER(0x700452a210ull);
L_700452a210:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a220(Cpu *c) {
    FN_ENTER(0x700452a220ull);
L_700452a220:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a230(Cpu *c) {
    FN_ENTER(0x700452a230ull);
L_700452a230:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a240(Cpu *c) {
    FN_ENTER(0x700452a240ull);
L_700452a240:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a250(Cpu *c) {
    FN_ENTER(0x700452a250ull);
L_700452a250:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a260(Cpu *c) {
    FN_ENTER(0x700452a260ull);
L_700452a260:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a270(Cpu *c) {
    FN_ENTER(0x700452a270ull);
L_700452a270:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a280(Cpu *c) {
    FN_ENTER(0x700452a280ull);
L_700452a280:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a290(Cpu *c) {
    FN_ENTER(0x700452a290ull);
L_700452a290:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a2a0(Cpu *c) {
    FN_ENTER(0x700452a2a0ull);
L_700452a2a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a2b0(Cpu *c) {
    FN_ENTER(0x700452a2b0ull);
L_700452a2b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a2c0(Cpu *c) {
    FN_ENTER(0x700452a2c0ull);
L_700452a2c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a2d0(Cpu *c) {
    FN_ENTER(0x700452a2d0ull);
L_700452a2d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a2e0(Cpu *c) {
    FN_ENTER(0x700452a2e0ull);
L_700452a2e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a2f0(Cpu *c) {
    FN_ENTER(0x700452a2f0ull);
L_700452a2f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a300(Cpu *c) {
    FN_ENTER(0x700452a300ull);
L_700452a300:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a310(Cpu *c) {
    FN_ENTER(0x700452a310ull);
L_700452a310:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a320(Cpu *c) {
    FN_ENTER(0x700452a320ull);
L_700452a320:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a330(Cpu *c) {
    FN_ENTER(0x700452a330ull);
L_700452a330:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a340(Cpu *c) {
    FN_ENTER(0x700452a340ull);
L_700452a340:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a350(Cpu *c) {
    FN_ENTER(0x700452a350ull);
L_700452a350:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a360(Cpu *c) {
    FN_ENTER(0x700452a360ull);
L_700452a360:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a370(Cpu *c) {
    FN_ENTER(0x700452a370ull);
L_700452a370:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a380(Cpu *c) {
    FN_ENTER(0x700452a380ull);
L_700452a380:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a390(Cpu *c) {
    FN_ENTER(0x700452a390ull);
L_700452a390:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a3a0(Cpu *c) {
    FN_ENTER(0x700452a3a0ull);
L_700452a3a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a3b0(Cpu *c) {
    FN_ENTER(0x700452a3b0ull);
L_700452a3b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a3c0(Cpu *c) {
    FN_ENTER(0x700452a3c0ull);
L_700452a3c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a3d0(Cpu *c) {
    FN_ENTER(0x700452a3d0ull);
L_700452a3d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a3e0(Cpu *c) {
    FN_ENTER(0x700452a3e0ull);
L_700452a3e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a3f0(Cpu *c) {
    FN_ENTER(0x700452a3f0ull);
L_700452a3f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a400(Cpu *c) {
    FN_ENTER(0x700452a400ull);
L_700452a400:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a410(Cpu *c) {
    FN_ENTER(0x700452a410ull);
L_700452a410:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a420(Cpu *c) {
    FN_ENTER(0x700452a420ull);
L_700452a420:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a430(Cpu *c) {
    FN_ENTER(0x700452a430ull);
L_700452a430:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a440(Cpu *c) {
    FN_ENTER(0x700452a440ull);
L_700452a440:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a450(Cpu *c) {
    FN_ENTER(0x700452a450ull);
L_700452a450:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a460(Cpu *c) {
    FN_ENTER(0x700452a460ull);
L_700452a460:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a470(Cpu *c) {
    FN_ENTER(0x700452a470ull);
L_700452a470:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a480(Cpu *c) {
    FN_ENTER(0x700452a480ull);
L_700452a480:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a490(Cpu *c) {
    FN_ENTER(0x700452a490ull);
L_700452a490:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a4a0(Cpu *c) {
    FN_ENTER(0x700452a4a0ull);
L_700452a4a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a4b0(Cpu *c) {
    FN_ENTER(0x700452a4b0ull);
L_700452a4b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a4c0(Cpu *c) {
    FN_ENTER(0x700452a4c0ull);
L_700452a4c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a4d0(Cpu *c) {
    FN_ENTER(0x700452a4d0ull);
L_700452a4d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a4e0(Cpu *c) {
    FN_ENTER(0x700452a4e0ull);
L_700452a4e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a4f0(Cpu *c) {
    FN_ENTER(0x700452a4f0ull);
L_700452a4f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a500(Cpu *c) {
    FN_ENTER(0x700452a500ull);
L_700452a500:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a510(Cpu *c) {
    FN_ENTER(0x700452a510ull);
L_700452a510:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a520(Cpu *c) {
    FN_ENTER(0x700452a520ull);
L_700452a520:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a530(Cpu *c) {
    FN_ENTER(0x700452a530ull);
L_700452a530:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a540(Cpu *c) {
    FN_ENTER(0x700452a540ull);
L_700452a540:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a550(Cpu *c) {
    FN_ENTER(0x700452a550ull);
L_700452a550:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a560(Cpu *c) {
    FN_ENTER(0x700452a560ull);
L_700452a560:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a570(Cpu *c) {
    FN_ENTER(0x700452a570ull);
L_700452a570:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a580(Cpu *c) {
    FN_ENTER(0x700452a580ull);
L_700452a580:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a590(Cpu *c) {
    FN_ENTER(0x700452a590ull);
L_700452a590:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a5a0(Cpu *c) {
    FN_ENTER(0x700452a5a0ull);
L_700452a5a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a5b0(Cpu *c) {
    FN_ENTER(0x700452a5b0ull);
L_700452a5b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a5c0(Cpu *c) {
    FN_ENTER(0x700452a5c0ull);
L_700452a5c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a5d0(Cpu *c) {
    FN_ENTER(0x700452a5d0ull);
L_700452a5d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a5e0(Cpu *c) {
    FN_ENTER(0x700452a5e0ull);
L_700452a5e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a5f0(Cpu *c) {
    FN_ENTER(0x700452a5f0ull);
L_700452a5f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a600(Cpu *c) {
    FN_ENTER(0x700452a600ull);
L_700452a600:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a610(Cpu *c) {
    FN_ENTER(0x700452a610ull);
L_700452a610:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a620(Cpu *c) {
    FN_ENTER(0x700452a620ull);
L_700452a620:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a630(Cpu *c) {
    FN_ENTER(0x700452a630ull);
L_700452a630:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a640(Cpu *c) {
    FN_ENTER(0x700452a640ull);
L_700452a640:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a650(Cpu *c) {
    FN_ENTER(0x700452a650ull);
L_700452a650:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a660(Cpu *c) {
    FN_ENTER(0x700452a660ull);
L_700452a660:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a670(Cpu *c) {
    FN_ENTER(0x700452a670ull);
L_700452a670:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a680(Cpu *c) {
    FN_ENTER(0x700452a680ull);
L_700452a680:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a690(Cpu *c) {
    FN_ENTER(0x700452a690ull);
L_700452a690:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a6a0(Cpu *c) {
    FN_ENTER(0x700452a6a0ull);
L_700452a6a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a6b0(Cpu *c) {
    FN_ENTER(0x700452a6b0ull);
L_700452a6b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a6c0(Cpu *c) {
    FN_ENTER(0x700452a6c0ull);
L_700452a6c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a6d0(Cpu *c) {
    FN_ENTER(0x700452a6d0ull);
L_700452a6d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a6e0(Cpu *c) {
    FN_ENTER(0x700452a6e0ull);
L_700452a6e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a6f0(Cpu *c) {
    FN_ENTER(0x700452a6f0ull);
L_700452a6f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a700(Cpu *c) {
    FN_ENTER(0x700452a700ull);
L_700452a700:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a710(Cpu *c) {
    FN_ENTER(0x700452a710ull);
L_700452a710:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a720(Cpu *c) {
    FN_ENTER(0x700452a720ull);
L_700452a720:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a730(Cpu *c) {
    FN_ENTER(0x700452a730ull);
L_700452a730:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a740(Cpu *c) {
    FN_ENTER(0x700452a740ull);
L_700452a740:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a750(Cpu *c) {
    FN_ENTER(0x700452a750ull);
L_700452a750:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a760(Cpu *c) {
    FN_ENTER(0x700452a760ull);
L_700452a760:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a770(Cpu *c) {
    FN_ENTER(0x700452a770ull);
L_700452a770:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a780(Cpu *c) {
    FN_ENTER(0x700452a780ull);
L_700452a780:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a790(Cpu *c) {
    FN_ENTER(0x700452a790ull);
L_700452a790:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a7a0(Cpu *c) {
    FN_ENTER(0x700452a7a0ull);
L_700452a7a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a7b0(Cpu *c) {
    FN_ENTER(0x700452a7b0ull);
L_700452a7b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a7c0(Cpu *c) {
    FN_ENTER(0x700452a7c0ull);
L_700452a7c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a7d0(Cpu *c) {
    FN_ENTER(0x700452a7d0ull);
L_700452a7d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a7e0(Cpu *c) {
    FN_ENTER(0x700452a7e0ull);
L_700452a7e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a7f0(Cpu *c) {
    FN_ENTER(0x700452a7f0ull);
L_700452a7f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a800(Cpu *c) {
    FN_ENTER(0x700452a800ull);
L_700452a800:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a810(Cpu *c) {
    FN_ENTER(0x700452a810ull);
L_700452a810:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a820(Cpu *c) {
    FN_ENTER(0x700452a820ull);
L_700452a820:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a830(Cpu *c) {
    FN_ENTER(0x700452a830ull);
L_700452a830:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a840(Cpu *c) {
    FN_ENTER(0x700452a840ull);
L_700452a840:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a850(Cpu *c) {
    FN_ENTER(0x700452a850ull);
L_700452a850:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a860(Cpu *c) {
    FN_ENTER(0x700452a860ull);
L_700452a860:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a870(Cpu *c) {
    FN_ENTER(0x700452a870ull);
L_700452a870:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a880(Cpu *c) {
    FN_ENTER(0x700452a880ull);
L_700452a880:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a890(Cpu *c) {
    FN_ENTER(0x700452a890ull);
L_700452a890:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a8a0(Cpu *c) {
    FN_ENTER(0x700452a8a0ull);
L_700452a8a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a8b0(Cpu *c) {
    FN_ENTER(0x700452a8b0ull);
L_700452a8b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a8c0(Cpu *c) {
    FN_ENTER(0x700452a8c0ull);
L_700452a8c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a8d0(Cpu *c) {
    FN_ENTER(0x700452a8d0ull);
L_700452a8d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a8e0(Cpu *c) {
    FN_ENTER(0x700452a8e0ull);
L_700452a8e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a8f0(Cpu *c) {
    FN_ENTER(0x700452a8f0ull);
L_700452a8f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a900(Cpu *c) {
    FN_ENTER(0x700452a900ull);
L_700452a900:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a910(Cpu *c) {
    FN_ENTER(0x700452a910ull);
L_700452a910:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a920(Cpu *c) {
    FN_ENTER(0x700452a920ull);
L_700452a920:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a930(Cpu *c) {
    FN_ENTER(0x700452a930ull);
L_700452a930:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a940(Cpu *c) {
    FN_ENTER(0x700452a940ull);
L_700452a940:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a950(Cpu *c) {
    FN_ENTER(0x700452a950ull);
L_700452a950:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a960(Cpu *c) {
    FN_ENTER(0x700452a960ull);
L_700452a960:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a970(Cpu *c) {
    FN_ENTER(0x700452a970ull);
L_700452a970:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a980(Cpu *c) {
    FN_ENTER(0x700452a980ull);
L_700452a980:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a990(Cpu *c) {
    FN_ENTER(0x700452a990ull);
L_700452a990:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a9a0(Cpu *c) {
    FN_ENTER(0x700452a9a0ull);
L_700452a9a0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a9b0(Cpu *c) {
    FN_ENTER(0x700452a9b0ull);
L_700452a9b0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a9c0(Cpu *c) {
    FN_ENTER(0x700452a9c0ull);
L_700452a9c0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a9d0(Cpu *c) {
    FN_ENTER(0x700452a9d0ull);
L_700452a9d0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a9e0(Cpu *c) {
    FN_ENTER(0x700452a9e0ull);
L_700452a9e0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452a9f0(Cpu *c) {
    FN_ENTER(0x700452a9f0ull);
L_700452a9f0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa00(Cpu *c) {
    FN_ENTER(0x700452aa00ull);
L_700452aa00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa10(Cpu *c) {
    FN_ENTER(0x700452aa10ull);
L_700452aa10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa20(Cpu *c) {
    FN_ENTER(0x700452aa20ull);
L_700452aa20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa30(Cpu *c) {
    FN_ENTER(0x700452aa30ull);
L_700452aa30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa40(Cpu *c) {
    FN_ENTER(0x700452aa40ull);
L_700452aa40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa50(Cpu *c) {
    FN_ENTER(0x700452aa50ull);
L_700452aa50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa60(Cpu *c) {
    FN_ENTER(0x700452aa60ull);
L_700452aa60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa70(Cpu *c) {
    FN_ENTER(0x700452aa70ull);
L_700452aa70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa80(Cpu *c) {
    FN_ENTER(0x700452aa80ull);
L_700452aa80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aa90(Cpu *c) {
    FN_ENTER(0x700452aa90ull);
L_700452aa90:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aaa0(Cpu *c) {
    FN_ENTER(0x700452aaa0ull);
L_700452aaa0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aab0(Cpu *c) {
    FN_ENTER(0x700452aab0ull);
L_700452aab0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aac0(Cpu *c) {
    FN_ENTER(0x700452aac0ull);
L_700452aac0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aad0(Cpu *c) {
    FN_ENTER(0x700452aad0ull);
L_700452aad0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aae0(Cpu *c) {
    FN_ENTER(0x700452aae0ull);
L_700452aae0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aaf0(Cpu *c) {
    FN_ENTER(0x700452aaf0ull);
L_700452aaf0:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab00(Cpu *c) {
    FN_ENTER(0x700452ab00ull);
L_700452ab00:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab10(Cpu *c) {
    FN_ENTER(0x700452ab10ull);
L_700452ab10:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab20(Cpu *c) {
    FN_ENTER(0x700452ab20ull);
L_700452ab20:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab30(Cpu *c) {
    FN_ENTER(0x700452ab30ull);
L_700452ab30:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab40(Cpu *c) {
    FN_ENTER(0x700452ab40ull);
L_700452ab40:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab50(Cpu *c) {
    FN_ENTER(0x700452ab50ull);
L_700452ab50:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab60(Cpu *c) {
    FN_ENTER(0x700452ab60ull);
L_700452ab60:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab70(Cpu *c) {
    FN_ENTER(0x700452ab70ull);
L_700452ab70:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab80(Cpu *c) {
    FN_ENTER(0x700452ab80ull);
L_700452ab80:;
    c->x[16] = (uint64_t)(0x7004c2d000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ab90(Cpu *c) {
    FN_ENTER(0x700452ab90ull);
L_700452ab90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aba0(Cpu *c) {
    FN_ENTER(0x700452aba0ull);
L_700452aba0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452abb0(Cpu *c) {
    FN_ENTER(0x700452abb0ull);
L_700452abb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452abc0(Cpu *c) {
    FN_ENTER(0x700452abc0ull);
L_700452abc0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452abd0(Cpu *c) {
    FN_ENTER(0x700452abd0ull);
L_700452abd0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452abe0(Cpu *c) {
    FN_ENTER(0x700452abe0ull);
L_700452abe0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452abf0(Cpu *c) {
    FN_ENTER(0x700452abf0ull);
L_700452abf0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac00(Cpu *c) {
    FN_ENTER(0x700452ac00ull);
L_700452ac00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac10(Cpu *c) {
    FN_ENTER(0x700452ac10ull);
L_700452ac10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac20(Cpu *c) {
    FN_ENTER(0x700452ac20ull);
L_700452ac20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac30(Cpu *c) {
    FN_ENTER(0x700452ac30ull);
L_700452ac30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac40(Cpu *c) {
    FN_ENTER(0x700452ac40ull);
L_700452ac40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac50(Cpu *c) {
    FN_ENTER(0x700452ac50ull);
L_700452ac50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac60(Cpu *c) {
    FN_ENTER(0x700452ac60ull);
L_700452ac60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac70(Cpu *c) {
    FN_ENTER(0x700452ac70ull);
L_700452ac70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac80(Cpu *c) {
    FN_ENTER(0x700452ac80ull);
L_700452ac80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ac90(Cpu *c) {
    FN_ENTER(0x700452ac90ull);
L_700452ac90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aca0(Cpu *c) {
    FN_ENTER(0x700452aca0ull);
L_700452aca0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452acb0(Cpu *c) {
    FN_ENTER(0x700452acb0ull);
L_700452acb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452acc0(Cpu *c) {
    FN_ENTER(0x700452acc0ull);
L_700452acc0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452acd0(Cpu *c) {
    FN_ENTER(0x700452acd0ull);
L_700452acd0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ace0(Cpu *c) {
    FN_ENTER(0x700452ace0ull);
L_700452ace0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452acf0(Cpu *c) {
    FN_ENTER(0x700452acf0ull);
L_700452acf0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad00(Cpu *c) {
    FN_ENTER(0x700452ad00ull);
L_700452ad00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad10(Cpu *c) {
    FN_ENTER(0x700452ad10ull);
L_700452ad10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad20(Cpu *c) {
    FN_ENTER(0x700452ad20ull);
L_700452ad20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad30(Cpu *c) {
    FN_ENTER(0x700452ad30ull);
L_700452ad30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad40(Cpu *c) {
    FN_ENTER(0x700452ad40ull);
L_700452ad40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad50(Cpu *c) {
    FN_ENTER(0x700452ad50ull);
L_700452ad50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad60(Cpu *c) {
    FN_ENTER(0x700452ad60ull);
L_700452ad60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad70(Cpu *c) {
    FN_ENTER(0x700452ad70ull);
L_700452ad70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad80(Cpu *c) {
    FN_ENTER(0x700452ad80ull);
L_700452ad80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ad90(Cpu *c) {
    FN_ENTER(0x700452ad90ull);
L_700452ad90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x100ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x100ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ada0(Cpu *c) {
    FN_ENTER(0x700452ada0ull);
L_700452ada0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x108ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x108ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452adb0(Cpu *c) {
    FN_ENTER(0x700452adb0ull);
L_700452adb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x110ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x110ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452adc0(Cpu *c) {
    FN_ENTER(0x700452adc0ull);
L_700452adc0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x118ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x118ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452add0(Cpu *c) {
    FN_ENTER(0x700452add0ull);
L_700452add0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x120ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x120ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ade0(Cpu *c) {
    FN_ENTER(0x700452ade0ull);
L_700452ade0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x128ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x128ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452adf0(Cpu *c) {
    FN_ENTER(0x700452adf0ull);
L_700452adf0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x130ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x130ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae00(Cpu *c) {
    FN_ENTER(0x700452ae00ull);
L_700452ae00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x138ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x138ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae10(Cpu *c) {
    FN_ENTER(0x700452ae10ull);
L_700452ae10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x140ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x140ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae20(Cpu *c) {
    FN_ENTER(0x700452ae20ull);
L_700452ae20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x148ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x148ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae30(Cpu *c) {
    FN_ENTER(0x700452ae30ull);
L_700452ae30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x150ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x150ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae40(Cpu *c) {
    FN_ENTER(0x700452ae40ull);
L_700452ae40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x158ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x158ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae50(Cpu *c) {
    FN_ENTER(0x700452ae50ull);
L_700452ae50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x160ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x160ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae60(Cpu *c) {
    FN_ENTER(0x700452ae60ull);
L_700452ae60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x168ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x168ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae70(Cpu *c) {
    FN_ENTER(0x700452ae70ull);
L_700452ae70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x170ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x170ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae80(Cpu *c) {
    FN_ENTER(0x700452ae80ull);
L_700452ae80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x178ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x178ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ae90(Cpu *c) {
    FN_ENTER(0x700452ae90ull);
L_700452ae90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x180ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x180ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aea0(Cpu *c) {
    FN_ENTER(0x700452aea0ull);
L_700452aea0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x188ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x188ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aeb0(Cpu *c) {
    FN_ENTER(0x700452aeb0ull);
L_700452aeb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x190ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x190ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aec0(Cpu *c) {
    FN_ENTER(0x700452aec0ull);
L_700452aec0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x198ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x198ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aed0(Cpu *c) {
    FN_ENTER(0x700452aed0ull);
L_700452aed0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aee0(Cpu *c) {
    FN_ENTER(0x700452aee0ull);
L_700452aee0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aef0(Cpu *c) {
    FN_ENTER(0x700452aef0ull);
L_700452aef0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af00(Cpu *c) {
    FN_ENTER(0x700452af00ull);
L_700452af00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af10(Cpu *c) {
    FN_ENTER(0x700452af10ull);
L_700452af10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af20(Cpu *c) {
    FN_ENTER(0x700452af20ull);
L_700452af20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af30(Cpu *c) {
    FN_ENTER(0x700452af30ull);
L_700452af30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af40(Cpu *c) {
    FN_ENTER(0x700452af40ull);
L_700452af40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af50(Cpu *c) {
    FN_ENTER(0x700452af50ull);
L_700452af50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af60(Cpu *c) {
    FN_ENTER(0x700452af60ull);
L_700452af60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af70(Cpu *c) {
    FN_ENTER(0x700452af70ull);
L_700452af70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af80(Cpu *c) {
    FN_ENTER(0x700452af80ull);
L_700452af80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x1f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452af90(Cpu *c) {
    FN_ENTER(0x700452af90ull);
L_700452af90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x200ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x200ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452afa0(Cpu *c) {
    FN_ENTER(0x700452afa0ull);
L_700452afa0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x208ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x208ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452afb0(Cpu *c) {
    FN_ENTER(0x700452afb0ull);
L_700452afb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x210ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x210ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452afc0(Cpu *c) {
    FN_ENTER(0x700452afc0ull);
L_700452afc0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x218ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x218ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452afd0(Cpu *c) {
    FN_ENTER(0x700452afd0ull);
L_700452afd0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x220ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x220ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452afe0(Cpu *c) {
    FN_ENTER(0x700452afe0ull);
L_700452afe0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x228ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x228ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452aff0(Cpu *c) {
    FN_ENTER(0x700452aff0ull);
L_700452aff0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x230ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x230ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b000(Cpu *c) {
    FN_ENTER(0x700452b000ull);
L_700452b000:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x238ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x238ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b010(Cpu *c) {
    FN_ENTER(0x700452b010ull);
L_700452b010:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x240ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x240ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b020(Cpu *c) {
    FN_ENTER(0x700452b020ull);
L_700452b020:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x248ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x248ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b030(Cpu *c) {
    FN_ENTER(0x700452b030ull);
L_700452b030:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x250ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x250ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b040(Cpu *c) {
    FN_ENTER(0x700452b040ull);
L_700452b040:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x258ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x258ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b050(Cpu *c) {
    FN_ENTER(0x700452b050ull);
L_700452b050:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x260ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x260ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b060(Cpu *c) {
    FN_ENTER(0x700452b060ull);
L_700452b060:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x268ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x268ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b070(Cpu *c) {
    FN_ENTER(0x700452b070ull);
L_700452b070:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x270ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x270ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b080(Cpu *c) {
    FN_ENTER(0x700452b080ull);
L_700452b080:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x278ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x278ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b090(Cpu *c) {
    FN_ENTER(0x700452b090ull);
L_700452b090:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x280ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x280ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b0a0(Cpu *c) {
    FN_ENTER(0x700452b0a0ull);
L_700452b0a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x288ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x288ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b0b0(Cpu *c) {
    FN_ENTER(0x700452b0b0ull);
L_700452b0b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x290ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x290ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b0c0(Cpu *c) {
    FN_ENTER(0x700452b0c0ull);
L_700452b0c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x298ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x298ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b0d0(Cpu *c) {
    FN_ENTER(0x700452b0d0ull);
L_700452b0d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b0e0(Cpu *c) {
    FN_ENTER(0x700452b0e0ull);
L_700452b0e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b0f0(Cpu *c) {
    FN_ENTER(0x700452b0f0ull);
L_700452b0f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b100(Cpu *c) {
    FN_ENTER(0x700452b100ull);
L_700452b100:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b110(Cpu *c) {
    FN_ENTER(0x700452b110ull);
L_700452b110:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b120(Cpu *c) {
    FN_ENTER(0x700452b120ull);
L_700452b120:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b130(Cpu *c) {
    FN_ENTER(0x700452b130ull);
L_700452b130:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b140(Cpu *c) {
    FN_ENTER(0x700452b140ull);
L_700452b140:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b150(Cpu *c) {
    FN_ENTER(0x700452b150ull);
L_700452b150:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b160(Cpu *c) {
    FN_ENTER(0x700452b160ull);
L_700452b160:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b170(Cpu *c) {
    FN_ENTER(0x700452b170ull);
L_700452b170:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b180(Cpu *c) {
    FN_ENTER(0x700452b180ull);
L_700452b180:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x2f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b190(Cpu *c) {
    FN_ENTER(0x700452b190ull);
L_700452b190:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x300ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x300ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b1a0(Cpu *c) {
    FN_ENTER(0x700452b1a0ull);
L_700452b1a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x308ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x308ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b1b0(Cpu *c) {
    FN_ENTER(0x700452b1b0ull);
L_700452b1b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x310ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x310ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b1c0(Cpu *c) {
    FN_ENTER(0x700452b1c0ull);
L_700452b1c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x318ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x318ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b1d0(Cpu *c) {
    FN_ENTER(0x700452b1d0ull);
L_700452b1d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x320ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x320ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b1e0(Cpu *c) {
    FN_ENTER(0x700452b1e0ull);
L_700452b1e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x328ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x328ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b1f0(Cpu *c) {
    FN_ENTER(0x700452b1f0ull);
L_700452b1f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x330ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x330ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b200(Cpu *c) {
    FN_ENTER(0x700452b200ull);
L_700452b200:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x338ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x338ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b210(Cpu *c) {
    FN_ENTER(0x700452b210ull);
L_700452b210:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x340ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x340ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b220(Cpu *c) {
    FN_ENTER(0x700452b220ull);
L_700452b220:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x348ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x348ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b230(Cpu *c) {
    FN_ENTER(0x700452b230ull);
L_700452b230:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x350ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x350ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b240(Cpu *c) {
    FN_ENTER(0x700452b240ull);
L_700452b240:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x358ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x358ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b250(Cpu *c) {
    FN_ENTER(0x700452b250ull);
L_700452b250:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x360ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x360ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b260(Cpu *c) {
    FN_ENTER(0x700452b260ull);
L_700452b260:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x368ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x368ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b270(Cpu *c) {
    FN_ENTER(0x700452b270ull);
L_700452b270:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x370ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x370ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b280(Cpu *c) {
    FN_ENTER(0x700452b280ull);
L_700452b280:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x378ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x378ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b290(Cpu *c) {
    FN_ENTER(0x700452b290ull);
L_700452b290:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x380ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x380ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b2a0(Cpu *c) {
    FN_ENTER(0x700452b2a0ull);
L_700452b2a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x388ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x388ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b2b0(Cpu *c) {
    FN_ENTER(0x700452b2b0ull);
L_700452b2b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x390ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x390ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b2c0(Cpu *c) {
    FN_ENTER(0x700452b2c0ull);
L_700452b2c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x398ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x398ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b2d0(Cpu *c) {
    FN_ENTER(0x700452b2d0ull);
L_700452b2d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b2e0(Cpu *c) {
    FN_ENTER(0x700452b2e0ull);
L_700452b2e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b2f0(Cpu *c) {
    FN_ENTER(0x700452b2f0ull);
L_700452b2f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b300(Cpu *c) {
    FN_ENTER(0x700452b300ull);
L_700452b300:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b310(Cpu *c) {
    FN_ENTER(0x700452b310ull);
L_700452b310:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b320(Cpu *c) {
    FN_ENTER(0x700452b320ull);
L_700452b320:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b330(Cpu *c) {
    FN_ENTER(0x700452b330ull);
L_700452b330:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b340(Cpu *c) {
    FN_ENTER(0x700452b340ull);
L_700452b340:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b350(Cpu *c) {
    FN_ENTER(0x700452b350ull);
L_700452b350:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b360(Cpu *c) {
    FN_ENTER(0x700452b360ull);
L_700452b360:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b370(Cpu *c) {
    FN_ENTER(0x700452b370ull);
L_700452b370:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b380(Cpu *c) {
    FN_ENTER(0x700452b380ull);
L_700452b380:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x3f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x3f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b390(Cpu *c) {
    FN_ENTER(0x700452b390ull);
L_700452b390:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x400ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x400ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b3a0(Cpu *c) {
    FN_ENTER(0x700452b3a0ull);
L_700452b3a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x408ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x408ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b3b0(Cpu *c) {
    FN_ENTER(0x700452b3b0ull);
L_700452b3b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x410ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x410ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b3c0(Cpu *c) {
    FN_ENTER(0x700452b3c0ull);
L_700452b3c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x418ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x418ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b3d0(Cpu *c) {
    FN_ENTER(0x700452b3d0ull);
L_700452b3d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x420ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x420ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b3e0(Cpu *c) {
    FN_ENTER(0x700452b3e0ull);
L_700452b3e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x428ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x428ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b3f0(Cpu *c) {
    FN_ENTER(0x700452b3f0ull);
L_700452b3f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x430ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x430ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b400(Cpu *c) {
    FN_ENTER(0x700452b400ull);
L_700452b400:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x438ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x438ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b410(Cpu *c) {
    FN_ENTER(0x700452b410ull);
L_700452b410:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x440ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x440ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b420(Cpu *c) {
    FN_ENTER(0x700452b420ull);
L_700452b420:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x448ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x448ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b430(Cpu *c) {
    FN_ENTER(0x700452b430ull);
L_700452b430:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x450ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x450ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b440(Cpu *c) {
    FN_ENTER(0x700452b440ull);
L_700452b440:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x458ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x458ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b450(Cpu *c) {
    FN_ENTER(0x700452b450ull);
L_700452b450:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x460ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x460ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b460(Cpu *c) {
    FN_ENTER(0x700452b460ull);
L_700452b460:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x468ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x468ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b470(Cpu *c) {
    FN_ENTER(0x700452b470ull);
L_700452b470:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x470ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x470ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b480(Cpu *c) {
    FN_ENTER(0x700452b480ull);
L_700452b480:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x478ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x478ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b490(Cpu *c) {
    FN_ENTER(0x700452b490ull);
L_700452b490:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x480ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x480ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b4a0(Cpu *c) {
    FN_ENTER(0x700452b4a0ull);
L_700452b4a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x488ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x488ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b4b0(Cpu *c) {
    FN_ENTER(0x700452b4b0ull);
L_700452b4b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x490ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x490ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b4c0(Cpu *c) {
    FN_ENTER(0x700452b4c0ull);
L_700452b4c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x498ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x498ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b4d0(Cpu *c) {
    FN_ENTER(0x700452b4d0ull);
L_700452b4d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b4e0(Cpu *c) {
    FN_ENTER(0x700452b4e0ull);
L_700452b4e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b4f0(Cpu *c) {
    FN_ENTER(0x700452b4f0ull);
L_700452b4f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b500(Cpu *c) {
    FN_ENTER(0x700452b500ull);
L_700452b500:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b510(Cpu *c) {
    FN_ENTER(0x700452b510ull);
L_700452b510:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b520(Cpu *c) {
    FN_ENTER(0x700452b520ull);
L_700452b520:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b530(Cpu *c) {
    FN_ENTER(0x700452b530ull);
L_700452b530:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b540(Cpu *c) {
    FN_ENTER(0x700452b540ull);
L_700452b540:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b550(Cpu *c) {
    FN_ENTER(0x700452b550ull);
L_700452b550:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b560(Cpu *c) {
    FN_ENTER(0x700452b560ull);
L_700452b560:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b570(Cpu *c) {
    FN_ENTER(0x700452b570ull);
L_700452b570:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b580(Cpu *c) {
    FN_ENTER(0x700452b580ull);
L_700452b580:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x4f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x4f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b590(Cpu *c) {
    FN_ENTER(0x700452b590ull);
L_700452b590:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x500ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x500ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b5a0(Cpu *c) {
    FN_ENTER(0x700452b5a0ull);
L_700452b5a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x508ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x508ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b5b0(Cpu *c) {
    FN_ENTER(0x700452b5b0ull);
L_700452b5b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x510ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x510ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b5c0(Cpu *c) {
    FN_ENTER(0x700452b5c0ull);
L_700452b5c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x518ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x518ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b5d0(Cpu *c) {
    FN_ENTER(0x700452b5d0ull);
L_700452b5d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x520ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x520ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b5e0(Cpu *c) {
    FN_ENTER(0x700452b5e0ull);
L_700452b5e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x528ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x528ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b5f0(Cpu *c) {
    FN_ENTER(0x700452b5f0ull);
L_700452b5f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x530ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x530ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b600(Cpu *c) {
    FN_ENTER(0x700452b600ull);
L_700452b600:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x538ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x538ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b610(Cpu *c) {
    FN_ENTER(0x700452b610ull);
L_700452b610:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x540ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x540ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b620(Cpu *c) {
    FN_ENTER(0x700452b620ull);
L_700452b620:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x548ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x548ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b630(Cpu *c) {
    FN_ENTER(0x700452b630ull);
L_700452b630:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x550ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x550ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b640(Cpu *c) {
    FN_ENTER(0x700452b640ull);
L_700452b640:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x558ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x558ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b650(Cpu *c) {
    FN_ENTER(0x700452b650ull);
L_700452b650:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x560ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x560ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b660(Cpu *c) {
    FN_ENTER(0x700452b660ull);
L_700452b660:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x568ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x568ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b670(Cpu *c) {
    FN_ENTER(0x700452b670ull);
L_700452b670:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x570ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x570ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b680(Cpu *c) {
    FN_ENTER(0x700452b680ull);
L_700452b680:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x578ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x578ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b690(Cpu *c) {
    FN_ENTER(0x700452b690ull);
L_700452b690:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x580ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x580ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b6a0(Cpu *c) {
    FN_ENTER(0x700452b6a0ull);
L_700452b6a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x588ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x588ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b6b0(Cpu *c) {
    FN_ENTER(0x700452b6b0ull);
L_700452b6b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x590ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x590ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b6c0(Cpu *c) {
    FN_ENTER(0x700452b6c0ull);
L_700452b6c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x598ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x598ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b6d0(Cpu *c) {
    FN_ENTER(0x700452b6d0ull);
L_700452b6d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b6e0(Cpu *c) {
    FN_ENTER(0x700452b6e0ull);
L_700452b6e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b6f0(Cpu *c) {
    FN_ENTER(0x700452b6f0ull);
L_700452b6f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b700(Cpu *c) {
    FN_ENTER(0x700452b700ull);
L_700452b700:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b710(Cpu *c) {
    FN_ENTER(0x700452b710ull);
L_700452b710:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b720(Cpu *c) {
    FN_ENTER(0x700452b720ull);
L_700452b720:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b730(Cpu *c) {
    FN_ENTER(0x700452b730ull);
L_700452b730:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b740(Cpu *c) {
    FN_ENTER(0x700452b740ull);
L_700452b740:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b750(Cpu *c) {
    FN_ENTER(0x700452b750ull);
L_700452b750:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b760(Cpu *c) {
    FN_ENTER(0x700452b760ull);
L_700452b760:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b770(Cpu *c) {
    FN_ENTER(0x700452b770ull);
L_700452b770:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b780(Cpu *c) {
    FN_ENTER(0x700452b780ull);
L_700452b780:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x5f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x5f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b790(Cpu *c) {
    FN_ENTER(0x700452b790ull);
L_700452b790:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x600ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x600ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b7a0(Cpu *c) {
    FN_ENTER(0x700452b7a0ull);
L_700452b7a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x608ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x608ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b7b0(Cpu *c) {
    FN_ENTER(0x700452b7b0ull);
L_700452b7b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x610ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x610ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b7c0(Cpu *c) {
    FN_ENTER(0x700452b7c0ull);
L_700452b7c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x618ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x618ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b7d0(Cpu *c) {
    FN_ENTER(0x700452b7d0ull);
L_700452b7d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x620ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x620ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b7e0(Cpu *c) {
    FN_ENTER(0x700452b7e0ull);
L_700452b7e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x628ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x628ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b7f0(Cpu *c) {
    FN_ENTER(0x700452b7f0ull);
L_700452b7f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x630ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x630ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b800(Cpu *c) {
    FN_ENTER(0x700452b800ull);
L_700452b800:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x638ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x638ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b810(Cpu *c) {
    FN_ENTER(0x700452b810ull);
L_700452b810:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x640ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x640ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b820(Cpu *c) {
    FN_ENTER(0x700452b820ull);
L_700452b820:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x648ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x648ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b830(Cpu *c) {
    FN_ENTER(0x700452b830ull);
L_700452b830:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x650ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x650ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b840(Cpu *c) {
    FN_ENTER(0x700452b840ull);
L_700452b840:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x658ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x658ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b850(Cpu *c) {
    FN_ENTER(0x700452b850ull);
L_700452b850:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x660ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x660ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b860(Cpu *c) {
    FN_ENTER(0x700452b860ull);
L_700452b860:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x668ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x668ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b870(Cpu *c) {
    FN_ENTER(0x700452b870ull);
L_700452b870:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x670ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x670ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b880(Cpu *c) {
    FN_ENTER(0x700452b880ull);
L_700452b880:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x678ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x678ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b890(Cpu *c) {
    FN_ENTER(0x700452b890ull);
L_700452b890:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x680ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x680ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b8a0(Cpu *c) {
    FN_ENTER(0x700452b8a0ull);
L_700452b8a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x688ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x688ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b8b0(Cpu *c) {
    FN_ENTER(0x700452b8b0ull);
L_700452b8b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x690ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x690ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b8c0(Cpu *c) {
    FN_ENTER(0x700452b8c0ull);
L_700452b8c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x698ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x698ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b8d0(Cpu *c) {
    FN_ENTER(0x700452b8d0ull);
L_700452b8d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b8e0(Cpu *c) {
    FN_ENTER(0x700452b8e0ull);
L_700452b8e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b8f0(Cpu *c) {
    FN_ENTER(0x700452b8f0ull);
L_700452b8f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b900(Cpu *c) {
    FN_ENTER(0x700452b900ull);
L_700452b900:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b910(Cpu *c) {
    FN_ENTER(0x700452b910ull);
L_700452b910:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b920(Cpu *c) {
    FN_ENTER(0x700452b920ull);
L_700452b920:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b930(Cpu *c) {
    FN_ENTER(0x700452b930ull);
L_700452b930:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b940(Cpu *c) {
    FN_ENTER(0x700452b940ull);
L_700452b940:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b950(Cpu *c) {
    FN_ENTER(0x700452b950ull);
L_700452b950:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b960(Cpu *c) {
    FN_ENTER(0x700452b960ull);
L_700452b960:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b970(Cpu *c) {
    FN_ENTER(0x700452b970ull);
L_700452b970:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b980(Cpu *c) {
    FN_ENTER(0x700452b980ull);
L_700452b980:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x6f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x6f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b990(Cpu *c) {
    FN_ENTER(0x700452b990ull);
L_700452b990:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x700ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x700ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b9a0(Cpu *c) {
    FN_ENTER(0x700452b9a0ull);
L_700452b9a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x708ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x708ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b9b0(Cpu *c) {
    FN_ENTER(0x700452b9b0ull);
L_700452b9b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x710ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x710ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b9c0(Cpu *c) {
    FN_ENTER(0x700452b9c0ull);
L_700452b9c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x718ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x718ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b9d0(Cpu *c) {
    FN_ENTER(0x700452b9d0ull);
L_700452b9d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x720ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x720ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b9e0(Cpu *c) {
    FN_ENTER(0x700452b9e0ull);
L_700452b9e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x728ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x728ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452b9f0(Cpu *c) {
    FN_ENTER(0x700452b9f0ull);
L_700452b9f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x730ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x730ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba00(Cpu *c) {
    FN_ENTER(0x700452ba00ull);
L_700452ba00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x738ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x738ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba10(Cpu *c) {
    FN_ENTER(0x700452ba10ull);
L_700452ba10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x740ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x740ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba20(Cpu *c) {
    FN_ENTER(0x700452ba20ull);
L_700452ba20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x748ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x748ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba30(Cpu *c) {
    FN_ENTER(0x700452ba30ull);
L_700452ba30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x750ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x750ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba40(Cpu *c) {
    FN_ENTER(0x700452ba40ull);
L_700452ba40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x758ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x758ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba50(Cpu *c) {
    FN_ENTER(0x700452ba50ull);
L_700452ba50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x760ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x760ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba60(Cpu *c) {
    FN_ENTER(0x700452ba60ull);
L_700452ba60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x768ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x768ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba70(Cpu *c) {
    FN_ENTER(0x700452ba70ull);
L_700452ba70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x770ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x770ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba80(Cpu *c) {
    FN_ENTER(0x700452ba80ull);
L_700452ba80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x778ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x778ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ba90(Cpu *c) {
    FN_ENTER(0x700452ba90ull);
L_700452ba90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x780ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x780ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452baa0(Cpu *c) {
    FN_ENTER(0x700452baa0ull);
L_700452baa0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x788ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x788ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bab0(Cpu *c) {
    FN_ENTER(0x700452bab0ull);
L_700452bab0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x790ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x790ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bac0(Cpu *c) {
    FN_ENTER(0x700452bac0ull);
L_700452bac0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x798ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x798ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bad0(Cpu *c) {
    FN_ENTER(0x700452bad0ull);
L_700452bad0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bae0(Cpu *c) {
    FN_ENTER(0x700452bae0ull);
L_700452bae0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452baf0(Cpu *c) {
    FN_ENTER(0x700452baf0ull);
L_700452baf0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb00(Cpu *c) {
    FN_ENTER(0x700452bb00ull);
L_700452bb00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb10(Cpu *c) {
    FN_ENTER(0x700452bb10ull);
L_700452bb10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb20(Cpu *c) {
    FN_ENTER(0x700452bb20ull);
L_700452bb20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb30(Cpu *c) {
    FN_ENTER(0x700452bb30ull);
L_700452bb30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb40(Cpu *c) {
    FN_ENTER(0x700452bb40ull);
L_700452bb40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb50(Cpu *c) {
    FN_ENTER(0x700452bb50ull);
L_700452bb50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb60(Cpu *c) {
    FN_ENTER(0x700452bb60ull);
L_700452bb60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb70(Cpu *c) {
    FN_ENTER(0x700452bb70ull);
L_700452bb70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb80(Cpu *c) {
    FN_ENTER(0x700452bb80ull);
L_700452bb80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x7f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x7f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bb90(Cpu *c) {
    FN_ENTER(0x700452bb90ull);
L_700452bb90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x800ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x800ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bba0(Cpu *c) {
    FN_ENTER(0x700452bba0ull);
L_700452bba0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x808ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x808ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bbb0(Cpu *c) {
    FN_ENTER(0x700452bbb0ull);
L_700452bbb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x810ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x810ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bbc0(Cpu *c) {
    FN_ENTER(0x700452bbc0ull);
L_700452bbc0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x818ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x818ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bbd0(Cpu *c) {
    FN_ENTER(0x700452bbd0ull);
L_700452bbd0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x820ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x820ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bbe0(Cpu *c) {
    FN_ENTER(0x700452bbe0ull);
L_700452bbe0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x828ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x828ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bbf0(Cpu *c) {
    FN_ENTER(0x700452bbf0ull);
L_700452bbf0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x830ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x830ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc00(Cpu *c) {
    FN_ENTER(0x700452bc00ull);
L_700452bc00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x838ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x838ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc10(Cpu *c) {
    FN_ENTER(0x700452bc10ull);
L_700452bc10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x840ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x840ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc20(Cpu *c) {
    FN_ENTER(0x700452bc20ull);
L_700452bc20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x848ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x848ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc30(Cpu *c) {
    FN_ENTER(0x700452bc30ull);
L_700452bc30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x850ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x850ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc40(Cpu *c) {
    FN_ENTER(0x700452bc40ull);
L_700452bc40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x858ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x858ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc50(Cpu *c) {
    FN_ENTER(0x700452bc50ull);
L_700452bc50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x860ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x860ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc60(Cpu *c) {
    FN_ENTER(0x700452bc60ull);
L_700452bc60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x868ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x868ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc70(Cpu *c) {
    FN_ENTER(0x700452bc70ull);
L_700452bc70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x870ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x870ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc80(Cpu *c) {
    FN_ENTER(0x700452bc80ull);
L_700452bc80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x878ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x878ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bc90(Cpu *c) {
    FN_ENTER(0x700452bc90ull);
L_700452bc90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x880ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x880ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bca0(Cpu *c) {
    FN_ENTER(0x700452bca0ull);
L_700452bca0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x888ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x888ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bcb0(Cpu *c) {
    FN_ENTER(0x700452bcb0ull);
L_700452bcb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x890ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x890ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bcc0(Cpu *c) {
    FN_ENTER(0x700452bcc0ull);
L_700452bcc0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x898ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x898ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bcd0(Cpu *c) {
    FN_ENTER(0x700452bcd0ull);
L_700452bcd0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bce0(Cpu *c) {
    FN_ENTER(0x700452bce0ull);
L_700452bce0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bcf0(Cpu *c) {
    FN_ENTER(0x700452bcf0ull);
L_700452bcf0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd00(Cpu *c) {
    FN_ENTER(0x700452bd00ull);
L_700452bd00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd10(Cpu *c) {
    FN_ENTER(0x700452bd10ull);
L_700452bd10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd20(Cpu *c) {
    FN_ENTER(0x700452bd20ull);
L_700452bd20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd30(Cpu *c) {
    FN_ENTER(0x700452bd30ull);
L_700452bd30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd40(Cpu *c) {
    FN_ENTER(0x700452bd40ull);
L_700452bd40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd50(Cpu *c) {
    FN_ENTER(0x700452bd50ull);
L_700452bd50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd60(Cpu *c) {
    FN_ENTER(0x700452bd60ull);
L_700452bd60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd70(Cpu *c) {
    FN_ENTER(0x700452bd70ull);
L_700452bd70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd80(Cpu *c) {
    FN_ENTER(0x700452bd80ull);
L_700452bd80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x8f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bd90(Cpu *c) {
    FN_ENTER(0x700452bd90ull);
L_700452bd90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x900ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x900ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bda0(Cpu *c) {
    FN_ENTER(0x700452bda0ull);
L_700452bda0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x908ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x908ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bdb0(Cpu *c) {
    FN_ENTER(0x700452bdb0ull);
L_700452bdb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x910ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x910ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bdc0(Cpu *c) {
    FN_ENTER(0x700452bdc0ull);
L_700452bdc0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x918ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x918ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bdd0(Cpu *c) {
    FN_ENTER(0x700452bdd0ull);
L_700452bdd0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x920ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x920ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bde0(Cpu *c) {
    FN_ENTER(0x700452bde0ull);
L_700452bde0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x928ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x928ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bdf0(Cpu *c) {
    FN_ENTER(0x700452bdf0ull);
L_700452bdf0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x930ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x930ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be00(Cpu *c) {
    FN_ENTER(0x700452be00ull);
L_700452be00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x938ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x938ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be10(Cpu *c) {
    FN_ENTER(0x700452be10ull);
L_700452be10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x940ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x940ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be20(Cpu *c) {
    FN_ENTER(0x700452be20ull);
L_700452be20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x948ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x948ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be30(Cpu *c) {
    FN_ENTER(0x700452be30ull);
L_700452be30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x950ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x950ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be40(Cpu *c) {
    FN_ENTER(0x700452be40ull);
L_700452be40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x958ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x958ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be50(Cpu *c) {
    FN_ENTER(0x700452be50ull);
L_700452be50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x960ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x960ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be60(Cpu *c) {
    FN_ENTER(0x700452be60ull);
L_700452be60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x968ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x968ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be70(Cpu *c) {
    FN_ENTER(0x700452be70ull);
L_700452be70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x970ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x970ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be80(Cpu *c) {
    FN_ENTER(0x700452be80ull);
L_700452be80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x978ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x978ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452be90(Cpu *c) {
    FN_ENTER(0x700452be90ull);
L_700452be90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x980ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x980ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bea0(Cpu *c) {
    FN_ENTER(0x700452bea0ull);
L_700452bea0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x988ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x988ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452beb0(Cpu *c) {
    FN_ENTER(0x700452beb0ull);
L_700452beb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x990ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x990ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bec0(Cpu *c) {
    FN_ENTER(0x700452bec0ull);
L_700452bec0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x998ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x998ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bed0(Cpu *c) {
    FN_ENTER(0x700452bed0ull);
L_700452bed0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bee0(Cpu *c) {
    FN_ENTER(0x700452bee0ull);
L_700452bee0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bef0(Cpu *c) {
    FN_ENTER(0x700452bef0ull);
L_700452bef0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf00(Cpu *c) {
    FN_ENTER(0x700452bf00ull);
L_700452bf00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf10(Cpu *c) {
    FN_ENTER(0x700452bf10ull);
L_700452bf10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf20(Cpu *c) {
    FN_ENTER(0x700452bf20ull);
L_700452bf20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf30(Cpu *c) {
    FN_ENTER(0x700452bf30ull);
L_700452bf30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf40(Cpu *c) {
    FN_ENTER(0x700452bf40ull);
L_700452bf40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf50(Cpu *c) {
    FN_ENTER(0x700452bf50ull);
L_700452bf50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf60(Cpu *c) {
    FN_ENTER(0x700452bf60ull);
L_700452bf60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf70(Cpu *c) {
    FN_ENTER(0x700452bf70ull);
L_700452bf70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf80(Cpu *c) {
    FN_ENTER(0x700452bf80ull);
L_700452bf80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0x9f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x9f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bf90(Cpu *c) {
    FN_ENTER(0x700452bf90ull);
L_700452bf90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bfa0(Cpu *c) {
    FN_ENTER(0x700452bfa0ull);
L_700452bfa0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bfb0(Cpu *c) {
    FN_ENTER(0x700452bfb0ull);
L_700452bfb0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bfc0(Cpu *c) {
    FN_ENTER(0x700452bfc0ull);
L_700452bfc0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bfd0(Cpu *c) {
    FN_ENTER(0x700452bfd0ull);
L_700452bfd0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bfe0(Cpu *c) {
    FN_ENTER(0x700452bfe0ull);
L_700452bfe0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452bff0(Cpu *c) {
    FN_ENTER(0x700452bff0ull);
L_700452bff0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c000(Cpu *c) {
    FN_ENTER(0x700452c000ull);
L_700452c000:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c010(Cpu *c) {
    FN_ENTER(0x700452c010ull);
L_700452c010:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c020(Cpu *c) {
    FN_ENTER(0x700452c020ull);
L_700452c020:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c030(Cpu *c) {
    FN_ENTER(0x700452c030ull);
L_700452c030:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c040(Cpu *c) {
    FN_ENTER(0x700452c040ull);
L_700452c040:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c050(Cpu *c) {
    FN_ENTER(0x700452c050ull);
L_700452c050:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c060(Cpu *c) {
    FN_ENTER(0x700452c060ull);
L_700452c060:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c070(Cpu *c) {
    FN_ENTER(0x700452c070ull);
L_700452c070:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c080(Cpu *c) {
    FN_ENTER(0x700452c080ull);
L_700452c080:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c090(Cpu *c) {
    FN_ENTER(0x700452c090ull);
L_700452c090:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c0a0(Cpu *c) {
    FN_ENTER(0x700452c0a0ull);
L_700452c0a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c0b0(Cpu *c) {
    FN_ENTER(0x700452c0b0ull);
L_700452c0b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c0c0(Cpu *c) {
    FN_ENTER(0x700452c0c0ull);
L_700452c0c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xa98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c0d0(Cpu *c) {
    FN_ENTER(0x700452c0d0ull);
L_700452c0d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xaa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c0e0(Cpu *c) {
    FN_ENTER(0x700452c0e0ull);
L_700452c0e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xaa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c0f0(Cpu *c) {
    FN_ENTER(0x700452c0f0ull);
L_700452c0f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xab0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c100(Cpu *c) {
    FN_ENTER(0x700452c100ull);
L_700452c100:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xab8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xab8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c110(Cpu *c) {
    FN_ENTER(0x700452c110ull);
L_700452c110:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xac0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c120(Cpu *c) {
    FN_ENTER(0x700452c120ull);
L_700452c120:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xac8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xac8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c130(Cpu *c) {
    FN_ENTER(0x700452c130ull);
L_700452c130:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xad0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c140(Cpu *c) {
    FN_ENTER(0x700452c140ull);
L_700452c140:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xad8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xad8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c150(Cpu *c) {
    FN_ENTER(0x700452c150ull);
L_700452c150:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xae0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c160(Cpu *c) {
    FN_ENTER(0x700452c160ull);
L_700452c160:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xae8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xae8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c170(Cpu *c) {
    FN_ENTER(0x700452c170ull);
L_700452c170:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xaf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c180(Cpu *c) {
    FN_ENTER(0x700452c180ull);
L_700452c180:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xaf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xaf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c190(Cpu *c) {
    FN_ENTER(0x700452c190ull);
L_700452c190:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c1a0(Cpu *c) {
    FN_ENTER(0x700452c1a0ull);
L_700452c1a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c1b0(Cpu *c) {
    FN_ENTER(0x700452c1b0ull);
L_700452c1b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c1c0(Cpu *c) {
    FN_ENTER(0x700452c1c0ull);
L_700452c1c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c1d0(Cpu *c) {
    FN_ENTER(0x700452c1d0ull);
L_700452c1d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c1e0(Cpu *c) {
    FN_ENTER(0x700452c1e0ull);
L_700452c1e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c1f0(Cpu *c) {
    FN_ENTER(0x700452c1f0ull);
L_700452c1f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c200(Cpu *c) {
    FN_ENTER(0x700452c200ull);
L_700452c200:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c210(Cpu *c) {
    FN_ENTER(0x700452c210ull);
L_700452c210:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c220(Cpu *c) {
    FN_ENTER(0x700452c220ull);
L_700452c220:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c230(Cpu *c) {
    FN_ENTER(0x700452c230ull);
L_700452c230:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c240(Cpu *c) {
    FN_ENTER(0x700452c240ull);
L_700452c240:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c250(Cpu *c) {
    FN_ENTER(0x700452c250ull);
L_700452c250:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c260(Cpu *c) {
    FN_ENTER(0x700452c260ull);
L_700452c260:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c270(Cpu *c) {
    FN_ENTER(0x700452c270ull);
L_700452c270:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c280(Cpu *c) {
    FN_ENTER(0x700452c280ull);
L_700452c280:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c290(Cpu *c) {
    FN_ENTER(0x700452c290ull);
L_700452c290:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c2a0(Cpu *c) {
    FN_ENTER(0x700452c2a0ull);
L_700452c2a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c2b0(Cpu *c) {
    FN_ENTER(0x700452c2b0ull);
L_700452c2b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c2c0(Cpu *c) {
    FN_ENTER(0x700452c2c0ull);
L_700452c2c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xb98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c2d0(Cpu *c) {
    FN_ENTER(0x700452c2d0ull);
L_700452c2d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xba0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c2e0(Cpu *c) {
    FN_ENTER(0x700452c2e0ull);
L_700452c2e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xba8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xba8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c2f0(Cpu *c) {
    FN_ENTER(0x700452c2f0ull);
L_700452c2f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c300(Cpu *c) {
    FN_ENTER(0x700452c300ull);
L_700452c300:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c310(Cpu *c) {
    FN_ENTER(0x700452c310ull);
L_700452c310:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c320(Cpu *c) {
    FN_ENTER(0x700452c320ull);
L_700452c320:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c330(Cpu *c) {
    FN_ENTER(0x700452c330ull);
L_700452c330:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c340(Cpu *c) {
    FN_ENTER(0x700452c340ull);
L_700452c340:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c350(Cpu *c) {
    FN_ENTER(0x700452c350ull);
L_700452c350:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c360(Cpu *c) {
    FN_ENTER(0x700452c360ull);
L_700452c360:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c370(Cpu *c) {
    FN_ENTER(0x700452c370ull);
L_700452c370:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c380(Cpu *c) {
    FN_ENTER(0x700452c380ull);
L_700452c380:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xbf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xbf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c390(Cpu *c) {
    FN_ENTER(0x700452c390ull);
L_700452c390:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c3a0(Cpu *c) {
    FN_ENTER(0x700452c3a0ull);
L_700452c3a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c3b0(Cpu *c) {
    FN_ENTER(0x700452c3b0ull);
L_700452c3b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c3c0(Cpu *c) {
    FN_ENTER(0x700452c3c0ull);
L_700452c3c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c3d0(Cpu *c) {
    FN_ENTER(0x700452c3d0ull);
L_700452c3d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c3e0(Cpu *c) {
    FN_ENTER(0x700452c3e0ull);
L_700452c3e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c3f0(Cpu *c) {
    FN_ENTER(0x700452c3f0ull);
L_700452c3f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c400(Cpu *c) {
    FN_ENTER(0x700452c400ull);
L_700452c400:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c410(Cpu *c) {
    FN_ENTER(0x700452c410ull);
L_700452c410:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c420(Cpu *c) {
    FN_ENTER(0x700452c420ull);
L_700452c420:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c430(Cpu *c) {
    FN_ENTER(0x700452c430ull);
L_700452c430:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c440(Cpu *c) {
    FN_ENTER(0x700452c440ull);
L_700452c440:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c450(Cpu *c) {
    FN_ENTER(0x700452c450ull);
L_700452c450:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c460(Cpu *c) {
    FN_ENTER(0x700452c460ull);
L_700452c460:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c470(Cpu *c) {
    FN_ENTER(0x700452c470ull);
L_700452c470:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c480(Cpu *c) {
    FN_ENTER(0x700452c480ull);
L_700452c480:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c490(Cpu *c) {
    FN_ENTER(0x700452c490ull);
L_700452c490:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c4a0(Cpu *c) {
    FN_ENTER(0x700452c4a0ull);
L_700452c4a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c4b0(Cpu *c) {
    FN_ENTER(0x700452c4b0ull);
L_700452c4b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c4c0(Cpu *c) {
    FN_ENTER(0x700452c4c0ull);
L_700452c4c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xc98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c4d0(Cpu *c) {
    FN_ENTER(0x700452c4d0ull);
L_700452c4d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xca0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c4e0(Cpu *c) {
    FN_ENTER(0x700452c4e0ull);
L_700452c4e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xca8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xca8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c4f0(Cpu *c) {
    FN_ENTER(0x700452c4f0ull);
L_700452c4f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xcb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c500(Cpu *c) {
    FN_ENTER(0x700452c500ull);
L_700452c500:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xcb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c510(Cpu *c) {
    FN_ENTER(0x700452c510ull);
L_700452c510:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xcc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c520(Cpu *c) {
    FN_ENTER(0x700452c520ull);
L_700452c520:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xcc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c530(Cpu *c) {
    FN_ENTER(0x700452c530ull);
L_700452c530:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xcd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c540(Cpu *c) {
    FN_ENTER(0x700452c540ull);
L_700452c540:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xcd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c550(Cpu *c) {
    FN_ENTER(0x700452c550ull);
L_700452c550:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xce0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c560(Cpu *c) {
    FN_ENTER(0x700452c560ull);
L_700452c560:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xce8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xce8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c570(Cpu *c) {
    FN_ENTER(0x700452c570ull);
L_700452c570:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xcf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c580(Cpu *c) {
    FN_ENTER(0x700452c580ull);
L_700452c580:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xcf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xcf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c590(Cpu *c) {
    FN_ENTER(0x700452c590ull);
L_700452c590:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c5a0(Cpu *c) {
    FN_ENTER(0x700452c5a0ull);
L_700452c5a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c5b0(Cpu *c) {
    FN_ENTER(0x700452c5b0ull);
L_700452c5b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c5c0(Cpu *c) {
    FN_ENTER(0x700452c5c0ull);
L_700452c5c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c5d0(Cpu *c) {
    FN_ENTER(0x700452c5d0ull);
L_700452c5d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c5e0(Cpu *c) {
    FN_ENTER(0x700452c5e0ull);
L_700452c5e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c5f0(Cpu *c) {
    FN_ENTER(0x700452c5f0ull);
L_700452c5f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c600(Cpu *c) {
    FN_ENTER(0x700452c600ull);
L_700452c600:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c610(Cpu *c) {
    FN_ENTER(0x700452c610ull);
L_700452c610:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c620(Cpu *c) {
    FN_ENTER(0x700452c620ull);
L_700452c620:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c630(Cpu *c) {
    FN_ENTER(0x700452c630ull);
L_700452c630:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c640(Cpu *c) {
    FN_ENTER(0x700452c640ull);
L_700452c640:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c650(Cpu *c) {
    FN_ENTER(0x700452c650ull);
L_700452c650:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c660(Cpu *c) {
    FN_ENTER(0x700452c660ull);
L_700452c660:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c670(Cpu *c) {
    FN_ENTER(0x700452c670ull);
L_700452c670:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c680(Cpu *c) {
    FN_ENTER(0x700452c680ull);
L_700452c680:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c690(Cpu *c) {
    FN_ENTER(0x700452c690ull);
L_700452c690:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c6a0(Cpu *c) {
    FN_ENTER(0x700452c6a0ull);
L_700452c6a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c6b0(Cpu *c) {
    FN_ENTER(0x700452c6b0ull);
L_700452c6b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c6c0(Cpu *c) {
    FN_ENTER(0x700452c6c0ull);
L_700452c6c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xd98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c6d0(Cpu *c) {
    FN_ENTER(0x700452c6d0ull);
L_700452c6d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xda0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c6e0(Cpu *c) {
    FN_ENTER(0x700452c6e0ull);
L_700452c6e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xda8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xda8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c6f0(Cpu *c) {
    FN_ENTER(0x700452c6f0ull);
L_700452c6f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xdb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c700(Cpu *c) {
    FN_ENTER(0x700452c700ull);
L_700452c700:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xdb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c710(Cpu *c) {
    FN_ENTER(0x700452c710ull);
L_700452c710:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xdc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c720(Cpu *c) {
    FN_ENTER(0x700452c720ull);
L_700452c720:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xdc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c730(Cpu *c) {
    FN_ENTER(0x700452c730ull);
L_700452c730:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xdd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c740(Cpu *c) {
    FN_ENTER(0x700452c740ull);
L_700452c740:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xdd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c750(Cpu *c) {
    FN_ENTER(0x700452c750ull);
L_700452c750:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xde0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c760(Cpu *c) {
    FN_ENTER(0x700452c760ull);
L_700452c760:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xde8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xde8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c770(Cpu *c) {
    FN_ENTER(0x700452c770ull);
L_700452c770:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xdf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c780(Cpu *c) {
    FN_ENTER(0x700452c780ull);
L_700452c780:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xdf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xdf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c790(Cpu *c) {
    FN_ENTER(0x700452c790ull);
L_700452c790:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c7a0(Cpu *c) {
    FN_ENTER(0x700452c7a0ull);
L_700452c7a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c7b0(Cpu *c) {
    FN_ENTER(0x700452c7b0ull);
L_700452c7b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c7c0(Cpu *c) {
    FN_ENTER(0x700452c7c0ull);
L_700452c7c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c7d0(Cpu *c) {
    FN_ENTER(0x700452c7d0ull);
L_700452c7d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c7e0(Cpu *c) {
    FN_ENTER(0x700452c7e0ull);
L_700452c7e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c7f0(Cpu *c) {
    FN_ENTER(0x700452c7f0ull);
L_700452c7f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c800(Cpu *c) {
    FN_ENTER(0x700452c800ull);
L_700452c800:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c810(Cpu *c) {
    FN_ENTER(0x700452c810ull);
L_700452c810:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c820(Cpu *c) {
    FN_ENTER(0x700452c820ull);
L_700452c820:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c830(Cpu *c) {
    FN_ENTER(0x700452c830ull);
L_700452c830:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c840(Cpu *c) {
    FN_ENTER(0x700452c840ull);
L_700452c840:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c850(Cpu *c) {
    FN_ENTER(0x700452c850ull);
L_700452c850:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c860(Cpu *c) {
    FN_ENTER(0x700452c860ull);
L_700452c860:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c870(Cpu *c) {
    FN_ENTER(0x700452c870ull);
L_700452c870:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c880(Cpu *c) {
    FN_ENTER(0x700452c880ull);
L_700452c880:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c890(Cpu *c) {
    FN_ENTER(0x700452c890ull);
L_700452c890:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c8a0(Cpu *c) {
    FN_ENTER(0x700452c8a0ull);
L_700452c8a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c8b0(Cpu *c) {
    FN_ENTER(0x700452c8b0ull);
L_700452c8b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c8c0(Cpu *c) {
    FN_ENTER(0x700452c8c0ull);
L_700452c8c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xe98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c8d0(Cpu *c) {
    FN_ENTER(0x700452c8d0ull);
L_700452c8d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xea0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c8e0(Cpu *c) {
    FN_ENTER(0x700452c8e0ull);
L_700452c8e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xea8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xea8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c8f0(Cpu *c) {
    FN_ENTER(0x700452c8f0ull);
L_700452c8f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xeb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c900(Cpu *c) {
    FN_ENTER(0x700452c900ull);
L_700452c900:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xeb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xeb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c910(Cpu *c) {
    FN_ENTER(0x700452c910ull);
L_700452c910:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xec0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c920(Cpu *c) {
    FN_ENTER(0x700452c920ull);
L_700452c920:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xec8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xec8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c930(Cpu *c) {
    FN_ENTER(0x700452c930ull);
L_700452c930:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xed0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c940(Cpu *c) {
    FN_ENTER(0x700452c940ull);
L_700452c940:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xed8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xed8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c950(Cpu *c) {
    FN_ENTER(0x700452c950ull);
L_700452c950:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xee0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c960(Cpu *c) {
    FN_ENTER(0x700452c960ull);
L_700452c960:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xee8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xee8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c970(Cpu *c) {
    FN_ENTER(0x700452c970ull);
L_700452c970:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xef0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c980(Cpu *c) {
    FN_ENTER(0x700452c980ull);
L_700452c980:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xef8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xef8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c990(Cpu *c) {
    FN_ENTER(0x700452c990ull);
L_700452c990:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf00ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf00ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c9a0(Cpu *c) {
    FN_ENTER(0x700452c9a0ull);
L_700452c9a0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf08ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf08ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c9b0(Cpu *c) {
    FN_ENTER(0x700452c9b0ull);
L_700452c9b0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c9c0(Cpu *c) {
    FN_ENTER(0x700452c9c0ull);
L_700452c9c0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c9d0(Cpu *c) {
    FN_ENTER(0x700452c9d0ull);
L_700452c9d0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c9e0(Cpu *c) {
    FN_ENTER(0x700452c9e0ull);
L_700452c9e0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452c9f0(Cpu *c) {
    FN_ENTER(0x700452c9f0ull);
L_700452c9f0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca00(Cpu *c) {
    FN_ENTER(0x700452ca00ull);
L_700452ca00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca10(Cpu *c) {
    FN_ENTER(0x700452ca10ull);
L_700452ca10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca20(Cpu *c) {
    FN_ENTER(0x700452ca20ull);
L_700452ca20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca30(Cpu *c) {
    FN_ENTER(0x700452ca30ull);
L_700452ca30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca40(Cpu *c) {
    FN_ENTER(0x700452ca40ull);
L_700452ca40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca50(Cpu *c) {
    FN_ENTER(0x700452ca50ull);
L_700452ca50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca60(Cpu *c) {
    FN_ENTER(0x700452ca60ull);
L_700452ca60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca70(Cpu *c) {
    FN_ENTER(0x700452ca70ull);
L_700452ca70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca80(Cpu *c) {
    FN_ENTER(0x700452ca80ull);
L_700452ca80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ca90(Cpu *c) {
    FN_ENTER(0x700452ca90ull);
L_700452ca90:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452caa0(Cpu *c) {
    FN_ENTER(0x700452caa0ull);
L_700452caa0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cab0(Cpu *c) {
    FN_ENTER(0x700452cab0ull);
L_700452cab0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cac0(Cpu *c) {
    FN_ENTER(0x700452cac0ull);
L_700452cac0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xf98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cad0(Cpu *c) {
    FN_ENTER(0x700452cad0ull);
L_700452cad0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cae0(Cpu *c) {
    FN_ENTER(0x700452cae0ull);
L_700452cae0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452caf0(Cpu *c) {
    FN_ENTER(0x700452caf0ull);
L_700452caf0:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb00(Cpu *c) {
    FN_ENTER(0x700452cb00ull);
L_700452cb00:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb10(Cpu *c) {
    FN_ENTER(0x700452cb10ull);
L_700452cb10:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb20(Cpu *c) {
    FN_ENTER(0x700452cb20ull);
L_700452cb20:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb30(Cpu *c) {
    FN_ENTER(0x700452cb30ull);
L_700452cb30:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb40(Cpu *c) {
    FN_ENTER(0x700452cb40ull);
L_700452cb40:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb50(Cpu *c) {
    FN_ENTER(0x700452cb50ull);
L_700452cb50:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb60(Cpu *c) {
    FN_ENTER(0x700452cb60ull);
L_700452cb60:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xfe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xfe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb70(Cpu *c) {
    FN_ENTER(0x700452cb70ull);
L_700452cb70:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xff0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb80(Cpu *c) {
    FN_ENTER(0x700452cb80ull);
L_700452cb80:;
    c->x[16] = (uint64_t)(0x7004c2e000ull);
    { uint64_t ea = c->x[16] + 0xff8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xff8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cb90(Cpu *c) {
    FN_ENTER(0x700452cb90ull);
L_700452cb90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cba0(Cpu *c) {
    FN_ENTER(0x700452cba0ull);
L_700452cba0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cbb0(Cpu *c) {
    FN_ENTER(0x700452cbb0ull);
L_700452cbb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x10ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x10ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cbc0(Cpu *c) {
    FN_ENTER(0x700452cbc0ull);
L_700452cbc0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x18ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x18ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cbd0(Cpu *c) {
    FN_ENTER(0x700452cbd0ull);
L_700452cbd0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x20ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x20ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cbe0(Cpu *c) {
    FN_ENTER(0x700452cbe0ull);
L_700452cbe0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x28ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x28ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cbf0(Cpu *c) {
    FN_ENTER(0x700452cbf0ull);
L_700452cbf0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x30ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x30ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc00(Cpu *c) {
    FN_ENTER(0x700452cc00ull);
L_700452cc00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x38ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x38ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc10(Cpu *c) {
    FN_ENTER(0x700452cc10ull);
L_700452cc10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x40ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x40ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc20(Cpu *c) {
    FN_ENTER(0x700452cc20ull);
L_700452cc20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x48ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x48ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc30(Cpu *c) {
    FN_ENTER(0x700452cc30ull);
L_700452cc30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x50ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x50ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc40(Cpu *c) {
    FN_ENTER(0x700452cc40ull);
L_700452cc40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x58ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x58ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc50(Cpu *c) {
    FN_ENTER(0x700452cc50ull);
L_700452cc50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x60ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x60ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc60(Cpu *c) {
    FN_ENTER(0x700452cc60ull);
L_700452cc60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x68ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x68ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc70(Cpu *c) {
    FN_ENTER(0x700452cc70ull);
L_700452cc70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x70ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x70ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc80(Cpu *c) {
    FN_ENTER(0x700452cc80ull);
L_700452cc80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x78ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x78ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cc90(Cpu *c) {
    FN_ENTER(0x700452cc90ull);
L_700452cc90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x80ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x80ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cca0(Cpu *c) {
    FN_ENTER(0x700452cca0ull);
L_700452cca0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x88ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x88ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ccb0(Cpu *c) {
    FN_ENTER(0x700452ccb0ull);
L_700452ccb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x90ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x90ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ccc0(Cpu *c) {
    FN_ENTER(0x700452ccc0ull);
L_700452ccc0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x98ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x98ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ccd0(Cpu *c) {
    FN_ENTER(0x700452ccd0ull);
L_700452ccd0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cce0(Cpu *c) {
    FN_ENTER(0x700452cce0ull);
L_700452cce0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xa8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xa8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ccf0(Cpu *c) {
    FN_ENTER(0x700452ccf0ull);
L_700452ccf0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd00(Cpu *c) {
    FN_ENTER(0x700452cd00ull);
L_700452cd00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xb8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xb8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd10(Cpu *c) {
    FN_ENTER(0x700452cd10ull);
L_700452cd10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd20(Cpu *c) {
    FN_ENTER(0x700452cd20ull);
L_700452cd20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xc8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xc8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd30(Cpu *c) {
    FN_ENTER(0x700452cd30ull);
L_700452cd30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd40(Cpu *c) {
    FN_ENTER(0x700452cd40ull);
L_700452cd40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xd8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xd8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd50(Cpu *c) {
    FN_ENTER(0x700452cd50ull);
L_700452cd50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd60(Cpu *c) {
    FN_ENTER(0x700452cd60ull);
L_700452cd60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xe8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xe8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd70(Cpu *c) {
    FN_ENTER(0x700452cd70ull);
L_700452cd70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd80(Cpu *c) {
    FN_ENTER(0x700452cd80ull);
L_700452cd80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0xf8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0xf8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cd90(Cpu *c) {
    FN_ENTER(0x700452cd90ull);
L_700452cd90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x100ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x100ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cda0(Cpu *c) {
    FN_ENTER(0x700452cda0ull);
L_700452cda0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x108ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x108ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cdb0(Cpu *c) {
    FN_ENTER(0x700452cdb0ull);
L_700452cdb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x110ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x110ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cdc0(Cpu *c) {
    FN_ENTER(0x700452cdc0ull);
L_700452cdc0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x118ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x118ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cdd0(Cpu *c) {
    FN_ENTER(0x700452cdd0ull);
L_700452cdd0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x120ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x120ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cde0(Cpu *c) {
    FN_ENTER(0x700452cde0ull);
L_700452cde0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x128ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x128ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cdf0(Cpu *c) {
    FN_ENTER(0x700452cdf0ull);
L_700452cdf0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x130ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x130ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce00(Cpu *c) {
    FN_ENTER(0x700452ce00ull);
L_700452ce00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x138ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x138ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce10(Cpu *c) {
    FN_ENTER(0x700452ce10ull);
L_700452ce10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x140ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x140ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce20(Cpu *c) {
    FN_ENTER(0x700452ce20ull);
L_700452ce20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x148ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x148ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce30(Cpu *c) {
    FN_ENTER(0x700452ce30ull);
L_700452ce30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x150ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x150ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce40(Cpu *c) {
    FN_ENTER(0x700452ce40ull);
L_700452ce40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x158ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x158ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce50(Cpu *c) {
    FN_ENTER(0x700452ce50ull);
L_700452ce50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x160ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x160ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce60(Cpu *c) {
    FN_ENTER(0x700452ce60ull);
L_700452ce60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x168ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x168ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce70(Cpu *c) {
    FN_ENTER(0x700452ce70ull);
L_700452ce70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x170ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x170ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce80(Cpu *c) {
    FN_ENTER(0x700452ce80ull);
L_700452ce80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x178ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x178ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ce90(Cpu *c) {
    FN_ENTER(0x700452ce90ull);
L_700452ce90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x180ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x180ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cea0(Cpu *c) {
    FN_ENTER(0x700452cea0ull);
L_700452cea0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x188ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x188ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ceb0(Cpu *c) {
    FN_ENTER(0x700452ceb0ull);
L_700452ceb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x190ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x190ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cec0(Cpu *c) {
    FN_ENTER(0x700452cec0ull);
L_700452cec0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x198ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x198ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452ced0(Cpu *c) {
    FN_ENTER(0x700452ced0ull);
L_700452ced0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cee0(Cpu *c) {
    FN_ENTER(0x700452cee0ull);
L_700452cee0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cef0(Cpu *c) {
    FN_ENTER(0x700452cef0ull);
L_700452cef0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf00(Cpu *c) {
    FN_ENTER(0x700452cf00ull);
L_700452cf00:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf10(Cpu *c) {
    FN_ENTER(0x700452cf10ull);
L_700452cf10:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf20(Cpu *c) {
    FN_ENTER(0x700452cf20ull);
L_700452cf20:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf30(Cpu *c) {
    FN_ENTER(0x700452cf30ull);
L_700452cf30:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf40(Cpu *c) {
    FN_ENTER(0x700452cf40ull);
L_700452cf40:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf50(Cpu *c) {
    FN_ENTER(0x700452cf50ull);
L_700452cf50:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf60(Cpu *c) {
    FN_ENTER(0x700452cf60ull);
L_700452cf60:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf70(Cpu *c) {
    FN_ENTER(0x700452cf70ull);
L_700452cf70:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf80(Cpu *c) {
    FN_ENTER(0x700452cf80ull);
L_700452cf80:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x1f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x1f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cf90(Cpu *c) {
    FN_ENTER(0x700452cf90ull);
L_700452cf90:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x200ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x200ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cfa0(Cpu *c) {
    FN_ENTER(0x700452cfa0ull);
L_700452cfa0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x208ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x208ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cfb0(Cpu *c) {
    FN_ENTER(0x700452cfb0ull);
L_700452cfb0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x210ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x210ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cfc0(Cpu *c) {
    FN_ENTER(0x700452cfc0ull);
L_700452cfc0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x218ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x218ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cfd0(Cpu *c) {
    FN_ENTER(0x700452cfd0ull);
L_700452cfd0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x220ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x220ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cfe0(Cpu *c) {
    FN_ENTER(0x700452cfe0ull);
L_700452cfe0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x228ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x228ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452cff0(Cpu *c) {
    FN_ENTER(0x700452cff0ull);
L_700452cff0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x230ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x230ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d000(Cpu *c) {
    FN_ENTER(0x700452d000ull);
L_700452d000:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x238ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x238ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d010(Cpu *c) {
    FN_ENTER(0x700452d010ull);
L_700452d010:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x240ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x240ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d020(Cpu *c) {
    FN_ENTER(0x700452d020ull);
L_700452d020:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x248ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x248ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d030(Cpu *c) {
    FN_ENTER(0x700452d030ull);
L_700452d030:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x250ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x250ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d040(Cpu *c) {
    FN_ENTER(0x700452d040ull);
L_700452d040:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x258ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x258ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d050(Cpu *c) {
    FN_ENTER(0x700452d050ull);
L_700452d050:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x260ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x260ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d060(Cpu *c) {
    FN_ENTER(0x700452d060ull);
L_700452d060:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x268ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x268ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d070(Cpu *c) {
    FN_ENTER(0x700452d070ull);
L_700452d070:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x270ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x270ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d080(Cpu *c) {
    FN_ENTER(0x700452d080ull);
L_700452d080:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x278ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x278ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d090(Cpu *c) {
    FN_ENTER(0x700452d090ull);
L_700452d090:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x280ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x280ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d0a0(Cpu *c) {
    FN_ENTER(0x700452d0a0ull);
L_700452d0a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x288ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x288ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d0b0(Cpu *c) {
    FN_ENTER(0x700452d0b0ull);
L_700452d0b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x290ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x290ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d0c0(Cpu *c) {
    FN_ENTER(0x700452d0c0ull);
L_700452d0c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x298ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x298ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d0d0(Cpu *c) {
    FN_ENTER(0x700452d0d0ull);
L_700452d0d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2a0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d0e0(Cpu *c) {
    FN_ENTER(0x700452d0e0ull);
L_700452d0e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2a8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2a8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d0f0(Cpu *c) {
    FN_ENTER(0x700452d0f0ull);
L_700452d0f0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2b0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d100(Cpu *c) {
    FN_ENTER(0x700452d100ull);
L_700452d100:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2b8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2b8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d110(Cpu *c) {
    FN_ENTER(0x700452d110ull);
L_700452d110:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2c0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d120(Cpu *c) {
    FN_ENTER(0x700452d120ull);
L_700452d120:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2c8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2c8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d130(Cpu *c) {
    FN_ENTER(0x700452d130ull);
L_700452d130:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2d0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d140(Cpu *c) {
    FN_ENTER(0x700452d140ull);
L_700452d140:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2d8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2d8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d150(Cpu *c) {
    FN_ENTER(0x700452d150ull);
L_700452d150:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2e0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d160(Cpu *c) {
    FN_ENTER(0x700452d160ull);
L_700452d160:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2e8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2e8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d170(Cpu *c) {
    FN_ENTER(0x700452d170ull);
L_700452d170:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2f0ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f0ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d180(Cpu *c) {
    FN_ENTER(0x700452d180ull);
L_700452d180:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x2f8ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x2f8ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d190(Cpu *c) {
    FN_ENTER(0x700452d190ull);
L_700452d190:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x300ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x300ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d1a0(Cpu *c) {
    FN_ENTER(0x700452d1a0ull);
L_700452d1a0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x308ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x308ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d1b0(Cpu *c) {
    FN_ENTER(0x700452d1b0ull);
L_700452d1b0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x310ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x310ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d1c0(Cpu *c) {
    FN_ENTER(0x700452d1c0ull);
L_700452d1c0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x318ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x318ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d1d0(Cpu *c) {
    FN_ENTER(0x700452d1d0ull);
L_700452d1d0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x320ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x320ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
void f_700452d1e0(Cpu *c) {
    FN_ENTER(0x700452d1e0ull);
L_700452d1e0:;
    c->x[16] = (uint64_t)(0x7004c2f000ull);
    { uint64_t ea = c->x[16] + 0x328ull; uint64_t v = LD64(ea); c->x[17] = (uint64_t)(v); }
    c->x[16] = (uint64_t)(c->x[16] + 0x328ull);
    c->pc = c->x[17]; __attribute__((musttail)) return rt_dispatch(c);
}
