/*
 * Copyright © 2012 Collabora, Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT.  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/*
 * Based on weston shared/os-compatibility.c
 */

#include "anon_file.h"

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#if defined(HAVE_MEMFD_CREATE) || defined(__FreeBSD__) ||                      \
    defined(__OpenBSD__) || defined(__APPLE__)
#include <sys/mman.h>
#elif defined(__ANDROID__)
#include <sys/syscall.h>
#include <linux/memfd.h>
#else
#include <stdio.h>
#endif

#if defined(__APPLE__)
#ifndef PSHMNAMLEN
#define PSHMNAMLEN (31)
#endif
#define APP_SANDBOX_GROUP_ID_MAX (PSHMNAMLEN - 3)
#endif

#if !(defined(__FreeBSD__) || defined(HAVE_MEMFD_CREATE) ||                    \
      defined(HAVE_MKOSTEMP) || defined(__ANDROID__) || defined(__APPLE__))
static int
set_cloexec_or_close(int fd)
{
   long flags;

   if (fd == -1)
      return -1;

   flags = fcntl(fd, F_GETFD);
   if (flags == -1)
      goto err;

   if (fcntl(fd, F_SETFD, flags | FD_CLOEXEC) == -1)
      goto err;

   return fd;

err:
   close(fd);
   return -1;
}
#endif

#if !(defined(__FreeBSD__) || defined(HAVE_MEMFD_CREATE) ||                    \
      defined(__ANDROID__) || defined(__APPLE__))
static int
create_tmpfile_cloexec(char *tmpname)
{
   int fd;

#ifdef HAVE_MKOSTEMP
   fd = mkostemp(tmpname, O_CLOEXEC);
#else
   fd = mkstemp(tmpname);
#endif

   if (fd < 0) {
      return fd;
   }

#ifndef HAVE_MKOSTEMP
   fd = set_cloexec_or_close(fd);
#endif

   unlink(tmpname);
   return fd;
}
#endif

/*
 * Create a new, unique, anonymous file of the given size, and
 * return the file descriptor for it. The file descriptor is set
 * CLOEXEC. The file is immediately suitable for mmap()'ing
 * the given size at offset zero.
 *
 * An optional name for debugging can be provided as the second argument.
 *
 * The file should not have a permanent backing store like a disk,
 * but may have if XDG_RUNTIME_DIR is not properly implemented in OS.
 *
 * If memfd or SHM_ANON is supported, the filesystem is not touched at all.
 * Otherwise, the file name is deleted from the file system.
 *
 * The file is suitable for buffer sharing between processes by
 * transmitting the file descriptor over Unix sockets using the
 * SCM_RIGHTS methods.
 */
int
os_create_anonymous_file(off_t size, const char *debug_name)
{
   int fd, ret;
#if defined(HAVE_MEMFD_CREATE)
   if (!debug_name)
      debug_name = "mesa-shared";
   fd = memfd_create(debug_name, MFD_CLOEXEC | MFD_ALLOW_SEALING);
#elif defined(__ANDROID__)
   if (!debug_name)
      debug_name = "mesa-shared";
   fd = syscall(SYS_memfd_create, debug_name, MFD_CLOEXEC | MFD_ALLOW_SEALING);
#elif defined(__FreeBSD__)
   fd = shm_open(SHM_ANON, O_CREAT | O_RDWR | O_CLOEXEC, 0600);
#elif defined(__APPLE__)
   /* Under App Sandbox a shm name must live in the app group container, i.e.
    * be prefixed with the group identifier instead of '/'; anything else is
    * denied.  The PSHMNAMLEN budget then leaves no room for a debug tag or
    * the pid, so the name is just a slot digit plus as much of the nonce as
    * fits. */
   const char *group = getenv("APP_SANDBOX_GROUP_ID");
   if (group && !group[0])
      group = NULL;
   if (group && strlen(group) > APP_SANDBOX_GROUP_ID_MAX) {
      fprintf(stderr, "APP_SANDBOX_GROUP_ID is %zu chars, at most %d fit\n",
              strlen(group), APP_SANDBOX_GROUP_ID_MAX);
      errno = EINVAL;
      return -1;
   }

   const char *tag = (debug_name && debug_name[0]) ? debug_name : "mesa";
   const size_t nonce_room = group ? PSHMNAMLEN - strlen(group) - 2 : 8;
   const unsigned int nonce_digits = nonce_room < 8 ? (unsigned int)nonce_room : 8;
   const unsigned int nonce = arc4random() >> (32 - 4 * nonce_digits);
   for (unsigned int i = 0; i < 32; i++) {
     char shm_name[64];
     if (group) {
       /* the slot must stay a single hex digit to fit the name budget */
       if (i > 0xf)
         break;
       snprintf(shm_name, sizeof(shm_name), "%s/%x%x", group, i, nonce);
     } else {
       snprintf(shm_name, sizeof(shm_name), "/%s-%d-%x-%x", tag, getpid(),
                nonce, i);
     }
     /* macOS shm_open() rejects O_CLOEXEC with EINVAL; set close-on-exec
      * explicitly afterwards instead. */
     fd = shm_open(shm_name, O_CREAT | O_EXCL | O_RDWR, 0600);
     if (fd >= 0) {
       fcntl(fd, F_SETFD, FD_CLOEXEC);
       shm_unlink(shm_name);
       break;
     }

     if (errno != EEXIST)
       break;
   }
#elif defined(__OpenBSD__)
   char template[] = "/tmp/mesa-XXXXXXXXXX";
   fd = shm_mkstemp(template);
   if (fd != -1)
      shm_unlink(template);
#else
   const char *path;
   char *name;

   path = getenv("XDG_RUNTIME_DIR");
   if (!path)
      path = "/tmp";

   if (debug_name)
      asprintf(&name, "%s/mesa-shared-%s-XXXXXX", path, debug_name);
   else
      asprintf(&name, "%s/mesa-shared-XXXXXX", path);
   if (!name)
      return -1;

   fd = create_tmpfile_cloexec(name);

   free(name);
#endif

   if (fd < 0)
      return -1;

   ret = ftruncate(fd, size);
   if (ret < 0) {
      close(fd);
      return -1;
   }

   return fd;
}
